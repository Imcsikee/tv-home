package com.example.tvhome;

import android.util.Log;
import android.content.Context;
import java.util.concurrent.CopyOnWriteArrayList;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Enumeration;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Only usable on trusted local networks. No internet relay or text logging. */
final class TvHomeTextServer {
    interface Result { void finish(boolean ok); }
    private static final String TAG = "TVHomeInput";
    private static final int PORT = 8770;
    private static final int MAX_TEXT = 4096;
    private final SecureRandom random = new SecureRandom();
    // One local pairing server. Text can be delivered only while the Android IME is visible.
    private static TvHomeTextServer instance;
    private final CopyOnWriteArrayList<Runnable> listeners = new CopyOnWriteArrayList<>();
    static synchronized TvHomeTextServer shared(Context context) {
        if (instance == null) instance = new TvHomeTextServer();
        instance.start();
        return instance;
    }
    static synchronized TvHomeTextServer peek() { return instance; }
    void addListener(Runnable listener) { listeners.addIfAbsent(listener); listener.run(); }
    void removeListener(Runnable listener) { listeners.remove(listener); }
    private void notifyChanged() {
        for (Runnable listener : listeners) {
            try { listener.run(); } catch (Exception ignored) { }
        }
    }
    private volatile ServerSocket listener;
    private volatile boolean running;
    private volatile String pendingToken;
    private volatile String activeToken;
    private final Object sessionLock = new Object();

    private TvHomeTextServer() { pendingToken = token(); }

    void start() {
        if (running) return;
        running = true;
        Thread worker = new Thread(new Runnable() {
            @Override public void run() {
                try (ServerSocket socket = new ServerSocket()) {
                    socket.setReuseAddress(true);
                    socket.bind(new InetSocketAddress(PORT));
                    listener = socket;
                    notifyChanged();
                    while (running) {
                        try (Socket client = socket.accept()) {
                            client.setSoTimeout(5000);
                            serve(client);
                        } catch (IOException error) {
                            if (running) Log.w(TAG, "LAN request failed", error);
                        }
                    }
                } catch (IOException error) {
                    if (running) Log.e(TAG, "Port 8770 unavailable", error);
                } finally { listener = null; }
            }
        }, "TVHome-KeyboardServer");
        worker.setDaemon(true);
        worker.start();
    }

    void stop() {
        running = false;
        ServerSocket socket = listener;
        listener = null;
        if (socket != null) try { socket.close(); } catch (IOException ignored) { }
        synchronized (sessionLock) { pendingToken = null; activeToken = null; }
    }

    private String token() {
        byte[] bytes = new byte[24];
        random.nextBytes(bytes);
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) result.append(String.format(Locale.ROOT, "%02x", b & 255));
        return result.toString();
    }

    void revokeAndRegenerate() {
        synchronized (sessionLock) {
            activeToken = null; // immediate revoke; old browser can no longer send.
            pendingToken = token();
        }
        notifyChanged();
    }

    boolean isPaired() { return activeToken != null; }

    String pairingUrl() {
        if (listener == null) return null;
        String ip = localIp();
        String nonce = pendingToken;
        if (ip == null || nonce == null) return null;
        return "http://" + ip + ":" + PORT + "/?pair=" + nonce;
    }

    private String localIp() {
        try {
            String fallback = null;
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface n = interfaces.nextElement();
                if (!n.isUp() || n.isLoopback()) continue;
                String name = n.getName().toLowerCase(Locale.ROOT);
                Enumeration<InetAddress> addresses = n.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress a = addresses.nextElement();
                    if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                    if (name.startsWith("wlan") || name.startsWith("eth")) return a.getHostAddress();
                    if (fallback == null) fallback = a.getHostAddress();
                }
            }
            return fallback;
        } catch (Exception e) { return null; }
    }

    private String readLine(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        int ch;
        while ((ch = in.read()) != -1) {
            if (ch == '\n') break;
            if (ch != '\r') {
                if (bytes.size() >= limit) throw new IOException("header too large");
                bytes.write(ch);
            }
        }
        return bytes.toString("ISO-8859-1");
    }

    private void serve(Socket socket) throws IOException {
        InputStream in = new BufferedInputStream(socket.getInputStream());
        OutputStream out = socket.getOutputStream();
        String request = readLine(in, 4096);
        String[] req = request.split(" ");
        if (req.length < 2) { respond(out, 400, "application/json", "{\"ok\":false}"); return; }
        String method = req[0], path = req[1];
        int length = 0;
        String bearer = "";
        String origin = "";
        for (int i = 0; i < 50; i++) {
            String h = readLine(in, 4096);
            if (h.isEmpty()) break;
            int colon = h.indexOf(':');
            if (colon < 0) continue;
            String key = h.substring(0, colon).trim().toLowerCase(Locale.ROOT);
            String value = h.substring(colon + 1).trim();
            if (key.equals("content-length")) {
                try { length = Integer.parseInt(value); } catch (Exception ex) { length = -1; }
            } else if (key.equals("x-tvhome-token")) bearer = value;
            else if (key.equals("origin")) origin = value;
        }
        if (length < 0 || length > MAX_TEXT * 4) {
            respond(out, 413, "application/json", "{\"ok\":false,\"error\":\"too_long\"}"); return;
        }
        String ip = localIp();
        if (!origin.isEmpty() && (ip == null || !origin.equals("http://" + ip + ":" + PORT))) {
            respond(out, 403, "application/json", "{\"ok\":false}"); return;
        }
        if ("GET".equals(method) && path.startsWith("/?pair=")) {
            String attempt = path.substring("/?pair=".length());
            String assigned = null;
            synchronized (sessionLock) {
                if (pendingToken != null && pendingToken.equals(attempt) && activeToken == null) {
                    activeToken = token();
                    pendingToken = null; // only first phone can claim it
                    assigned = activeToken;
                }
            }
            if (assigned == null) {
                respond(out, 403, "text/html; charset=UTF-8", errorPage()); return;
            }
            respond(out, 200, "text/html; charset=UTF-8", html(assigned));
            notifyChanged();
            return;
        }
        if ("GET".equals(method) && path.equals("/")) {
            respond(out, 200, "text/html; charset=UTF-8", "<meta name='viewport' content='width=device-width'><h2>TVHome Keyboard</h2><p>Olvasd be a TV-n látható QR-kódot.</p>");
            return;
        }
        if (!"POST".equals(method) ||
                !(path.equals("/send") || path.equals("/delete") || path.equals("/enter"))) {
            respond(out, 404, "application/json", "{\"ok\":false}"); return;
        }
        String session = activeToken;
        if (session == null || !session.equals(bearer)) {
            respond(out, 403, "application/json", "{\"ok\":false,\"error\":\"disconnected\"}"); return;
        }
        byte[] data = new byte[length];
        int pos = 0;
        while (pos < length) {
            int n = in.read(data, pos, length - pos);
            if (n < 0) throw new IOException("missing body");
            pos += n;
        }
        String value = new String(data, StandardCharsets.UTF_8);
        if (value.length() > MAX_TEXT) {
            respond(out, 413, "application/json", "{\"ok\":false}"); return;
        }
        // Never execute request if the session was revoked mid-request.
        if (!session.equals(activeToken)) {
            respond(out, 403, "application/json", "{\"ok\":false}"); return;
        }
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        Result delivery = new Result() {
            @Override public void finish(boolean success) {
                ok[0] = success;
                latch.countDown();
            }
        };
        // Deliver ONLY to the active standard Android TVHome Keyboard.
        // No accessibility gesture injection and no arbitrary app overlays.
        if (!TvHomeInputService.deliverIfVisible(value, path.substring(1), delivery)) {
            delivery.finish(false);
        }
        try { latch.await(5, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        respond(out, ok[0] ? 200 : 409, "application/json",
                ok[0] ? "{\"ok\":true}" : "{\"ok\":false,\"error\":\"no_input\"}");
    }

    private String errorPage() {
        return "<meta name='viewport' content='width=device-width'><body style='background:#101823;color:white;font-family:sans-serif;padding:32px'>"
                + "<h2>A QR-kód lejárt</h2><p>A TVHome Keyboardban válaszd az új telefon csatlakoztatását.</p></body>";
    }

    private String html(String authorization) {
        return "<!doctype html><html lang='hu'><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<meta charset='utf-8'><title>TVHome Keyboard</title><style>"
                + "*{box-sizing:border-box}body{min-height:100vh;margin:0;color:#f4f9ff;font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;"
                + "background:radial-gradient(circle at top left,#27475b,#090f19 65%);padding:22px}main{max-width:530px;margin:6vh auto;"
                + "padding:25px;background:#ffffff14;border:1px solid #ffffff35;border-radius:28px;box-shadow:0 16px 50px #0008}"
                + "h1{font-size:26px;margin:0 0 8px}p{color:#b5ccdf}textarea{display:block;width:100%;resize:vertical;min-height:135px;"
                + "border-radius:16px;border:1px solid #ffffff55;background:#05101abf;padding:16px;color:white;font-size:19px;outline:none}"
                + "button{border:0;color:white;background:#426782;padding:14px 18px;border-radius:14px;font-size:16px;font-weight:650;margin-top:13px}"
                + "button.primary{background:#e3f3ff;color:#102237;width:100%}.actions{display:flex;gap:12px}.actions button{flex:1}"
                + "small{color:#a3bed0;display:block;margin-top:15px}</style></head><body><main>"
                + "<h1>TVHome Keyboard</h1><p>Kapcsolódva a tévéhez. Nyiss meg egy normál Android-szövegmezőt a tévén, ahol a TVHome Keyboard az aktív billentyűzet.</p>"
                + "<textarea id='entry' placeholder='Írj ide…' spellcheck='true'></textarea>"
                + "<button class='primary' id='send'>Szöveg elküldése</button>"
                + "<div class='actions'><button id='del'>⌫ Törlés</button><button id='enter'>↵ Enter</button></div>"
                + "<small id='status'>A szöveg csak a helyi Wi-Fi-n jut el a tévéhez. Jelszót ne írj be nem megbízható hálózaton.</small>"
                + "</main><script>const key='" + authorization + "';"
                + "async function send(action,body=''){let s=document.getElementById('status');try{let r=await fetch('/'+action,{method:'POST',headers:{'X-TVHome-Token':key,'Content-Type':'text/plain;charset=utf-8'},body});let j=await r.json();"
                + "s.textContent=j.ok?'Elküldve ✓':(r.status===403?'Kapcsolat bontva. Párosíts újra.':'A TVHome Keyboard jelenleg nincs megnyitva egy szövegmezőnél.');"
                + "if(j.ok&&action==='send')document.getElementById('entry').value='';}catch(e){s.textContent='Nem érhető el a tévé. Ellenőrizd a Wi-Fi-t.'}}"
                + "document.getElementById('send').onclick=()=>send('send',document.getElementById('entry').value);"
                + "document.getElementById('del').onclick=()=>send('delete');document.getElementById('enter').onclick=()=>send('enter');"
                + "</script></body></html>";
    }

    private void respond(OutputStream out, int code, String type, String body) throws IOException {
        byte[] raw = body.getBytes(StandardCharsets.UTF_8);
        String title = code == 200 ? "OK" : (code == 409 ? "Conflict" : "Error");
        String header = "HTTP/1.1 " + code + " " + title + "\r\nContent-Type: " + type
                + "\r\nContent-Length: " + raw.length
                + "\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer"
                + "\r\nX-Content-Type-Options: nosniff"
                + "\r\nContent-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'"
                + "\r\nConnection: close\r\n\r\n";
        out.write(header.getBytes(StandardCharsets.UTF_8));
        out.write(raw);
        out.flush();
    }
}
