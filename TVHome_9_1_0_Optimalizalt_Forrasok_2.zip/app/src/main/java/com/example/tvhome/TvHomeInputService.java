package com.example.tvhome;

import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.HashMap;
import java.util.Map;

/**
 * TVHome 8.3: valodi Android IME. Mas alkalmazas szovegmezojebe csak
 * InputConnection commitText segitsegevel ir.
 * A telefonos webes kapcsolatot a TvHomeTextServer kezeli.
 */
public class TvHomeInputService extends InputMethodService {
    private static volatile TvHomeInputService active;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TvHomeTextServer server;
    private ImageView qrView;
    private String qrUrl;
    private Bitmap qrBitmap;
    private TextView infoView;
    private TextView stateView;
    private TextView disconnectButton;
    private final Runnable refresh = new Runnable() {
        @Override public void run() { ui.post(new Runnable() {
            @Override public void run() { showPairing(); }
        }); }
    };

    static boolean deliverIfVisible(String value, String action, TvHomeTextServer.Result result) {
        TvHomeInputService service = active;
        if (service == null || !service.isInputViewShown()) return false;
        service.receiveText(value, action, result);
        return true;
    }

    public static boolean disconnectConnectedPhone() {
        TvHomeTextServer server = TvHomeTextServer.peek();
        if (server == null) return false;
        server.revokeAndRegenerate();
        return true;
    }

    @Override public void onCreate() {
        super.onCreate();
        active = this;
        server = TvHomeTextServer.shared(this);
        server.addListener(refresh);
    }

    @Override public View onCreateInputView() {
        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.HORIZONTAL);
        base.setFocusable(true);
        base.setFocusableInTouchMode(true);
        base.setGravity(Gravity.CENTER_VERTICAL);
        base.setPadding(dp(25), dp(14), dp(25), dp(14));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF182C3F, 0xFF080E18});
        bg.setCornerRadius(dp(24));
        bg.setStroke(dp(1), 0x6696C4E5);
        base.setBackground(bg);

        qrView = new ImageView(this);
        qrView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams qrLp = new LinearLayout.LayoutParams(dp(155), dp(155));
        qrLp.rightMargin = dp(24);
        base.addView(qrView, qrLp);

        LinearLayout description = new LinearLayout(this);
        description.setOrientation(LinearLayout.VERTICAL);
        description.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = label("TVHome Keyboard", 23, 0xFFFFFFFF);
        description.addView(heading);
        infoView = label("QR-kód beolvasása a telefonoddal", 15, 0xFFB6D2E5);
        description.addView(infoView);
        stateView = label("", 13, 0xFF9FE5CF);
        description.addView(stateView);

        TextView revoke = label("Kapcsolat bontása / új telefon", 14, 0xFFFFFFFF);
        revoke.setGravity(Gravity.CENTER);
        revoke.setPadding(dp(13), dp(9), dp(13), dp(9));
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0x664C7F9D);
        pill.setCornerRadius(dp(14));
        pill.setStroke(dp(1), 0x779CCADD);
        revoke.setBackground(pill);
        revoke.setFocusable(true);
        revoke.setFocusableInTouchMode(true);
        disconnectButton = revoke;
        revoke.setClickable(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(44));
        p.topMargin = dp(10);
        description.addView(revoke, p);
        revoke.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (server != null) server.revokeAndRegenerate();
                Toast.makeText(TvHomeInputService.this,
                        "Korábbi telefon leválasztva", Toast.LENGTH_SHORT).show();
            }
        });
        base.addView(description, new LinearLayout.LayoutParams(0, -2, 1));
        // Normal Android IME windows can pass DPAD through to the target app.
        // We consume the DPAD in onKeyDown/Up and move focus here ourselves.
        setDisconnectFocus(false);
        base.requestFocus();
        showPairing();
        return base;
    }

    @Override public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        showPairing();
    }

    void receiveText(final String value, final String action, final TvHomeTextServer.Result result) {
        ui.post(new Runnable() {
            @Override public void run() {
                InputConnection connection = getCurrentInputConnection();
                if (connection == null || !isInputViewShown()) {
                    result.finish(false);
                    return;
                }
                boolean ok;
                if ("delete".equals(action)) ok = connection.deleteSurroundingText(1, 0);
                else if ("enter".equals(action)) ok = connection.commitText("\n", 1);
                else ok = connection.commitText(value, 1);
                result.finish(ok);
            }
        });
    }

    private void setDisconnectFocus(boolean selected) {
        if (disconnectButton == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(selected ? 0xFFB8DBEE : 0x664C7F9D);
        bg.setStroke(dp(1), selected ? 0xFFFFFFFF : 0x779CCADD);
        disconnectButton.setTextColor(selected ? 0xFF0F2534 : 0xFFFFFFFF);
        disconnectButton.setBackground(bg);
        if (selected) disconnectButton.requestFocus();
        else disconnectButton.clearFocus();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isInputViewShown()) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                // BACK is the only key that closes the QR view.
                if (event.getRepeatCount() == 0) requestHideSelf(0);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_UP
                    || keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                setDisconnectFocus(keyCode == KeyEvent.KEYCODE_DPAD_DOWN);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                    || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if (event.getRepeatCount() == 0 && disconnectButton != null && disconnectButton.hasFocus())
                    disconnectButton.performClick();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (isInputViewShown() && (keyCode == KeyEvent.KEYCODE_BACK
                || keyCode == KeyEvent.KEYCODE_DPAD_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_UP
                || keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                || keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) return true;
        return super.onKeyUp(keyCode, event);
    }

    private void showPairing() {
        if (server == null || infoView == null || stateView == null || qrView == null) return;
        if (server.isPaired()) {
            qrView.setVisibility(View.GONE);
            infoView.setText("Telefon csatlakoztatva");
            stateView.setText("Írj a telefon böngészőjében. Az aktív app szövegmezőjébe kerül.");
            return;
        }
        String url = server.pairingUrl();
        if (url == null) {
            qrView.setVisibility(View.GONE);
            infoView.setText("A TV és a telefon legyen ugyanazon a Wi-Fi-hálózaton.");
            stateView.setText("Nincs elérhető helyi IP-cím vagy szerver.");
            return;
        }
        infoView.setText("Olvasd be a QR-kódot a telefonoddal");
        stateView.setText("Csak azonos helyi hálózaton · egy telefon egyszerre");
        showPairingQr(url);
    }

    private void showPairingQr(String url) {
        qrView.setVisibility(View.VISIBLE);
        if (url.equals(qrUrl) && qrBitmap != null && !qrBitmap.isRecycled()) {
            qrView.setImageBitmap(qrBitmap);
            return;
        }
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.MARGIN, 1);
            BitMatrix bits = new QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, 240, 240, hints);
            Bitmap result = Bitmap.createBitmap(240, 240, Bitmap.Config.RGB_565);
            int[] pixels = new int[240 * 240];
            for (int y = 0; y < 240; y++) for (int x = 0; x < 240; x++)
                pixels[y * 240 + x] = bits.get(x, y) ? 0xFF101720 : 0xFFFFFFFF;
            result.setPixels(pixels, 0, 240, 0, 0, 240, 240);
            qrUrl = url;
            qrBitmap = result;
            qrView.setImageBitmap(result);
        } catch (Exception ex) {
            qrView.setVisibility(View.GONE);
            stateView.setText("Kézi cím: " + url);
        }
    }

    private TextView label(String value, int sizeSp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sizeSp);
        return t;
    }
    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onDestroy() {
        if (server != null) server.removeListener(refresh);
        server = null;
        if (active == this) active = null;
        ui.removeCallbacksAndMessages(null);
        if (qrView != null) qrView.setImageDrawable(null);
        qrBitmap = null;
        qrUrl = null;
        super.onDestroy();
    }
}
