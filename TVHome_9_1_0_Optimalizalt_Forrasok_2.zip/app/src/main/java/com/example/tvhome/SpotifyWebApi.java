package com.example.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * TVHome 7.8.3 – Spotify Connect Web API.
 * OAuth authorization runs ONCE on user's own PC with PKCE and a local loopback callback.
 * This TV class only receives the short-lived bearer + encrypted refresh token over a
 * PIN-protected, short-lived local-LAN setup endpoint. No Spotify password or client secret.
 */
final class SpotifyWebApi {
    static final int PAIR_PORT = 38763;
    private static final String TAG = "TvHome-SpotifyAPI";
    private static final String PREFERENCES = "tvhome_spotify_api_v783";
    private static final String KEY_ALIAS = "tvhome_spotify_oauth_aes_v783";
    private final Context context;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile Snapshot snapshot;
    private volatile String accessToken = "";
    private volatile long tokenExpiryMs = 0;
    // Az API nem push-ertesitest kuld, hanem poll-olunk. A minimum idokoz
    // osszhangban van a MainActivity 2,5 s-os frissitesevel.
    private static final long MIN_POLL_GAP_MS = 2400L;
    private volatile long nextPollMs = 0;
    private volatile long rateLimitedUntilMs = 0;
    private volatile boolean activeRequest = false;
    private volatile String latestError = "";
    private volatile boolean setupOpen = false;
    private volatile ServerSocket setupSocket;
    private volatile String setupPin;
    private Thread setupThread;
    private int badPins;

    static final class Snapshot {
        final String title, artist, coverUrl, device;
        final boolean playing;
        final long progressMs, durationMs, sampledAtMs;
        Snapshot(String title, String artist, String coverUrl, String device,
                 boolean playing, long progressMs, long durationMs, long sampledAtMs) {
            this.title=title; this.artist=artist; this.coverUrl=coverUrl;
            this.device=device; this.playing=playing;
            this.progressMs=Math.max(0, progressMs);
            this.durationMs=Math.max(0, durationMs);
            this.sampledAtMs=sampledAtMs;
        }
    }

    SpotifyWebApi(Context context) {
        this.context=context.getApplicationContext();
        this.prefs=this.context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }
    boolean isLinked() { return !prefs.getString("client_id", "").isEmpty()
            && !prefs.getString("refresh_enc", "").isEmpty(); }
    String error() { return latestError; }
    Snapshot snapshot() { return snapshot; }

    private static String readAll(InputStream in, int limit) throws Exception {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) >= 0) {
            if (data.size() + n > limit) throw new IllegalStateException("Response too large");
            data.write(buf, 0, n);
        }
        return data.toString("UTF-8");
    }
    private static HttpURLConnection connect(String endpoint, String method, String token,
                                               String data) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(6000);
        c.setReadTimeout(6000);
        c.setInstanceFollowRedirects(false);
        c.setRequestProperty("Accept", "application/json");
        if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        if (data != null) {
            byte[] bytes=data.getBytes(StandardCharsets.UTF_8);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream out=c.getOutputStream()) {out.write(bytes);}
        }
        return c;
    }
    private static String encode(String x) throws Exception {
        return java.net.URLEncoder.encode(x, "UTF-8");
    }
    private SecretKey secretKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        java.security.Key k=ks.getKey(KEY_ALIAS, null);
        if (k instanceof SecretKey) return (SecretKey)k;
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }
    private String encrypt(String raw) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,secretKey());
        byte[] iv=cipher.getIV();
        byte[] ct=cipher.doFinal(raw.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv,Base64.NO_WRAP)+":"+Base64.encodeToString(ct,Base64.NO_WRAP);
    }
    private String decrypt(String encoded) throws Exception {
        String[] parts=encoded.split(":",2);
        if(parts.length!=2) throw new IllegalArgumentException("Invalid encrypted token");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,secretKey(),
                new GCMParameterSpec(128,Base64.decode(parts[0],Base64.DEFAULT)));
        return new String(cipher.doFinal(Base64.decode(parts[1],Base64.DEFAULT)), StandardCharsets.UTF_8);
    }
    private synchronized boolean ensureToken() throws Exception {
        if (!accessToken.isEmpty() && System.currentTimeMillis() < tokenExpiryMs - 60000) return true;
        String client=prefs.getString("client_id", "");
        String saved=prefs.getString("refresh_enc", "");
        if(client.isEmpty()||saved.isEmpty()) return false;
        String refresh=decrypt(saved);
        HttpURLConnection c=null;
        try {
            c=connect("https://accounts.spotify.com/api/token", "POST", null,
                    "grant_type=refresh_token&client_id="+encode(client)+"&refresh_token="+encode(refresh));
            int status=c.getResponseCode();
            if(status!=200) {latestError="Spotify token frissites: HTTP "+status; return false;}
            JSONObject body=new JSONObject(readAll(c.getInputStream(),32768));
            String fresh=body.optString("access_token","");
            if(fresh.isEmpty()) return false;
            accessToken=fresh;
            tokenExpiryMs=System.currentTimeMillis()+body.optLong("expires_in",3600)*1000;
            String newRefresh=body.optString("refresh_token","");
            if(!newRefresh.isEmpty()) prefs.edit().putString("refresh_enc",encrypt(newRefresh)).apply();
            return true;
        } finally {if(c!=null)c.disconnect();}
    }
    void poll(final Runnable onChange) {
        long now = SystemClock.elapsedRealtime();
        if(!isLinked() || activeRequest || now<nextPollMs || now<rateLimitedUntilMs) return;
        activeRequest=true;
        nextPollMs=now+MIN_POLL_GAP_MS;
        executor.execute(new Runnable() { @Override public void run() {
            HttpURLConnection c=null;
            try {
                if(!ensureToken()) return;
                c=connect("https://api.spotify.com/v1/me/player", "GET", accessToken, null);
                int status=c.getResponseCode();
                if(status==200) {
                    JSONObject body=new JSONObject(readAll(c.getInputStream(),131072));
                    JSONObject track=body.optJSONObject("item");
                    if(track!=null && !body.optBoolean("is_playing", false)
                            && (body.optJSONObject("device")==null)) snapshot=null;
                    else if(track!=null) {
                        String artist="Spotify",cover="", device="";
                        JSONArray artists=track.optJSONArray("artists");
                        if(artists!=null && artists.length()>0)
                            artist=artists.optJSONObject(0).optString("name","Spotify");
                        JSONObject album=track.optJSONObject("album");
                        if(album!=null) {
                            JSONArray images=album.optJSONArray("images");
                            if(images!=null && images.length()>0)
                                cover=images.optJSONObject(0).optString("url","");
                        }
                        JSONObject active=body.optJSONObject("device");
                        if(active!=null) device=active.optString("name","");
                        snapshot=new Snapshot(track.optString("name", ""),artist,cover,
                                device,body.optBoolean("is_playing",false),
                                body.optLong("progress_ms",0),
                                track.optLong("duration_ms",0),
                                SystemClock.elapsedRealtime());
                    } else snapshot=null;
                    latestError="";
                } else if(status==204) {snapshot=null;latestError="";}
                else if(status==429) {
                    int seconds=30;
                    try { seconds=Integer.parseInt(c.getHeaderField("Retry-After")); }catch(Exception ignored){}
                    // Spotify Retry-After tiszteletben tartasa: se timer, se
                    // taviranyitos parancs ne kapcsolja ki ezt a vedelmet.
                    rateLimitedUntilMs=SystemClock.elapsedRealtime()
                            + Math.max(1,seconds)*1000L + 250L;
                    nextPollMs=rateLimitedUntilMs;
                    latestError="Spotify API kvota / tul sok keres (429)";
                } else {
                    latestError="Spotify API: HTTP "+status;
                    if(status==401) accessToken="";
                    if(status==403) nextPollMs=SystemClock.elapsedRealtime()+60000L;
                }
            } catch(Exception e) {latestError="Spotify API nem elerheto";Log.w(TAG,"Poll",e);}
            finally {
                if(c!=null)c.disconnect();
                activeRequest=false;
                if(onChange!=null) ui.post(onChange);
            }
        }});
    }
    void command(final int command, final boolean currentlyPlaying, final Runnable onComplete) {
        if(!isLinked()) return;
        executor.execute(new Runnable(){@Override public void run(){
            HttpURLConnection c=null;
            try {
                if(!ensureToken()) throw new IllegalStateException("Spotify login lejart");
                String action=command==0?"previous":command==2?"next":currentlyPlaying?"pause":"play";
                c=connect("https://api.spotify.com/v1/me/player/"+action,(command==0||command==2)?"POST":"PUT",accessToken,null);
                int status=c.getResponseCode();
                if(status!=204 && status!=200) {
                    latestError="Spotify vezerles: HTTP "+status;
                    if(status==401) accessToken="";
                    Log.w(TAG,latestError);
                } else latestError="";
            } catch(Exception e) {latestError="Spotify nem fogadta a parancsot";Log.w(TAG,"Command",e);}
            finally {
                if(c!=null)c.disconnect();
                // A taviranyitos valtoztatas utan gyorsan kerdezunk ujra,
                // de a Spotify altal eloirt 429 varakozast nem irjuk felul.
                if (SystemClock.elapsedRealtime() >= rateLimitedUntilMs) nextPollMs=0;
                if(onComplete!=null) ui.post(onComplete);
            }
        }});
    }
    synchronized void link(String clientId, String token, String refresh, int seconds) throws Exception {
        if(!clientId.matches("[0-9a-fA-F]{32}") || refresh.length()<10 || refresh.length()>4096
                || token.length()<10 || token.length()>4096) throw new IllegalArgumentException("Invalid OAuth credentials");
        String encrypted=encrypt(refresh);
        prefs.edit().putString("client_id",clientId).putString("refresh_enc",encrypted).apply();
        accessToken=token;
        tokenExpiryMs=System.currentTimeMillis()+Math.max(30,seconds)*1000L;
        latestError="";nextPollMs=0;rateLimitedUntilMs=0;snapshot=null;
    }
    void unlink() {
        stopPairing();
        prefs.edit().clear().apply();
        accessToken="";tokenExpiryMs=0;snapshot=null;latestError="";
        nextPollMs=0;rateLimitedUntilMs=0;
    }
    void shutdown() {stopPairing();executor.shutdownNow();}

    void startPairing(String pin, final Runnable linked, final Runnable failed) {
        stopPairing();
        badPins=0;
        setupPin=pin;
        setupOpen=true;
        setupThread=new Thread(new Runnable(){@Override public void run(){
            try(ServerSocket server=new ServerSocket()) {
                server.setReuseAddress(true);
                server.bind(new InetSocketAddress(PAIR_PORT));
                server.setSoTimeout(1000);
                setupSocket=server;
                while(setupOpen) {
                    try(Socket socket=server.accept()) {
                        socket.setSoTimeout(5000);
                        handlePairRequest(socket,linked);
                    } catch(java.net.SocketTimeoutException ignored) {
                    } catch(Exception ex) {if(setupOpen) Log.w(TAG,"Pair request error",ex);}
                }
            } catch(Exception e){Log.e(TAG,"Pair server error",e);if(failed!=null)ui.post(failed);}
            finally {setupSocket=null;}
        }},"TVHome-Spotify-Setup");
        setupThread.setDaemon(true);
        setupThread.start();
    }
    void stopPairing() {
        setupOpen=false;
        setupPin=null;
        ServerSocket s=setupSocket;
        setupSocket=null;
        if(s!=null)try{s.close();}catch(Exception ignored){}
    }
    private static String line(InputStream in) throws Exception {
        ByteArrayOutputStream b=new ByteArrayOutputStream();int c;
        while((c=in.read())!=-1 && c!='\n'){
            if(c!='\r')b.write(c);
            if(b.size()>8192)throw new IllegalArgumentException("Header too long");
        }
        return b.toString("US-ASCII");
    }
    private static void answer(OutputStream out,int code,String text)throws Exception{
        byte[] b=text.getBytes(StandardCharsets.UTF_8);
        String head="HTTP/1.1 "+code+(code==200?" OK":" Error")+"\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\nContent-Length: "+b.length+"\r\nConnection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.US_ASCII));out.write(b);out.flush();
    }
    private void handlePairRequest(Socket sock,Runnable linked)throws Exception{
        InputStream in=new BufferedInputStream(sock.getInputStream());OutputStream out=sock.getOutputStream();
        InetAddress peer=sock.getInetAddress();
        if(!peer.isSiteLocalAddress()) {answer(out,403,"Private LAN only");return;}
        String start=line(in);
        if(!"POST /spotify/import HTTP/1.1".equals(start)){
            answer(out,404,"Invalid setup endpoint");return;
        }
        int size=-1;String pin="";boolean origin=false;
        for(int i=0;i<40;i++){
            String h=line(in);if(h.isEmpty())break;
            int colon=h.indexOf(':');if(colon<0)continue;
            String key=h.substring(0,colon).trim();String value=h.substring(colon+1).trim();
            if("Content-Length".equalsIgnoreCase(key)) size=Integer.parseInt(value);
            if("X-TVHome-PIN".equalsIgnoreCase(key))pin=value;
            if("Origin".equalsIgnoreCase(key)) origin=true;
        }
        if(origin || !setupOpen || setupPin==null || !setupPin.equals(pin)){
            if(++badPins>=6)stopPairing();
            answer(out,403,"Invalid PIN");return;
        }
        if(size<5||size>12000){answer(out,413,"Invalid payload size");return;}
        byte[] bytes=new byte[size];int pos=0;
        while(pos<size){int n=in.read(bytes,pos,size-pos);if(n<0)throw new IllegalArgumentException("Short request");pos+=n;}
        JSONObject data=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
        link(data.optString("client_id"),data.optString("access_token"),
                data.optString("refresh_token"),data.optInt("expires_in",3600));
        answer(out,200,"OK: Spotify linked to TVHome");
        stopPairing();
        ui.post(linked);
    }
}
