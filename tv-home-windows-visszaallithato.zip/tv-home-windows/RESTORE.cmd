@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "ADB=%~dp0platform-tools\adb.exe"
set "TV=192.168.0.4:5555"
if not exist "%ADB%" goto missing
set "BACKUP="
set "ORIGINAL="
set "ORIGINALPKG="
set "ORIGINALACT="
if not exist "last-backup.txt" goto missing
set /p "BACKUP=" < "last-backup.txt"
if not defined BACKUP goto missing
if not exist "%BACKUP%\original-home.txt" goto missing
findstr /r /x /c:"[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*/[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*" "%BACKUP%\original-home.txt" > "%BACKUP%\restore-home-validated.txt"
if errorlevel 1 goto missing
set /p "ORIGINAL=" < "%BACKUP%\restore-home-validated.txt"
if not defined ORIGINAL goto missing
echo %ORIGINAL% | findstr /i /c:"ResolverActivity" /c:"ChooserActivity" >nul
if not errorlevel 1 goto missing
echo %ORIGINAL% | findstr /b /c:"com.mihir.tvhome/" >nul
if not errorlevel 1 goto missing
for /f "tokens=1,2 delims=/" %%P in ("%ORIGINAL%") do (
  set "ORIGINALPKG=%%P"
  set "ORIGINALACT=%%Q"
)
if not defined ORIGINALPKG goto missing
if not defined ORIGINALACT goto missing
if "%ORIGINALACT:~0,1%"=="." set "ORIGINALACT=%ORIGINALPKG%%ORIGINALACT%"
set "ORIGINALCANON=%ORIGINALPKG%/%ORIGINALACT%"
echo Restoring Home to: %ORIGINAL%
"%ADB%" connect "%TV%"
"%ADB%" -s "%TV%" get-state > "%BACKUP%\restore-connection.txt" 2>&1
if errorlevel 1 goto failed
findstr /x /c:"device" "%BACKUP%\restore-connection.txt" >nul
if errorlevel 1 goto failed
"%ADB%" -s "%TV%" shell pm path --user 0 "%ORIGINALPKG%" > "%BACKUP%\restore-package-path.txt" 2>&1
if errorlevel 1 goto unavailable
findstr /b /c:"package:" "%BACKUP%\restore-package-path.txt" >nul
if errorlevel 1 goto unavailable
"%ADB%" -s "%TV%" shell pm list packages -e --user 0 "%ORIGINALPKG%" > "%BACKUP%\restore-enabled-packages.txt" 2>&1
if errorlevel 1 goto unavailable
findstr /x /c:"package:%ORIGINALPKG%" "%BACKUP%\restore-enabled-packages.txt" >nul
if errorlevel 1 goto unavailable
"%ADB%" -s "%TV%" shell cmd package set-home-activity --user 0 "%ORIGINAL%" > "%BACKUP%\restore-set-home.txt" 2>&1
if errorlevel 1 goto failed
"%ADB%" -s "%TV%" shell cmd package resolve-activity --brief --user 0 -a android.intent.action.MAIN -c android.intent.category.HOME > "%BACKUP%\restore-resolved-home.txt" 2>&1
if errorlevel 1 goto failed
findstr /r /x /c:"[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*/[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*" "%BACKUP%\restore-resolved-home.txt" > "%BACKUP%\restore-resolved-home-validated.txt"
if errorlevel 1 goto failed
set "RESOLVED="
set "RESOLVEDPKG="
set "RESOLVEDACT="
set /p "RESOLVED=" < "%BACKUP%\restore-resolved-home-validated.txt"
if not defined RESOLVED goto failed
for /f "tokens=1,2 delims=/" %%P in ("%RESOLVED%") do (
  set "RESOLVEDPKG=%%P"
  set "RESOLVEDACT=%%Q"
)
if not defined RESOLVEDPKG goto failed
if not defined RESOLVEDACT goto failed
if "%RESOLVEDACT:~0,1%"=="." set "RESOLVEDACT=%RESOLVEDPKG%%RESOLVEDACT%"
if not "%RESOLVEDPKG%/%RESOLVEDACT%"=="%ORIGINALCANON%" goto wrong_home
"%ADB%" -s "%TV%" shell input keyevent KEYCODE_HOME > "%BACKUP%\restore-home-key.txt" 2>&1
if errorlevel 1 goto failed
echo SUCCESS: Android confirms that the saved original Home is the default again.
echo A Home key was sent. Check that the original screen appears on the TV.
echo TV Home remains installed; no apps were disabled or removed.
echo This restores the Home selection, not a full TV firmware or app-data image.
echo Logs: %BACKUP%
pause
exit /b 0
:unavailable
echo The saved original Home package is missing or disabled on the TV.
echo No apps were enabled, disabled, removed or installed by this restore script.
echo Home was not changed. Keep the backup and share its restore logs.
goto failed
:wrong_home
echo Android did not confirm the saved original Home as the default.
echo Expected: %ORIGINALCANON%
echo Reported: %RESOLVEDPKG%/%RESOLVEDACT%
goto failed
:missing
echo No usable original Home backup or adb.exe was found.
echo Keep the same complete extracted folder used for installation.
goto failed
:failed
echo Restore could not be verified. Do not assume the original screen is active.
echo Keep this folder and share the error text and restore logs with the chat.
pause
exit /b 1
