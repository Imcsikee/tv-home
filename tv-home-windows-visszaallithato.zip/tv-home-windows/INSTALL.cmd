@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "ADB=%~dp0platform-tools\adb.exe"
set "TV=192.168.0.4:5555"
:choose_backup
set "BACKUP=backup\session-%RANDOM%-%RANDOM%"
if exist "%BACKUP%" goto choose_backup
set "RESTORE_BACKUP=%BACKUP%"
if not exist "%ADB%" goto missing
if not exist "tvhome.apk" goto missing
mkdir "%BACKUP%"
if errorlevel 1 goto fail
echo TV Home installer for %TV%
echo The Windows computer must be on the same network as your TV.
echo If the TV asks to allow USB debugging, accept it on the TV.
echo.
"%ADB%" connect "%TV%"
"%ADB%" -s "%TV%" get-state > "%BACKUP%\connection.txt" 2>&1
findstr /x /c:"device" "%BACKUP%\connection.txt" >nul
if not errorlevel 1 goto connected
type "%BACKUP%\connection.txt"
echo.
echo Check that the TV is on and accept its debugging prompt if one appears.
echo Press a key to try once more, or close this window to stop.
pause >nul
"%ADB%" connect "%TV%"
"%ADB%" -s "%TV%" get-state > "%BACKUP%\connection.txt" 2>&1
findstr /x /c:"device" "%BACKUP%\connection.txt" >nul
if errorlevel 1 goto connection_failed
:connected
"%ADB%" -s "%TV%" shell getprop ro.build.version.sdk > "%BACKUP%\android-api.txt" 2> "%BACKUP%\error.txt"
if errorlevel 1 goto fail
findstr /r /x /c:"[0-9][0-9]*" "%BACKUP%\android-api.txt" >nul
if errorlevel 1 goto fail
set /p "API=" < "%BACKUP%\android-api.txt"
if %API% LSS 30 goto too_old
"%ADB%" -s "%TV%" shell getprop ro.product.manufacturer > "%BACKUP%\manufacturer.txt"
"%ADB%" -s "%TV%" shell getprop ro.product.model > "%BACKUP%\model.txt"
echo Connected TV:
type "%BACKUP%\manufacturer.txt"
type "%BACKUP%\model.txt"
echo Android API: %API%
"%ADB%" -s "%TV%" shell cmd package resolve-activity --brief --user 0 -a android.intent.action.MAIN -c android.intent.category.HOME > "%BACKUP%\home-before.txt" 2>&1
findstr /r /x /c:"[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*/[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*" "%BACKUP%\home-before.txt" > "%BACKUP%\original-home.txt"
set "ORIGINAL="
set /p "ORIGINAL=" < "%BACKUP%\original-home.txt"
if not defined ORIGINAL goto backup_failed
echo %ORIGINAL% | findstr /b /c:"com.mihir.tvhome/" >nul
if errorlevel 1 goto validate_original
set "PREVIOUS_BACKUP="
if not exist "last-backup.txt" goto backup_failed
set /p "PREVIOUS_BACKUP=" < "last-backup.txt"
if not defined PREVIOUS_BACKUP goto backup_failed
if not exist "%PREVIOUS_BACKUP%\original-home.txt" goto backup_failed
findstr /r /x /c:"[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*/[a-zA-Z0-9_.$][a-zA-Z0-9_.$]*" "%PREVIOUS_BACKUP%\original-home.txt" > "%BACKUP%\original-home.txt"
if errorlevel 1 goto backup_failed
set "ORIGINAL="
set /p "ORIGINAL=" < "%BACKUP%\original-home.txt"
if not defined ORIGINAL goto backup_failed
set "RESTORE_BACKUP=%PREVIOUS_BACKUP%"
:validate_original
echo %ORIGINAL% | findstr /i /c:"ResolverActivity" /c:"ChooserActivity" >nul
if not errorlevel 1 goto backup_failed
echo %ORIGINAL% | findstr /b /c:"com.mihir.tvhome/" >nul
if not errorlevel 1 goto backup_failed
for /f "tokens=1 delims=/" %%P in ("%ORIGINAL%") do set "ORIGINAL_PACKAGE=%%P"
"%ADB%" -s "%TV%" shell pm path --user 0 "%ORIGINAL_PACKAGE%" > "%BACKUP%\original-package.txt" 2>&1
if errorlevel 1 goto backup_failed
findstr /b /c:"package:" "%BACKUP%\original-package.txt" >nul
if errorlevel 1 goto backup_failed
"%ADB%" -s "%TV%" shell pm list packages -e --user 0 "%ORIGINAL_PACKAGE%" > "%BACKUP%\original-package-enabled.txt" 2>&1
if errorlevel 1 goto backup_failed
findstr /l /x /c:"package:%ORIGINAL_PACKAGE%" "%BACKUP%\original-package-enabled.txt" >nul
if errorlevel 1 goto backup_failed
"%ADB%" -s "%TV%" shell pm list packages -d > "%BACKUP%\disabled-packages-before.txt"
"%ADB%" -s "%TV%" exec-out screencap -p > "%BACKUP%\before.png"
if errorlevel 1 goto backup_failed
for %%F in ("%BACKUP%\before.png") do if %%~zF LSS 8 goto backup_failed
echo %RESTORE_BACKUP%> "last-backup.txt"
findstr /l /x /c:"%RESTORE_BACKUP%" "last-backup.txt" >nul
if errorlevel 1 goto backup_failed
echo.
echo Installing the launcher. No existing apps will be disabled or removed.
"%ADB%" -s "%TV%" install -r "tvhome.apk" > "%BACKUP%\install.txt" 2>&1
if errorlevel 1 goto install_failed
findstr /x /c:"Success" "%BACKUP%\install.txt" >nul
if errorlevel 1 goto install_failed
type "%BACKUP%\install.txt"
"%ADB%" -s "%TV%" shell am start -W -n com.mihir.tvhome/.MainActivity > "%BACKUP%\launch.txt" 2>&1
if errorlevel 1 goto launch_failed
findstr /c:"Status: ok" "%BACKUP%\launch.txt" >nul
if errorlevel 1 goto launch_failed
call :wait_for_launcher
if errorlevel 1 goto launch_failed
echo Setting the new launcher as the Home screen.
"%ADB%" -s "%TV%" shell cmd package set-home-activity --user 0 com.mihir.tvhome/.MainActivity > "%BACKUP%\set-home.txt" 2>&1
if errorlevel 1 goto rollback
"%ADB%" -s "%TV%" shell input keyevent KEYCODE_HOME
if errorlevel 1 goto rollback
call :wait_for_launcher
if errorlevel 1 goto rollback
"%ADB%" -s "%TV%" shell cmd package resolve-activity --brief --user 0 -a android.intent.action.MAIN -c android.intent.category.HOME > "%BACKUP%\home-after.txt" 2>&1
findstr /b /c:"com.mihir.tvhome/" "%BACKUP%\home-after.txt" >nul
if errorlevel 1 goto rollback
:already_home
"%ADB%" -s "%TV%" exec-out screencap -p > "%BACKUP%\after.png"
echo.
echo SUCCESS: TV Home is installed, running and selected as the Home screen.
echo Check the TV: try the remote arrows, open an app, then press Home.
echo Logs and screenshots: %BACKUP%
if exist "last-backup.txt" echo To restore the previous Home screen, run RESTORE.cmd.
if not exist "last-backup.txt" echo No original Home backup exists in this folder; automatic restore is unavailable.
pause
exit /b 0
:wait_for_launcher
for /l %%I in (1,1,5) do (
  "%ADB%" -s "%TV%" shell dumpsys activity activities > "%BACKUP%\activity.txt" 2>&1
  findstr /r /c:"mResumedActivity.*com.mihir.tvhome/" /c:"topResumedActivity.*com.mihir.tvhome/" "%BACKUP%\activity.txt" >nul
  if not errorlevel 1 exit /b 0
  timeout /t 1 /nobreak >nul
)
exit /b 1
:rollback
echo Could not verify the new default Home screen. Restoring the original.
"%ADB%" -s "%TV%" shell cmd package set-home-activity --user 0 "%ORIGINAL%" > "%BACKUP%\rollback.txt" 2>&1
if errorlevel 1 goto rollback_failed
"%ADB%" -s "%TV%" shell input keyevent KEYCODE_HOME
echo Previous Home restore command completed. The new app remains installed.
goto fail
:rollback_failed
echo Automatic restore failed. Run RESTORE.cmd and share the error output.
type "%BACKUP%\rollback.txt"
goto fail
:backup_failed
echo Original Home backup could not be safely completed. Nothing was installed.
echo Home was not changed. Keep this folder and share the error details.
goto fail
:too_old
echo This APK requires Android 11 or newer, API 30. Your TV reports API %API%.
echo Nothing was installed.
goto fail
:connection_failed
type "%BACKUP%\connection.txt"
echo No authorized ADB connection. Nothing was installed.
goto fail
:install_failed
type "%BACKUP%\install.txt"
echo Installation failed. No existing apps were removed and Home was not changed.
goto fail
:launch_failed
type "%BACKUP%\launch.txt"
echo Could not verify that the app opened. Home was not changed.
goto fail
:missing
echo Missing files. Extract the entire ZIP before running INSTALL.cmd.
pause
exit /b 1
:fail
echo.
echo STOPPED. Keep the error text visible or copy it back to the chat.
echo Logs: %BACKUP%
pause
exit /b 1
