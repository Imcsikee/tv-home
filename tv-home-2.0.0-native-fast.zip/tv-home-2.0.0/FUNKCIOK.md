# TV Home 2.0 – natív funkciók a gyors felületen

A korábbi natív csemperajzolás és a legalább öt helyre méretezett dokk maradt az
alap. A funkciók külön osztályokba kerültek; nincs WebView, teljes képernyős élő
blur vagy fókuszváltáskor végzett képfeldolgozás.

## Használat

- **Kedvencek:** Beállítások → Kedvencek szerkesztése. Legfeljebb öt app, hozzáadás,
  eltávolítás és sorrend. Egy appon hosszú OK-val megnyílik a helyi műveletmenü.
- **Áthelyezés:** hosszú OK → Áthelyezés; nyilakkal mozgatás, OK ment, Vissza
  visszavon. A dokk és a rács között is mozgatható az alkalmazás.
- **Elrejtés:** csak ebből a launcherből rejt el; a rendszer alkalmazását nem
  tiltja le. Visszaállítás: Beállítások → Rejtett alkalmazások. Az alkalmazás
  tényleges eltávolítása külön Android-megerősítést kér.
- **Háttérképek:** kiválasztás, saját kép törlésének megerősítése, automatikus
  váltás, 1/5/10/15/30/60 perc, fájlválasztós import. A 12 beépített kép megmarad.
- **Telefonos feltöltés:** Háttérképek → Küldés telefonról. Az ablak ideiglenes,
  PIN-es helyi feltöltőt és QR-kódot nyit; bezáráskor/kilépéskor leáll.
- **PC-s képmappa:** a `PC_WALLPAPER_SERVER.cmd` megoszt egy kiválasztott mappát;
  a tévén a PC helyi IP-címével indítható az ellenőrzött szinkron. Ez csak a
  teljes letöltés és SHA-256-ellenőrzés után cseréli le a saját képmappát.
- **Ambient:** öt perc tétlenség után vagy a vezérlőközpontból. A meglévő
  háttérképet használja órával; az első ébresztő gomb nem indít el egy appot.
- **Megjelenés:** üveg/fényudvar erőssége, animációsebesség és három könnyű
  dokkstílus. A változtatásokhoz nem készül élő blur vagy új képernyő-bitmap.
- **Vezérlőközpont:** Menü gomb vagy Beállítások; Wi-Fi, Bluetooth, bemenetek,
  ambient, következő kép, automatikus váltás, galéria, megjelenés. A rendszer
  által tiltott közvetlen rádiókapcsolásnál a megfelelő Android-panel nyílik meg.
- **Időjárás:** a referencia Szolnok/Hetényi kórház környéki helyszíne maradt.
  Forrásjelölés, részletek, ötperces cache; csak azonosítható friss helyi
  állomásmérés írhatja felül a modellhőmérsékletet. A korábbi adatok jelölve vannak.
- **Spotify:** helyi MediaSession-vezérlés felhasználó által engedélyezett
  értesítés-hozzáféréssel; opcionális Spotify Connect a feltöltött Web API
  megoldás alapján. A `SPOTIFY_PAIR.cmd` egyszeri PKCE-összekapcsolást végez.
  Saját Spotify Client ID és a megfelelő fiók/API-hozzáférés szükséges; jelszó
  vagy client secret nem kerül az appba. A párosítás után a PC bezárható.
- **Telefonos billentyűzet:** az Androidban külön engedélyezendő/kiválasztandó
  valódi IME. Az aktív szövegmezőbe az InputConnection ír; nincs akadálymentesítési
  injektálás. Egy telefon párosítható, a kapcsolat visszavonható. A QR csak az
  inputnézetben készül, nem a kezdőképernyő renderelésekor.

## Teljesítmény és állapot

Appkatalógus, feliratok és ikonok háttérszálon töltődnek; a fókusz csak cache-elt
adatot és natív animációkat használ. A két háttérréteg RGB565 képei legfeljebb
1600 pixelesek. A galéria thumbnail-cache 4 MiB, a borító-cache 512 KiB.
Helyi médialejátszásnál callbackek működnek; hálózati Spotify-lekérés csak
összekapcsolt fiókkal és előtérben fut. A progress legfeljebb másodpercenként
frissül; az időjárás késleltetve, ötperces periódussal indul. Háttérben a
launcher hálózati és animációs frissítései leállnak.

A gyors csomag neve és aláírása megmaradt (`com.mihir.tvhome`), így a frissítés
nem törli az app adatait. A referencia `com.example.tvhome` másik alkalmazás;
annak privát beállításai és Spotify-tokenjei nem olvashatók át automatikusan.
Az eredeti tévékezdőképernyőt és adatait a Windows-frissítő nem módosítja.

20 Android/JVM- és 9 Python-teszt ellenőrzi a fő állapotokat, méretezést,
cache-használatot, valódi JPEG-feltöltést és helyi protokollokat. A fizikai tévé
FPS/RAM-értékeit és az élő Spotify-fiók/Android-jogosultságokat ezek nem mérik.
