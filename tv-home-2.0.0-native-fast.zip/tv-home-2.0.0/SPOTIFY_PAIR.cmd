@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto try_python
py -3 --version >nul 2>&1
if errorlevel 1 goto try_python
py -3 "%~dp0spotify_pair.py" %*
goto done
:try_python
where python >nul 2>&1
if errorlevel 1 goto missing
python "%~dp0spotify_pair.py" %*
goto done
:missing
echo Python 3 is required. Install from https://www.python.org/downloads/windows/
:done
pause
