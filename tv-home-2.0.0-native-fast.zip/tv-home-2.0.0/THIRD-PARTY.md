The application uses ZXing Core 3.5.3 for QR codes, under Apache License 2.0.
Source: https://github.com/zxing/zxing/tree/zxing-3.5.3
The license is included in `assets/licenses/zxing.txt`.

Dependencies are downloaded from Maven Central over verified HTTPS and checked
against the SHA-256 pinned in `prepare-deps.sh`. No AndroidX or web renderer is
included in the app. AndroidX/Robolectric are used only by host tests.
