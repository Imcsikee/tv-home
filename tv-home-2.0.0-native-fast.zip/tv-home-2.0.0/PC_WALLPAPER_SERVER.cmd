@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto try_python
py -3 --version >nul 2>&1
if errorlevel 1 goto try_python
py -3 "%~dp0pc_wallpapers.py" %*
goto done
:try_python
where python >nul 2>&1
if errorlevel 1 goto missing
python --version >nul 2>&1
if errorlevel 1 goto missing
python "%~dp0pc_wallpapers.py" %*
goto done
:missing
echo Python 3 is required. Install Python from https://www.python.org/downloads/windows/
echo Then reopen this helper. No pip packages are required.
:done
pause
