#!/usr/bin/env python3
"""Read-only wallpaper sharing for TV Home; Python standard library only."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
import json
from pathlib import Path
import re
import socket
import sys
import threading
from urllib.parse import urlsplit


PORT = 8765
MAX_FILES = 60
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 180 * 1024 * 1024
EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
PRIVATE_NETWORKS = tuple(ipaddress.ip_network(value) for value in
                         ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8"))


def private_client(value: str) -> bool:
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return False
    return address.version == 4 and any(address in network for network in PRIVATE_NETWORKS)


def safe_name(name: str) -> bool:
    return (0 < len(name.encode("utf-16-le")) // 2 <= 140
            and name not in (".", "..")
            and not any(ch in name for ch in ("/", "\\", "\x00"))
            and not name.lower().startswith("egyedi-")
            and Path(name).suffix.lower() in EXTENSIONS)


@dataclass(frozen=True)
class Wallpaper:
    path: Path
    name: str
    size: int
    sha256: str


class WallpaperCatalog:
    """One manifest per server start; only verified bytes are served later."""
    def __init__(self, directory: Path):
        self.directory = Path(directory).expanduser().resolve(strict=True)
        if not self.directory.is_dir():
            raise ValueError("A megadott útvonal nem mappa.")
        records = []
        names = set()
        total = 0
        for path in sorted(self.directory.iterdir(), key=lambda item: item.name.casefold()):
            if path.suffix.lower() not in EXTENSIONS or not path.is_file():
                continue
            if path.is_symlink() or path.resolve(strict=True).parent != self.directory:
                raise ValueError("A képmappában ne legyen más mappára mutató hivatkozás.")
            if not safe_name(path.name):
                raise ValueError("Nem támogatott képfájlnév: " + path.name)
            key = path.name.casefold()
            if key in names:
                raise ValueError("Kis- és nagybetűben eltérő, azonos fájlnevek vannak a mappában.")
            names.add(key)
            size = path.stat().st_size
            if not 0 < size <= MAX_FILE_BYTES:
                raise ValueError("Minden kép legyen 1 bájt és 16 MiB közötti: " + path.name)
            if len(records) >= MAX_FILES:
                raise ValueError("Legfeljebb 60 kép lehet a megosztott mappában.")
            total += size
            if total > MAX_TOTAL_BYTES:
                raise ValueError("A képek teljes mérete legfeljebb 180 MiB lehet.")
            content = path.read_bytes()
            if len(content) != size or len(content) > MAX_FILE_BYTES:
                raise ValueError("A mappa ellenőrzés közben megváltozott; indítsd újra a kiszolgálót.")
            records.append(Wallpaper(path, path.name, size, hashlib.sha256(content).hexdigest()))
        if not records:
            raise ValueError("A mappába előbb helyezz legalább egy JPG, PNG vagy WebP képet.")
        self.records = tuple(records)
        self.by_hash = {record.sha256: record for record in self.records}
        self.manifest = json.dumps({"files": [
            {"name": record.name, "size": record.size, "sha256": record.sha256}
            for record in self.records
        ]}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(self.manifest) > 128 * 1024:
            raise ValueError("Túl nagy képlista.")

    def verified_bytes(self, digest: str):
        record = self.by_hash.get(digest)
        if record is None:
            raise KeyError(digest)
        path = record.path
        if path.is_symlink() or path.resolve(strict=True).parent != self.directory:
            raise ValueError("A képfájl megváltozott.")
        with path.open("rb") as stream:
            content = stream.read(MAX_FILE_BYTES + 1)
        if len(content) != record.size or hashlib.sha256(content).hexdigest() != digest:
            raise ValueError("A képfájl megváltozott; indítsd újra a kiszolgálót.")
        return record, content


class WallpaperServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, catalog):
        self.catalog = catalog
        self._slots = threading.BoundedSemaphore(8)
        super().__init__(address, WallpaperHandler)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            try:
                request.sendall(b"HTTP/1.1 503 Busy\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()


class WallpaperHandler(BaseHTTPRequestHandler):
    server_version = "TVHomeWallpaper/1"
    protocol_version = "HTTP/1.1"

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, fmt, *args):
        # Do not expose local file paths or add per-request work to the console.
        pass

    def reply(self, code, data=b"", content_type="text/plain; charset=utf-8", head=False):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        if not head:
            try:
                self.wfile.write(data)
            except (OSError, TimeoutError):
                pass

    def do_HEAD(self):
        self.serve(head=True)

    def do_GET(self):
        self.serve()

    def do_POST(self):
        self.reply(405, b"Read-only server")

    def serve(self, head=False):
        if not private_client(self.client_address[0]):
            self.reply(403, b"Private LAN only", head=head)
            return
        path = urlsplit(self.path).path
        if self.path != path:
            self.reply(404, head=head)
            return
        if path == "/manifest":
            self.reply(200, self.server.catalog.manifest, "application/json; charset=utf-8", head)
            return
        match = re.fullmatch(r"/file/([0-9a-f]{64})", path)
        if not match:
            self.reply(404, head=head)
            return
        try:
            record, data = self.server.catalog.verified_bytes(match.group(1))
        except KeyError:
            self.reply(404, head=head)
            return
        except (OSError, ValueError):
            self.reply(409, b"Folder changed; restart the PC server", head=head)
            return
        mime = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}
        self.reply(200, data, mime[record.path.suffix.lower()], head)


def choose_directory():
    try:
        import tkinter
        from tkinter import filedialog
        window = tkinter.Tk()
        window.withdraw()
        try:
            selected = filedialog.askdirectory(title="TV Home – válaszd ki a háttérképek mappáját")
        finally:
            window.destroy()
        if selected:
            return Path(selected)
        raise ValueError("Nem választottál mappát.")
    except ImportError:
        return Path(input("A háttérképek mappájának teljes útvonala: ").strip().strip('"'))


def local_ipv4_addresses():
    try:
        found = {item[4][0] for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)}
    except OSError:
        return []
    return sorted(value for value in found if private_client(value) and not value.startswith("127."))


def main(argv=None):
    parser = argparse.ArgumentParser(description="TV Home: csak olvasható háttérkép-megosztó a helyi hálózaton.")
    parser.add_argument("--directory", type=Path, help="A képek mappája; megadása nélkül mappaválasztó nyílik.")
    args = parser.parse_args(argv)
    try:
        catalog = WallpaperCatalog(args.directory if args.directory else choose_directory())
        with WallpaperServer(("0.0.0.0", PORT), catalog) as server:
            print("TV Home – háttérkép-megosztó")
            print("Megosztott mappa:", catalog.directory)
            print("Képek:", len(catalog.records))
            ips = local_ipv4_addresses()
            if ips:
                print("A tévén a PC címének ezek közül a hálózati IPv4-címet add meg:")
                for address in ips:
                    print("  " + address)
            else:
                print("A PC IPv4-címét a Windows ipconfig parancsával nézheted meg.")
            print("Port: 8765. A tévén: Háttérképek → Mappa frissítése a PC-ről.")
            print("A képekhez itt nem nyúlunk. Új képek után indítsd újra ezt a programot.")
            print("Leállítás: Ctrl+C. Ezt az ablakot a másolás végéig hagyd nyitva.")
            server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        print("\nA megosztó leállt.")
        return 0
    except (OSError, ValueError) as exc:
        print("Nem indult el a megosztó:", str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
