#!/usr/bin/env python3
"""One-time Spotify PKCE pairing. Credentials stay in memory and go only to the selected TV."""
from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import ipaddress
import json
import re
import secrets
import time
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import ProxyHandler, Request, build_opener, urlopen
import webbrowser

REDIRECT = "http://127.0.0.1:8769/callback"
SCOPES = "user-read-playback-state user-read-currently-playing user-modify-playback-state"
NETWORKS = tuple(ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))


def valid_tv(value: str) -> bool:
    try:
        ip = ipaddress.ip_address(value)
        return ip.version == 4 and any(ip in n for n in NETWORKS)
    except ValueError:
        return False


def challenge(verifier: str) -> str:
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest()).rstrip(b"=").decode("ascii")


def authorization_url(client_id: str, verifier: str, state: str) -> str:
    return "https://accounts.spotify.com/authorize?" + urlencode({
        "client_id": client_id, "response_type": "code", "redirect_uri": REDIRECT,
        "code_challenge_method": "S256", "code_challenge": challenge(verifier),
        "state": state, "scope": SCOPES,
    })


class Callback(HTTPServer):
    allow_reuse_address = True

    def __init__(self, state: str, address=("127.0.0.1", 8769)):
        self.expected_state = state
        self.code = None
        self.error = None
        super().__init__(address, CallbackHandler)
        self.timeout = 1


class CallbackHandler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass  # OAuth codes and state must never appear in access logs.

    def do_GET(self):
        route = urlsplit(self.path)
        fields = parse_qs(route.query)
        status = 400
        text = "Érvénytelen visszahívás. Folytasd az eredetileg megnyitott Spotify-ablakban."
        if (route.path == "/callback" and fields.get("state") == [self.server.expected_state]
                and len(self.path) <= 8192):
            if fields.get("error"):
                self.server.error = "A Spotify-belépést megszakítottad."
                text = self.server.error
            elif len(fields.get("code", [])) == 1 and 0 < len(fields["code"][0]) <= 4096:
                self.server.code = fields["code"][0]
                status = 200
                text = "Spotify-belépés kész. Visszatérhetsz a telepítőablakhoz."
        body = ("<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width'>"
                "<title>TV Home Spotify</title><p>" + text + "</p>").encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)


def exchange_code(client_id: str, verifier: str, code: str) -> dict:
    form = urlencode({"grant_type": "authorization_code", "code": code,
                      "redirect_uri": REDIRECT, "client_id": client_id, "code_verifier": verifier})
    request = Request("https://accounts.spotify.com/api/token", data=form.encode("ascii"),
                      headers={"Content-Type": "application/x-www-form-urlencoded"}, method="POST")
    # Default SSL context preserves certificate and hostname verification.
    with urlopen(request, timeout=20) as response:
        raw = response.read(64 * 1024 + 1)
    if len(raw) > 64 * 1024:
        raise ValueError("A Spotify válasza túl nagy.")
    tokens = json.loads(raw)
    if not isinstance(tokens.get("access_token"), str) or not isinstance(tokens.get("refresh_token"), str):
        raise ValueError("A Spotify nem adott újra használható hozzáférést. Indítsd újra a belépést.")
    return tokens


def import_to_tv(tv: str, pin: str, client_id: str, tokens: dict) -> None:
    if not valid_tv(tv) or not re.fullmatch(r"\d{6}", pin) or not re.fullmatch(r"[0-9a-fA-F]{32}", client_id):
        raise ValueError("Érvénytelen tévécím, PIN vagy Client ID.")
    body = json.dumps({"client_id": client_id, "access_token": tokens["access_token"],
                       "refresh_token": tokens["refresh_token"],
                       "expires_in": int(tokens.get("expires_in", 3600))}).encode("utf-8")
    if len(body) > 12000:
        raise ValueError("A párosítási adat túl nagy.")
    request = Request("http://" + tv + ":38763/spotify/import", data=body,
                      headers={"Content-Type": "application/json", "X-TVHome-PIN": pin}, method="POST")
    # Private LAN must be contacted directly; never send these credentials to a configured HTTP proxy.
    with build_opener(ProxyHandler({})).open(request, timeout=15) as response:
        if response.status != 200:
            raise ValueError("A tévé nem fogadta el a párosítást.")
        response.read(1024)


def main() -> int:
    parser = argparse.ArgumentParser(description="TV Home – egyszeri Spotify-összekapcsolás")
    parser.add_argument("--client-id")
    parser.add_argument("--tv")
    args = parser.parse_args()
    print("A tévén: Beállítások → Spotify → Spotify Connect összekapcsolása.")
    print("Spotify Developer Dashboard: saját Web API app, Redirect URI: " + REDIRECT)
    client_id = (args.client_id or input("Spotify Client ID: ")).strip()
    tv = (args.tv or input("Tévé IP-címe [192.168.0.4]: ") or "192.168.0.4").strip()
    pin = getpass.getpass("A tévén látható hatjegyű PIN: ").strip()
    if not re.fullmatch(r"[0-9a-fA-F]{32}", client_id) or not valid_tv(tv) or not re.fullmatch(r"\d{6}", pin):
        raise ValueError("Ellenőrizd a Client ID-t, a helyi tévécímet és a hatjegyű PIN-t.")
    verifier, state = secrets.token_urlsafe(64), secrets.token_urlsafe(32)
    with Callback(state) as server:
        print("Megnyitom a Spotify-belépést. A tévén tartsd nyitva a párosítóablakot.")
        address = authorization_url(client_id, verifier, state)
        if not webbrowser.open(address):
            print("Nyisd meg ezt a belépési címet a böngésződben:\n" + address)
        deadline = time.monotonic() + 180
        while not server.code and not server.error and time.monotonic() < deadline:
            server.handle_request()
        if server.error:
            raise ValueError(server.error)
        if not server.code:
            raise ValueError("A belépés időtúllépéssel leállt. Indítsd újra a párosítást.")
        tokens = exchange_code(client_id, verifier, server.code)
    import_to_tv(tv, pin, client_id, tokens)
    print("Spotify összekapcsolva. Ezt a PC-s ablakot bezárhatod.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except HTTPError as error:
        print("A szolgáltatás visszautasította a kérést (HTTP %s). Ellenőrizd az app hozzáférését és a tévés PIN-t." % error.code)
        raise SystemExit(1)
    except (ValueError, OSError) as error:
        print("Nem sikerült: " + str(error))
        raise SystemExit(1)
    except KeyboardInterrupt:
        print("Párosítás megszakítva.")
        raise SystemExit(1)
