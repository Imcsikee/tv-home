@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0TvHome-Test.ps1" -ApkPath "%~1"
if errorlevel 1 echo A teszt megallt. Ne torold a launchert; olvasd el a fenti hibat.
pause
