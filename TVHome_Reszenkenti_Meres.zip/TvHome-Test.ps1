[CmdletBinding()]
param(
    [string]$ApkPath = '',
    [string]$AdbPath = '',
    [string]$AaptPath = '',
    [ValidatePattern('^(?:\d{1,3}\.){3}\d{1,3}:\d{1,5}$')]
    [string]$TvAddress = '192.168.0.2:5555',
    [ValidateRange(2,5)][int]$Trials = 3,
    [switch]$FunctionsOnly
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:Package = 'com.example.tvhome'
$script:Component = 'com.example.tvhome/.MainActivity'
$script:AdbExecutable = ''
$script:DeviceAddress = $TvAddress
$script:RemoteNav = ''
$script:LogFolder = ''

function Write-Utf8([string]$Path, [string]$Text) {
    [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($false)))
}
function Invoke-Native([string]$Program, [string[]]$Arguments) {
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& $Program @Arguments 2>&1)
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    $text = ($lines | ForEach-Object { $_.ToString() }) -join "`n"
    if ($code -ne 0) { throw "A parancs sikertelen (exit $code): $Program`n$text" }
    return $text
}
function Invoke-Adb([string[]]$Command, [switch]$Global) {
    $items = @('-s', $script:DeviceAddress) + $Command
    if ($Global) { $items = $Command }
    return Invoke-Native -Program $script:AdbExecutable -Arguments $items
}
function Select-LocalFile([string]$Title, [string]$Filter) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = $Title
    $dialog.Filter = $Filter
    $dialog.CheckFileExists = $true
    try {
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            throw 'Nem valasztottal fajlt. Telepites nem tortent.'
        }
        return $dialog.FileName
    } finally { $dialog.Dispose() }
}
function Find-Adb([string]$Chosen) {
    if ($Chosen -and (Test-Path -LiteralPath $Chosen -PathType Leaf)) { return (Resolve-Path -LiteralPath $Chosen).Path }
    $found = Get-Command adb.exe -ErrorAction SilentlyContinue
    if ($null -ne $found) { return $found.Source }
    $candidates = @((Join-Path $PSScriptRoot 'adb.exe'))
    foreach ($root in @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT)) {
        if ($root) { $candidates += Join-Path $root 'platform-tools\adb.exe' }
    }
    if ($env:LOCALAPPDATA) { $candidates += Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe' }
    foreach ($file in $candidates) { if (Test-Path -LiteralPath $file -PathType Leaf) { return $file } }
    return Select-LocalFile 'Valaszd ki az adb.exe fajlt (Android SDK / platform-tools)' 'Android ADB (adb.exe)|adb.exe'
}
function Find-Aapt([string]$Chosen, [string]$Adb) {
    if ($Chosen -and (Test-Path -LiteralPath $Chosen -PathType Leaf)) { return (Resolve-Path -LiteralPath $Chosen).Path }
    $roots = @((Split-Path (Split-Path $Adb -Parent) -Parent), $env:ANDROID_HOME, $env:ANDROID_SDK_ROOT)
    if ($env:LOCALAPPDATA) { $roots += Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
    foreach ($root in $roots) {
        if (-not $root) { continue }
        $buildTools = Join-Path $root 'build-tools'
        if (-not (Test-Path -LiteralPath $buildTools -PathType Container)) { continue }
        foreach ($version in @(Get-ChildItem -LiteralPath $buildTools -Directory | Sort-Object Name -Descending)) {
            foreach ($name in @('aapt2.exe','aapt.exe')) {
                $candidate = Join-Path $version.FullName $name
                if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
            }
        }
    }
    return Select-LocalFile 'APK ellenorzes: valaszd ki az aapt2.exe vagy aapt.exe fajlt (SDK / build-tools / verzio)' 'Android build tool|aapt2.exe;aapt.exe'
}
function Get-ApkIdentity([string]$Tool, [string]$Path) {
    $info = Invoke-Native -Program $Tool -Arguments @('dump','badging',$Path)
    $match = [regex]::Match($info, "(?m)^package: name='([^']+)' versionCode='(\d+)' versionName='([^']*)'")
    if (-not $match.Success) { throw 'Az APK csomagneve/verzioja nem olvashato. Telepites nem tortent.' }
    if ($match.Groups[1].Value -ne $script:Package) { throw "Ez az APK nem a com.example.tvhome alkalmazas. Telepites leallitva." }
    return [pscustomobject]@{ Package=$match.Groups[1].Value; VersionCode=[long]$match.Groups[2].Value; VersionName=$match.Groups[3].Value }
}
function Save-InstalledApks([string]$Folder) {
    $response = Invoke-Adb -Command @('shell','pm','path',$script:Package)
    $paths = @($response -split '\r?\n' | Where-Object { $_ -match '^package:' } | ForEach-Object { $_.Substring(8).Trim() })
    if ($paths.Count -eq 0) { throw 'A com.example.tvhome jelenleg nincs telepitve. Nincs merheto kiindulo verzio.' }
    New-Item -ItemType Directory -Path $Folder -Force | Out-Null
    $index=0
    foreach ($path in $paths) {
        $file = Join-Path $Folder ('installed_{0:D2}.apk' -f $index)
        Invoke-Adb -Command @('pull',$path,$file) | Out-Null
        if (-not (Test-Path -LiteralPath $file) -or (Get-Item -LiteralPath $file).Length -eq 0) { throw 'Nem sikerult elmenteni a jelenlegi APK-t. Frissites leallitva.' }
        $index++
    }
    Write-Utf8 (Join-Path $Folder 'apk-paths.txt') ($paths -join "`r`n")
}
function Assert-LauncherForeground {
    $state = Invoke-Adb -Command @('shell','dumpsys','activity','activities')
    if ($state -notmatch '(?m)(?:mResumedActivity|topResumedActivity)[^\r\n]*com\.example\.tvhome/') {
        Write-Utf8 (Join-Path $script:LogFolder 'foreground-error.txt') $state
        throw 'A TVHome nincs eloterben (peldaul TV-rendszermenu vagy engedelykeres takarja). A meres megallt.'
    }
}
function Start-Home {
    $text = Invoke-Adb -Command @('shell','am','start','-W','-a','android.intent.action.MAIN','-c','android.intent.category.HOME','-n',$script:Component)
    if ($text -match '(?im)^\s*(Error|Exception|SecurityException)') { throw "A launcher nem indithato: $text" }
    return $text
}
function Read-Number([string]$Text,[string]$Pattern) {
    $match=[regex]::Match($Text,$Pattern)
    if ($match.Success) { return [double]::Parse($match.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture) }
    return $null
}
function Read-Metrics([string]$Phase,[int]$Trial,[string]$Graphics,[string]$Memory,[string]$Launch) {
    $frames=Read-Number $Graphics '(?m)^Total frames rendered:\s*(\d+)'
    if ($null -eq $frames -or $frames -lt 20) { throw 'Tul keves/olvashatatlan kepkocka a mereshez. Az eredmenyt nem tekintjuk ervenyes tesztnek.' }
    $pss=Read-Number $Memory 'TOTAL PSS:\s*(\d+)'
    if ($null -eq $pss) { $pss=Read-Number $Memory '(?m)^\s*TOTAL\s+(\d+)\s' }
    $rss=Read-Number $Memory 'TOTAL RSS:\s*(\d+)'
    return [pscustomobject][ordered]@{
        Phase=$Phase; Trial=$Trial; Frames=$frames
        JankyPercent=(Read-Number $Graphics '(?m)^Janky frames:\s*\d+\s*\(([\d.]+)%\)')
        FrameP50ms=(Read-Number $Graphics '(?m)^50th percentile:\s*(\d+)ms')
        FrameP95ms=(Read-Number $Graphics '(?m)^95th percentile:\s*(\d+)ms')
        FrameP99ms=(Read-Number $Graphics '(?m)^99th percentile:\s*(\d+)ms')
        GpuP95ms=(Read-Number $Graphics '(?m)^95th gpu percentile:\s*(\d+)ms')
        PssMiB=$(if ($null -ne $pss) { [math]::Round($pss/1024,2) } else { $null })
        RssMiB=$(if ($null -ne $rss) { [math]::Round($rss/1024,2) } else { $null })
        StartTotalMs=(Read-Number $Launch '(?m)^TotalTime:\s*(\d+)')
    }
}
function Measure-Launcher([string]$Phase,[int]$Trial) {
    Write-Host "[$Phase $Trial/$Trials] Inditas es azonos bemelegites..." -ForegroundColor Cyan
    Invoke-Adb -Command @('shell','am','force-stop',$script:Package) | Out-Null
    $launch=Start-Home
    Write-Utf8 (Join-Path $script:LogFolder "$Phase-$Trial-start.txt") $launch
    Start-Sleep -Seconds 20
    Assert-LauncherForeground
    Invoke-Adb -Command @('shell','sh',$script:RemoteNav) | Out-Null
    Start-Home | Out-Null
    Start-Sleep -Seconds 3
    Assert-LauncherForeground
    Invoke-Adb -Command @('shell','dumpsys','gfxinfo',$script:Package,'reset') | Out-Null
    Write-Host "[$Phase $Trial/$Trials] Automatikus dokk / appracs / vezerlopult teszt..."
    Invoke-Adb -Command @('shell','sh',$script:RemoteNav) | Out-Null
    Start-Sleep -Seconds 3
    Assert-LauncherForeground
    $graphics=Invoke-Adb -Command @('shell','dumpsys','gfxinfo',$script:Package,'framestats')
    $memory=Invoke-Adb -Command @('shell','dumpsys','meminfo',$script:Package)
    Write-Utf8 (Join-Path $script:LogFolder "$Phase-$Trial-gfxinfo.txt") $graphics
    Write-Utf8 (Join-Path $script:LogFolder "$Phase-$Trial-meminfo.txt") $memory
    return Read-Metrics $Phase $Trial $graphics $memory $launch
}
function Get-Median($Values) {
    $items=@($Values | Where-Object { $null -ne $_ } | Sort-Object)
    if ($items.Count -eq 0) { return $null }
    $middle=[int][math]::Floor($items.Count/2)
    if ($items.Count % 2) { return [double]$items[$middle] }
    return ([double]$items[$middle-1]+[double]$items[$middle])/2
}
function Write-Summary($Rows,[string]$Path) {
    $lines=@('TVHome - telepites elotti / utani meres', '',
        'Azonos navigacio es bemelegites; verzionkent harom futas alapertelmezetten.',
        'Az alacsonyabb kepkockaido es PSS kedvezobb. A Frames darabszam, nem FPS.',
        'StartTotalMs: folyamat-ujrainditas AM ideje; nem hideg lemezcache vagy teljes betoltodes.',
        'A framestats resz csak a legutobbi kepkockakat tarolja, a fenti osszesito a reset utani futast.', '',
        'Mutato                 ELOTTE median     UTANA median       Valtozas',
        '-----------------------------------------------------------------------')
    foreach ($key in @('FrameP50ms','FrameP95ms','FrameP99ms','GpuP95ms','JankyPercent','PssMiB','RssMiB','StartTotalMs','Frames')) {
        $before=Get-Median @($Rows | Where-Object Phase -eq 'ELOTTE' | ForEach-Object { $_.$key })
        $after=Get-Median @($Rows | Where-Object Phase -eq 'UTANA' | ForEach-Object { $_.$key })
        $difference='n/a'
        if ($null -ne $before -and $null -ne $after) {
            if ($key -eq 'JankyPercent') { $difference=('{0:+0.00;-0.00;0.00} szazalekpont' -f ($after-$before)) }
            elseif ($before -gt 0) { $difference=('{0:+0.0;-0.0;0.0}%' -f (100*($after-$before)/$before)) }
        }
        $lines += ('{0,-22} {1,14} {2,16} {3,19}' -f $key,$before,$after,$difference)
    }
    $lines += @('', 'Reszletes eredmenyek: metrics.csv es az egyes futasok naploi.',
        'Ez nem bizonyit minden helyzetben gyorsulast. A hatterkep, Spotify, ho/terheles',
        'es a futasok kozti szoras is szamit. A meres alatt latott eltarest is jelezd.',
        'Az uj APK telepitve van; az alkalmazas adatait a seged nem torolte.')
    Write-Utf8 $Path ($lines -join "`r`n")
}
function Install-Update([string]$Path) {
    $output=Invoke-Adb -Command @('install','-r',$Path)
    Write-Utf8 (Join-Path $script:LogFolder 'install.txt') $output
    if ($output -notmatch '(?m)^\s*Success\s*$') { throw "A frissites sikertelen. Ne tavolitsd el az alkalmazast: $output" }
}
function Invoke-TvHomeTest {
    $ip=$null
    if (-not [Net.IPAddress]::TryParse(($TvAddress -split ':')[0],[ref]$ip) -or [int]($TvAddress -split ':')[1] -gt 65535) { throw 'Hibas TV-cim.' }
    if (-not $ApkPath) { $ApkPath=Select-LocalFile 'Valaszd ki a NEGY optimalizalt forrasbol forditott UJ APK-t' 'Android APK (*.apk)|*.apk' }
    $ApkPath=(Resolve-Path -LiteralPath $ApkPath).Path
    $script:AdbExecutable=Find-Adb $AdbPath
    $tool=Find-Aapt $AaptPath $script:AdbExecutable
    $candidate=Get-ApkIdentity $tool $ApkPath
    $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
    $root=Join-Path $PSScriptRoot "TVHOME_MERES_$stamp"
    $script:LogFolder=Join-Path $root 'eredmenyek'
    New-Item -ItemType Directory -Path $script:LogFolder -Force | Out-Null
    $candidate | Add-Member -NotePropertyName SHA256 -NotePropertyValue (Get-FileHash -LiteralPath $ApkPath -Algorithm SHA256).Hash
    Write-Utf8 (Join-Path $script:LogFolder 'new-apk.json') ($candidate | ConvertTo-Json)
    Invoke-Adb -Global -Command @('connect',$TvAddress) | Write-Host
    if ((Invoke-Adb -Command @('get-state')).Trim() -ne 'device') { throw 'Nincs engedelyezett ADB-kapcsolat. Ellenorizd a TV-n az engedelykerest es az IP-cimet.' }
    $oldPackage=Invoke-Adb -Command @('shell','dumpsys','package',$script:Package)
    Write-Utf8 (Join-Path $script:LogFolder 'package-before.txt') $oldPackage
    $oldVersion=Read-Number $oldPackage '\bversionCode=(\d+)'
    if ($null -ne $oldVersion -and $candidate.VersionCode -lt $oldVersion) { throw 'Az uj APK verzioszama kisebb a telepitettnel. A seged nem vegez visszalepest es nem torol adatot.' }
    Write-Host 'Jelenlegi APK mentese...' -ForegroundColor Cyan
    Save-InstalledApks (Join-Path $root 'regi-apk-mentes')
    $savedBase=Join-Path $root 'regi-apk-mentes\installed_00.apk'
    if ((Get-FileHash -LiteralPath $savedBase -Algorithm SHA256).Hash -eq $candidate.SHA256) {
        throw 'Pontosan ez az APK mar fent van a TV-n. A regivel valo osszehasonlitashoz masik kiindulo verzio kell; ne torold az appot.'
    }
    $device=@("TV: $TvAddress")
    foreach ($property in @('ro.product.model','ro.build.version.release','ro.build.version.sdk','ro.hardware')) {
        $device += $property+': '+(Invoke-Adb -Command @('shell','getprop',$property))
    }
    foreach ($setting in @('window_animation_scale','transition_animation_scale','animator_duration_scale')) {
        $device += $setting+': '+(Invoke-Adb -Command @('shell','settings','get','global',$setting))
    }
    $device += Invoke-Adb -Command @('shell','wm','size')
    Write-Utf8 (Join-Path $script:LogFolder 'device.txt') ($device -join "`r`n")
    $script:RemoteNav="/data/local/tmp/tvhome_measure_$stamp.sh"
    $localNav=Join-Path $script:LogFolder 'navigation.sh'
    # No OK, ENTER, HOME, media command or long press: only focus, grid and menu navigation.
    $nav="#!/system/bin/sh`nset -e`nfor key in 22 22 21 21 20 22 22 20 21 19 4 82 20 22 20 21 19 4; do`n  input keyevent `"`$key`"`n  sleep 0.6`ndone`n"
    Write-Utf8 $localNav $nav
    Invoke-Adb -Command @('push',$localNav,$script:RemoteNav) | Out-Null
    Write-Host "`nTV: $TvAddress; cel: com.example.tvhome" -ForegroundColor Green
    Write-Host 'Kb. 6-10 perc. A teszt automatikusan navigal, majd frissiti az alkalmazast.'
    Write-Host 'Legyen bekapcsolva a TV. Kozben ne nyomd a taviranyitot es ne valtoztass beallitast.'
    Write-Host 'Spotify mindket verzional azonos allapotban legyen (peldaul ugyanaz a hosszu zene).'
    Write-Host 'A regi APK mentve; a frissites az adatokat megtarto install -r parancsot hasznalja.'
    Read-Host 'Ha a TV keszen all, nyomj Entert' | Out-Null
    Invoke-Adb -Command @('shell','input','keyevent','KEYCODE_WAKEUP') | Out-Null
    $rows=New-Object 'System.Collections.Generic.List[object]'
    try {
        for($run=1;$run -le $Trials;$run++) {
            $rows.Add((Measure-Launcher 'ELOTTE' $run))
            $rows | Export-Csv -LiteralPath (Join-Path $script:LogFolder 'metrics.csv') -NoTypeInformation -Encoding UTF8
        }
        Write-Host "`nA regi verzio merese kesz. Az UJ APK telepitese..." -ForegroundColor Cyan
        if ((Get-FileHash -LiteralPath $ApkPath -Algorithm SHA256).Hash -ne $candidate.SHA256) {
            throw 'A kivalasztott APK megvaltozott a meres kozben. Telepites leallitva.'
        }
        Install-Update $ApkPath
        Write-Utf8 (Join-Path $script:LogFolder 'package-after.txt') (Invoke-Adb -Command @('shell','dumpsys','package',$script:Package))
        for($run=1;$run -le $Trials;$run++) {
            $rows.Add((Measure-Launcher 'UTANA' $run))
            $rows | Export-Csv -LiteralPath (Join-Path $script:LogFolder 'metrics.csv') -NoTypeInformation -Encoding UTF8
        }
        Write-Summary $rows (Join-Path $script:LogFolder 'OSSZEHASONLITAS.txt')
    } catch {
        Write-Utf8 (Join-Path $script:LogFolder 'HIBA.txt') $_.ToString()
        throw
    } finally {
        try { Invoke-Adb -Command @('shell','rm','-f',$script:RemoteNav) | Out-Null } catch { Write-Warning 'A tavoli ideiglenes meroszkript nem torolheto.' }
        $zip=Join-Path $root 'TVHOME_MERES_EREDMENY.zip'
        Compress-Archive -Path (Join-Path $script:LogFolder '*') -DestinationPath $zip -Force
        Write-Host "`nEREDMENYFAJL: $zip" -ForegroundColor Yellow
        Write-Host 'Ezt a ZIP-et kuldd vissza a beszelgetesbe. Az APK-mentes kulon mappaban van.'
    }
    Get-Content -LiteralPath (Join-Path $script:LogFolder 'OSSZEHASONLITAS.txt') | Write-Host
}
if ($FunctionsOnly) { return }
try { Invoke-TvHomeTest } catch { Write-Host "`nHIBA: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
