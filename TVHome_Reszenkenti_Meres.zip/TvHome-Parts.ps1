param([string]$TvAddress='192.168.0.2:5555',[string]$AdbPath='', [switch]$FunctionsOnly)
$partsFunctionsOnly=$FunctionsOnly
. (Join-Path $PSScriptRoot 'TvHome-Test.ps1') -FunctionsOnly -TvAddress $TvAddress -AdbPath $AdbPath

function Get-PartKeys([string]$Part) {
    switch ($Part) {
        'DOKK' { return @(22,22,21,21,22,22,21,21,22,22,21,21) }
        'RACS' { return @(22,22,20,21,21,19,22,22,20,21,21,19) }
        'VEZERLOPULT' { return @(20,22,20,21,20,22,19,21,19,22,19,21) }
        default { throw 'Ismeretlen reszteszt.' }
    }
}
function Open-Part([string]$Part) {
    Start-Home | Out-Null
    Start-Sleep -Seconds 2
    if($Part -eq 'RACS') { Invoke-Adb -Command @('shell','input','keyevent','20') | Out-Null }
    if($Part -eq 'VEZERLOPULT') { Invoke-Adb -Command @('shell','input','keyevent','82') | Out-Null }
    Start-Sleep -Seconds 2
    Assert-LauncherForeground
}
function Read-PartMetrics([string]$Part,[int]$Trial,[string]$Graphics,[string]$Memory) {
    $row=Read-Metrics $Part $Trial $Graphics $Memory ''
    # This TV reports its GPU overflow bucket as 4950 ms. It is not an exact duration.
    if($null -ne $row.GpuP95ms -and $row.GpuP95ms -ge 4950) { $row.GpuP95ms=$null }
    return $row | Select-Object Phase,Trial,Frames,JankyPercent,FrameP50ms,FrameP95ms,FrameP99ms,GpuP95ms,PssMiB,RssMiB
}
function Invoke-Parts {
    if(-not $AdbPath -and (Test-Path 'C:\tv')) {
        $candidate=Get-ChildItem -Path 'C:\tv\scrcpy*\adb.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
        if($null -ne $candidate) { $AdbPath=$candidate.FullName }
    }
    $script:AdbExecutable=Find-Adb $AdbPath
    $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
    $root=Join-Path $PSScriptRoot "RESZTESZT_$stamp"
    $script:LogFolder=Join-Path $root 'naplok'
    New-Item -ItemType Directory -Path $script:LogFolder -Force | Out-Null
    Invoke-Adb -Global -Command @('connect',$TvAddress) | Write-Host
    if((Invoke-Adb -Command @('get-state')).Trim() -ne 'device') { throw 'Nincs ADB-kapcsolat a TV-vel.' }
    Write-Host 'Zard be a scrcpy kepet mutato ablakot. A TV-t hagyd bekapcsolva.' -ForegroundColor Yellow
    Write-Host 'Csak a jelenleg telepitett TVHome-ot merjuk. Nem kell APK vagy aapt.'
    Write-Host 'Kb. 4-6 percig ne nyomd a taviranyitot; ne valtoztass zenet vagy hatterkepet.'
    Read-Host 'Ha keszen allsz, nyomj Entert' | Out-Null
    Invoke-Adb -Command @('shell','input','keyevent','KEYCODE_WAKEUP') | Out-Null
    Start-Home | Out-Null
    Start-Sleep -Seconds 20
    Write-Utf8 (Join-Path $script:LogFolder 'package.txt') (Invoke-Adb -Command @('shell','dumpsys','package',$script:Package))
    Write-Utf8 (Join-Path $script:LogFolder 'display.txt') (Invoke-Adb -Command @('shell','wm','size'))
    $rows=New-Object 'System.Collections.Generic.List[object]'
    $remotes=New-Object 'System.Collections.Generic.List[string]'
    try {
        $parts=@('DOKK','RACS','VEZERLOPULT')
        foreach($part in $parts) {
            $keys=(Get-PartKeys $part) -join ' '
            $nav="#!/system/bin/sh`nset -e`nfor key in $keys; do`n input keyevent `"`$key`"`n sleep 0.6`ndone`n"
            $local=Join-Path $script:LogFolder "$part.sh"
            Write-Utf8 $local $nav
            $remote="/data/local/tmp/tvhome_part_${stamp}_$part.sh"
            $remotes.Add($remote)
            Invoke-Adb -Command @('push',$local,$remote) | Out-Null
        }
        # Rotate order so one section is not always tested first/last.
        for($trial=1;$trial -le 3;$trial++) {
            for($index=0;$index -lt 3;$index++) {
                $part=$parts[($index+$trial-1)%3]
                $remote="/data/local/tmp/tvhome_part_${stamp}_$part.sh"
                Write-Host "[$trial/3] $part - bemelegites es meres" -ForegroundColor Cyan
                Open-Part $part
                Invoke-Adb -Command @('shell','sh',$remote) | Out-Null
                Open-Part $part
                Invoke-Adb -Command @('shell','dumpsys','gfxinfo',$script:Package,'reset') | Out-Null
                Invoke-Adb -Command @('shell','sh',$remote) | Out-Null
                Start-Sleep -Seconds 2
                Assert-LauncherForeground
                $graphics=Invoke-Adb -Command @('shell','dumpsys','gfxinfo',$script:Package,'framestats')
                $memory=Invoke-Adb -Command @('shell','dumpsys','meminfo',$script:Package)
                Write-Utf8 (Join-Path $script:LogFolder "$part-$trial-gfxinfo.txt") $graphics
                Write-Utf8 (Join-Path $script:LogFolder "$part-$trial-meminfo.txt") $memory
                $rows.Add((Read-PartMetrics $part $trial $graphics $memory))
                $rows | Export-Csv -LiteralPath (Join-Path $script:LogFolder 'metrics.csv') -NoTypeInformation -Encoding UTF8
            }
        }
        Start-Home | Out-Null
        Write-Host 'KESZ. Mindharom reszrol harom meres keszult.' -ForegroundColor Green
    } catch {
        Write-Utf8 (Join-Path $script:LogFolder 'HIBA.txt') $_.ToString()
        throw
    } finally {
        foreach($remote in $remotes) {
            try { Invoke-Adb -Command @('shell','rm','-f',$remote) | Out-Null } catch { Write-Warning 'Ideiglenes szkript a TV-n maradt.' }
        }
        $zip=Join-Path $root 'TVHOME_RESZTESZT_EREDMENY.zip'
        Compress-Archive -Path (Join-Path $script:LogFolder '*') -DestinationPath $zip -Force
        Write-Host "`nEzt kuldd vissza: $zip" -ForegroundColor Yellow
    }
}
if($partsFunctionsOnly){return}
try { Invoke-Parts } catch { Write-Host "HIBA: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
