@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "ADB=%~dp0platform-tools\adb.exe"
set "TV=192.168.0.4:5555"
:choose_log
set "LOG=update-logs\session-%RANDOM%-%RANDOM%"
if exist "%LOG%" goto choose_log
if not exist "%ADB%" goto missing
if not exist "tvhome.apk" goto missing
mkdir "%LOG%"
if errorlevel 1 goto failed
echo TV Home 1.0.1 - fix for oversized YouTube tile
echo This updates the existing app. Original Home backups are not changed.
echo Keep your ORIGINAL installation folder for RESTORE.cmd and its backups.
echo.
"%ADB%" connect "%TV%"
"%ADB%" -s "%TV%" get-state > "%LOG%\connection.txt" 2>&1
findstr /x /c:"device" "%LOG%\connection.txt" >nul
if not errorlevel 1 goto connected
type "%LOG%\connection.txt"
echo Accept the debugging prompt on the TV, if shown, then press a key to retry.
pause >nul
"%ADB%" connect "%TV%"
"%ADB%" -s "%TV%" get-state > "%LOG%\connection.txt" 2>&1
findstr /x /c:"device" "%LOG%\connection.txt" >nul
if errorlevel 1 goto failed
:connected
"%ADB%" -s "%TV%" shell pm path --user 0 com.mihir.tvhome > "%LOG%\existing-app.txt" 2>&1
if errorlevel 1 goto not_installed
findstr /b /c:"package:" "%LOG%\existing-app.txt" >nul
if errorlevel 1 goto not_installed
"%ADB%" -s "%TV%" shell wm size > "%LOG%\screen-size.txt" 2>&1
"%ADB%" -s "%TV%" shell wm density > "%LOG%\screen-density.txt" 2>&1
"%ADB%" -s "%TV%" install -r "tvhome.apk" > "%LOG%\install.txt" 2>&1
if errorlevel 1 goto install_failed
findstr /x /c:"Success" "%LOG%\install.txt" >nul
if errorlevel 1 goto install_failed
"%ADB%" -s "%TV%" shell dumpsys package com.mihir.tvhome > "%LOG%\installed-version.txt" 2>&1
if errorlevel 1 goto failed
findstr /c:"versionName=1.0.1" "%LOG%\installed-version.txt" >nul
if errorlevel 1 goto failed
"%ADB%" -s "%TV%" shell am force-stop com.mihir.tvhome
if errorlevel 1 goto failed
"%ADB%" -s "%TV%" shell am start -W -n com.mihir.tvhome/.MainActivity > "%LOG%\launch.txt" 2>&1
if errorlevel 1 goto launch_failed
findstr /c:"Status: ok" "%LOG%\launch.txt" >nul
if errorlevel 1 goto launch_failed
timeout /t 2 /nobreak >nul
"%ADB%" -s "%TV%" exec-out screencap -p > "%LOG%\after-update.png"
echo.
echo SUCCESS: TV Home 1.0.1 installed and opened. Check the tile size on the TV.
echo Your default Home selection and original Home backup were not changed.
echo To restore the stock screen, use RESTORE.cmd in your ORIGINAL installer folder.
echo Logs and screenshot: %LOG%
pause
exit /b 0
:not_installed
echo The existing TV Home app was not found. No update was installed.
goto failed
:install_failed
type "%LOG%\install.txt"
echo Update failed. No app was removed. Keep the error text.
goto failed
:launch_failed
type "%LOG%\launch.txt"
goto failed
:missing
echo Missing files. Extract the entire ZIP before running UPDATE.cmd.
pause
exit /b 1
:failed
echo.
echo STOPPED. Copy the error text back to the chat.
echo Your original Home backup has not been changed.
echo Logs: %LOG%
pause
exit /b 1
