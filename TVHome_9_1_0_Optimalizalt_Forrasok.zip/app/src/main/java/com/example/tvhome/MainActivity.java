package com.example.tvhome;

import android.app.Activity;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.animation.ValueAnimator;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.media.tv.TvContract;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Outline;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.BlurMaskFilter;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.widget.EditText;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.security.SecureRandom;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InterfaceAddress;
import java.security.MessageDigest;
import java.util.Locale;
import org.json.JSONObject;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Calendar;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;

/**
 * TV Home 7.5 - Telefonos hatterkepek es biztonsagos galeria torles.
 * Megtartja a 7.4 mukodo QR-feltolteset es a ZXing-fuggoseget.
 * A valaszto es a valtakozo hatter is CSAK a sajat wallpapers mappabol olvas.
 * Nem ker TV-s kepolvasasi engedelyt, es nem csinal 'egyedi-' masolatokat.
 */
public class MainActivity extends Activity {

    // Elso inditaskor ezt a listat toltjuk be. Utana a TV mentett listaja ervenyes.
    private static final String[] DEFAULT_FAVS = {
            "com.netflix.ninja",
            "com.google.android.youtube.tv",
            "com.spotify.tv.android",
            "com.android.vending",
            "com.mediatek.wwtv.tvcenter"
    };

    // TVHome 7.1: tovabbra is 10 perc az alap, de menurol modosithato.
    private static final int[] WALLPAPER_INTERVAL_OPTIONS = {1, 5, 10, 15, 30, 60};
    private static final String PREF_WALLPAPER_INTERVAL = "wallpaper_interval_minutes_v71";
    private int wallpaperIntervalMinutes = 10;
    private long wallpaperIntervalMs() { return wallpaperIntervalMinutes * 60L * 1000L; }
    private static final long WALLPAPER_FADE_MS = 1100L;
    private static final int WALLPAPER_MAX_SIDE = 1600;
    private static final String TAG = "TvHome";
    // 9.0.9: the Sources drop-down shares the existing modal navigation,
    // but is anchored beside its header button instead of centered.
    private static final String SOURCES_MENU_TAG = "tvhome_sources_dropdown_v909";
    private static final String PREFS_NAME = "tvhome_settings";
    private static final String PREFS_FAVS = "dock_favorites_v1";
    // Legfeljebb 5 alkalmazas a dokkban; a tobbi az appracsban marad.
    private static final int MAX_FAVS = 5;
    // 6.9.1: dokk alatti, kulon panel es cim nelkuli appracs.
    // A dokk elemei 3 dp bal/jobb margot hasznalnak: 6 dp a csempek koze.
    private static final int GRID_COLUMNS = 5;
    private static final int GRID_CARD_GAP_DP = 6;
    private static final int GRID_ROW_GAP_DP = 16;
    // 18 dp oldalmargo: az otoszlopos racs pontosan a dokk elso
    // es utolso csempejenek vizszintes hataraihoz igazodik.
    private static final int GRID_SIDE_INSET_DP = 18;
    private static final int GRID_TOP_PADDING_DP = 20;
    private static final int GRID_BOTTOM_PADDING_DP = 10;
    private int gridContentWidthDp = 810;
    private int gridVisibleColumns = GRID_COLUMNS;
    // A TVOS kartya szelessege : magassaga = 3 : 2, a dokkhoz hasonloan.
    // A GridView meretet a TV kepernyojen elfero hat oszlop alapjan szamoljuk.
    private int appGridCardHeightDp = 100;
    private int appGridRowHeightDp = 139;
    private static final String PREF_APP_ORDER = "app_order_v6";
    private static final String PREF_DOCK_SLOTS = "dock_slots_v6";
    // 7.5: külön tároljuk a rejtett appokat, nem távolítjuk el őket a TV-ről.
    private static final String PREF_HIDDEN_APPS = "hidden_apps_v75";
    private final HashSet<String> hiddenPackages = new HashSet<>();
    private final ArrayList<String> appOrder = new ArrayList<>();
    private final HashMap<String, ResolveInfo> appMetadata = new HashMap<>();
    // 9.0.2: az appcimeket nem kerjuk le ujra minden taviranyitos fokuszvaltasnal.
    // Kis meretu gyorsitotar: legfeljebb a telepitett appok darabszama.
    private final HashMap<String, String> appLabelCache = new HashMap<>();
    private final HashMap<String, Drawable> bannerCache = new HashMap<>();
    private boolean orderReady = false;
    private int dockSlots = 0;
    private boolean moving = false;
    private String movingPackage = null;
    private ArrayList<String> beforeMove = null;
    private int gridFocusIndexOnOpen = 0;
    private int previousGridSelection = -1;
    private String pressedPackage = null;
    private int pressedConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
    private boolean longPressOpened = false;
    private Runnable longPressRunnable;
    private int gridNavKey = KeyEvent.KEYCODE_UNKNOWN;
    // TVHome 6.3: egyetlen rovid, memoria-kimelo mozgasi stilus.
    // Live animation profile. Normal mode uses exactly the v6.6 timings.
    private long FOCUS_MS = 175L;
    private long PANEL_MS = 195L;
    private long SCROLL_MS = 235L;
    private static final String PREF_GLASS_STRENGTH = "appearance_glass_v67";
    private static final String PREF_GLOW_STRENGTH = "appearance_glow_v67";
    private static final String PREF_ANIMATION_SPEED = "appearance_anim_v67";
    private static final String PREF_DOCK_STYLE = "appearance_dock_v67";
    private static final int BASE_GLASS = 70;
    private static final int BASE_GLOW = 45;
    // Default values deliberately preserve the TVHome 6.6 look.
    private int glassStrength = BASE_GLASS;
    private int glowStrength = BASE_GLOW;
    private int animationSpeed = 1; // 0 fast, 1 normal, 2 slow
    private int dockStyle = 0;      // 0 liquid, 1 clear, 2 frosted
    private FrameLayout appearanceOverlay;
    private final ArrayList<TextView> appearanceOptions = new ArrayList<>();
    private int appearanceFocusIndex = 0;
    private final DecelerateInterpolator tvEase = new DecelerateInterpolator(1.35f);
    private ValueAnimator homeScrollAnimator;
    // Nem engedunk egymasra ket kulon gorgetest a dokk -> appracs valtasnal.
    private boolean enteringAppGrid = false;
    private int rearrangeRevision = 0;

    private TextView gridTitle;
    // Kis, a jobb felso fogaskerek alatt megjeleno tvOS-szeru panel.
    private LinearLayout settingsDropdown;
    private TextView settingsWallpaperRow;
    private TextView settingsAppearanceRow;
    private TextView settingsControlRow;
    private TextView settingsHiddenRow;
    private TextView settingsSpotifyRow;
    private TextView settingsInputRow;
    private TextView settingsAndroidRow;
    // Az eredeti fejlec-hatteret elmentjuk: a lenyilo menu alatt kapcsolodik,
    // bezaras utan pedig pontosan visszaall a 6.3.2-es kinezetre.
    private Drawable settingsClosedButtonBackground;
    private LinearLayout closingSettingsDropdown;
    // Egyetlen kozos, egybefuggo keret a fejlec ES a ket menupont mogott.
    private View settingsUnifiedShell;
    private View closingSettingsShell;
    private static final int CONNECTED_SETTINGS_WIDTH_DP = 184;
    private static final int CONNECTED_SETTINGS_HEIGHT_DP = 37 + 7 + 40 + 1 + 40 + 1 + 40 + 1 + 40 + 1 + 40 + 1 + 40 + 1 + 40 + 7;
    // Vissza utan a fogaskerek ne nyissa ujra automatikusan a panelt.
    private boolean suppressSettingsAutoOpen = false;

    private static final String PREF_WALLPAPER_AUTO = "wallpaper_auto_v1";
    private static final String PREF_WALLPAPER_FILE = "wallpaper_fixed_file_v1";
    private static final String PREF_WALLPAPER_PC_IP = "wallpaper_pc_ip_v1";
    private static final int WIFI_SYNC_PORT = 8765;
    // TVHome 7.4: temporary, password-protected LAN-only phone upload.
    private static final int PHONE_UPLOAD_PORT = 8766;
    private static final int PHONE_UPLOAD_MAX_BYTES = 16 * 1024 * 1024;
    private volatile boolean phoneUploadActive = false;
    private volatile ServerSocket phoneUploadSocket;
    private volatile Socket phoneUploadClient;
    private Thread phoneUploadThread;
    private String phoneUploadPin;
    private FrameLayout phoneUploadOverlay;
    private TextView phoneUploadStatus;
    private ImageView phoneUploadQr;
    private int phoneUploadCounter = 0;
    private int phoneUploadClosingKey = KeyEvent.KEYCODE_UNKNOWN;
    private volatile int phoneUploadGeneration = 0;
    private boolean wifiSyncBusy = false;
    private final ArrayList<String> favoritePackages = new ArrayList<>();
    private View editorView;
    private View pickerView;
    // A galeria csak megnyitaskor epul fel; thumbnailok maximalis cache-e 4 MiB.
    private GridView wallpaperGalleryGrid;
    // A GridView a teljes fokuszt birtokolja, az egyes thumbnailok nem fokuszalhatok.
    // A kivalasztott indexet emiatt kulon tartjuk nyilvan a taviranyitohoz.
    private int wallpaperGallerySelection = -1;
    // A hosszu OK csak a galeria sajat fokuszkezelojeben ervenyes.
    private static final long GALLERY_HOLD_TO_DELETE_MS = 650L;
    private Runnable wallpaperGalleryHoldTask;
    private boolean wallpaperGalleryHoldTriggered = false;
    private int wallpaperGalleryHoldKey = KeyEvent.KEYCODE_UNKNOWN;
    private FrameLayout wallpaperDeleteOverlay;
    private File wallpaperDeleteTarget;
    private int wallpaperDeleteIndex = -1;
    private int wallpaperDeleteSelection = 0; // 0=Megse; 1=Torles
    private TextView wallpaperDeleteCancel;
    private TextView wallpaperDeleteConfirm;
    private int wallpaperDeleteConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
    private volatile int wallpaperGalleryGeneration = 0;
    private final ExecutorService galleryExecutor = idleWorker("TVHome-Gallery");
    private final HashMap<String, ArrayList<ImageView>> galleryThumbnailWaiters = new HashMap<>();
    private final LruCache<String, Bitmap> galleryThumbCache = new LruCache<String, Bitmap>(4096) {
        @Override protected int sizeOf(String key, Bitmap bitmap) {
            return Math.max(1, bitmap.getByteCount() / 1024);
        }
    };
    private GridView editorGrid;
    private TextView editorAddButton;
    private TextView editorDoneButton;
    private int wrappedDockKey = KeyEvent.KEYCODE_UNKNOWN; // csak az elso/utolso csempe nyilainal


    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService wallpaperExecutor = idleWorker("TVHome-Wallpaper");
    // Csak indulasnal dolgozik: az appok es ikonok lekerdezese a UI-szalon kivul.
    private final ExecutorService iconExecutor = idleWorker("TVHome-Apps");
    // Minden PackageManager-listazas hatterszalon fut; a View-khoz csak a UI-szal nyul.
    private int installedAppsScanRevision = 0;
    private volatile int dockRevision = 0; // szerkesztesnel a keso hattervalaszokat eldobjuk
    private long startupAtMs;
    private FrameLayout root;
    private ImageView bgA;
    private ImageView bgB;
    private LinearLayout dock;
    private TextView greetingText;
    // TVHome 9.0.1: Hetenyi korhaz kornyeki idojaras, rovid cache, reszletes uvegpanel.
    private TextView szolnokWeatherChip;
    private volatile boolean szolnokWeatherBusy = false;
    private String szolnokWeatherDetails = "Időjárásadatok betöltése…";
    private JSONObject szolnokWeatherSnapshot;
    private static final long SZOLNOK_WEATHER_PERIOD_MS = 5L * 60L * 1000L;
    private static final String WEATHER_TIME_KEY = "szolnok_weather_cache_time_v2";
    private static final String WEATHER_LABEL_KEY = "szolnok_weather_cache_label_v2";
    private static final String WEATHER_DETAILS_KEY = "szolnok_weather_cache_details_v2";
    private static final String WEATHER_JSON_KEY = "szolnok_weather_cache_json_v2";
    private static final double HETENYI_LAT = 47.1567;
    private static final double HETENYI_LON = 20.17027;
    private long szolnokWeatherLastRequestMs = 0L;
    private final Runnable szolnokWeatherRefresh = new Runnable() {
        @Override public void run() {
            if (!running) return;
            requestSzolnokWeather();
            // OnStop/onStart must not force a fresh HTTP request each time Home opens.
            // Preserve the actual 20-minute cadence across Activity restarts.
            long age = System.currentTimeMillis() - szolnokWeatherLastRequestMs;
            long untilNext = (age >= 0 && age < SZOLNOK_WEATHER_PERIOD_MS)
                    ? SZOLNOK_WEATHER_PERIOD_MS - age : SZOLNOK_WEATHER_PERIOD_MS;
            mainHandler.postDelayed(this, Math.max(1000L, untilNext));
        }
    };
    private TextView selectedDockLabel;
    // TVHome 7.8 – Spotify Now Playing. Csak az Android helyi Spotify
    // MediaSession-jet olvassa; nem kell Spotify jelszo vagy Web API.
    private static final String SPOTIFY_PACKAGE = "com.spotify.tv.android";
    private SpotifyWebApi spotifyApi;
    // Web API lekerdezes: lejatszas alatt gyors, ures allapotban kimeltebb.
    // A halozati kerelem mindig hatterszalon fut, a 100 ms-os progress UI fuggetlen.
    private static final long SPOTIFY_REFRESH_MS = 2800L;
    private static final long SPOTIFY_API_ACTIVE_REFRESH_MS = 2500L;
    private static final long SPOTIFY_API_IDLE_REFRESH_MS = 4000L;
    private static final long SPOTIFY_PAUSE_GRACE_MS = 90000L;
    private FrameLayout spotifyPanel;
    private ImageView spotifyAlbum;
    private TextView spotifyAlbumFallback;
    private TextView spotifySong;
    private TextView spotifyArtist;
    private MediaTrackTextAnimator spotifyTrackText;
    private ImageView spotifyAlbumIncoming;
    private ImageView spotifyPlayIcon;
    // TVHome 8.0: a korabbi 300x54 dp-es kapszula merete VALTOZATLAN.
    private MediaHaloDrawable spotifyHaloDrawable;
    private View spotifyHaloView;
    private MediaHaloDrawable ambientHaloDrawable;
    // TVHome 8.1: boritobol valasztott szin, lagy 680 ms-os szinatmenettel.
    private static final int MEDIA_NEUTRAL_ACCENT = 0xFFA9B4BF;
    private int mediaAccentCurrent = MEDIA_NEUTRAL_ACCENT;
    private int mediaAccentTarget = MEDIA_NEUTRAL_ACCENT;
    private ValueAnimator mediaAccentAnimator;
    private MediaProgressView spotifyProgressView;
    private MediaProgressView ambientProgressView;
    private FrameLayout ambientSpotifyContainer;
    private ImageView ambientSpotifyAlbum;
    private TextView ambientSpotifyAlbumFallback;
    private TextView ambientSpotifySong;
    private TextView ambientSpotifyArtist;
    private MediaTrackTextAnimator ambientTrackText;
    private ImageView ambientSpotifyAlbumIncoming;
    private ImageView ambientSpotifyPlayIcon;
    private ImageView ambientSpotifyPrevButton;
    private ImageView ambientSpotifyPlayButton;
    private ImageView ambientSpotifyNextButton;
    private boolean ambientControlSelected = false;
    private View ambientReturnFocus;
    private static final long AMBIENT_MEDIA_FOCUS_TIMEOUT_MS = 10000L;
    private final Runnable ambientMediaFocusTimeout = new Runnable() {
        @Override public void run() { clearAmbientMediaSelection(); }
    };
    private long spotifyProgressMs = 0L;
    private long spotifyDurationMs = 0L;
    private long spotifyProgressSampleTimeMs = 0L;
    private boolean spotifyProgressPlaying = false;
    private final Runnable spotifyProgressTicker = new Runnable() {
        @Override public void run() {
            if (!running || !isMediaProgressVisible() || spotifyDurationMs <= 0
                    || !spotifyProgressPlaying) return;
            updateVisibleMediaProgress();
            mainHandler.postDelayed(this, 250L);
        }
    };
    private ImageView spotifyPrevButton;
    private ImageView spotifyPlayButton;
    private ImageView spotifyNextButton;
    private int spotifyConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
    private int spotifyShownPlaybackState = -1;
    private MediaController spotifyController;
    private String spotifyArtKey = "";
    private int spotifyArtRevision = 0;
    private long spotifyLastPlayingAt = 0L;
    private int spotifyPlaybackState = PlaybackState.STATE_NONE;
    private final ExecutorService spotifyArtExecutor = idleWorker("TVHome-Cover");
    private final Runnable spotifyRefresh = new Runnable() {
        @Override public void run() {
            if (!running) return;
            updateSpotifySession();
            long delay = SPOTIFY_REFRESH_MS;
            if (spotifyApi != null && spotifyApi.isLinked()) {
                // A lejatszasi allapotot (play/pause/skip) 2,5 s-onkent ellenorizzuk.
                // Ha nincs aktiv Spotify-eszkoz, eleg a 4 mp-es, takarekos polling.
                delay = spotifyApi.snapshot() != null
                        ? SPOTIFY_API_ACTIVE_REFRESH_MS : SPOTIFY_API_IDLE_REFRESH_MS;
            }
            mainHandler.postDelayed(this, delay);
        }
    };
    private LinearLayout inputsButton;
    private LinearLayout settingsButton;
    private int lastFocusedDockIndex = 0;
    private int headerNavKey = KeyEvent.KEYCODE_UNKNOWN;
    private final Runnable refreshGreeting = new Runnable() {
        @Override public void run() {
            if (greetingText != null) {
                String greeting = greetingForHour();
                if (!greeting.contentEquals(greetingText.getText()))
                    greetingText.setText(greeting);
            }
            mainHandler.postDelayed(this, 5L * 60L * 1000L);
        }
    };
    // A dock + appracs egyetlen ScrollView-ban: NINCS kulon teljes kepernyos app-overlay.
    private ScrollView homeScroll;
    private LinearLayout homeColumn;
    private FrameLayout homeTop;
    private View allView; // mar a homeColumn gyereke, nem modal
    // Codex TV Home: a wallpaper sotetedik, a dokk a racs folott fennmarad.
    // Egyetlen olcso, statikus View; nem Bitmap blur vagy uj Android-ablak.
    private View appGridShade;
    private boolean gridMode = false;
    private GridView allGrid;
    private GridView pickerGrid;
    // Az opciomenuk az Activity egyetlen ablakaban nyilnak meg.
    private View modalView;
    private View modalReturnFocus;
    // TVHome 7.2: egy kis, kulon Android Window nelkuli gyorsvezerlo.
    // Csak nyitaskor keszul, bezaraskor minden View-referencia felszabadul.
    private FrameLayout controlCenterView;
    // A sajat fokuszkezeles pontosan egy animalt ScrollView-gorgetest vezerel.
    private ScrollView controlCenterScroll;
    private ValueAnimator controlCenterScrollAnimator;
    // D-pad: a kivant csempe indexe fuggetlen a pillanatnyi Android-fokusztol.
    // Gorgites alatt az uj, meg nem lathato View nem mindig kerhet fokuszt.
    private int controlCenterCursor = 0;
    private View controlCenterReturnFocus;
    private final ArrayList<LinearLayout> controlCenterTiles = new ArrayList<>();
    private int controlCenterConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
    private static final int REQUEST_BT_CONNECT = 7312;
    private Boolean pendingBluetoothTarget = null;
    private boolean networkRequestInProgress = false;
    private final ArrayList<TextView> modalOptions = new ArrayList<>();
    // Csak az itt kezdet es itt elengedett OK valthat ki valasztast.
    // A Szerkesztes csempe hosszu OK-ja utan erkezo felengedes nem!
    private int modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
    // A hatterkep-lista Vissza gombja a hatterkep-opciokhoz terjen vissza.
    private Runnable modalBackAction;

    private boolean frontIsA = true;
    private volatile boolean running = false;

    // TVHome 7.0 - Cinematic Ambient Mode. 5 percig nincs gombnyomas:
    // a launcher felulete elhalvanyul, a hatterkep es egy diszkret ora marad.
    // NINCS uj Activity, szolgaltatas, kepernyokep, extra bitkep vagy engedely.
    private static final long AMBIENT_IDLE_MS = 5L * 60L * 1000L;
    private static final long AMBIENT_FADE_MS = 430L;
    private FrameLayout ambientLayer;
    private TextClock ambientClockTime;
    private TextClock ambientClockDate;
    private AmbientClockBackdropDrawable ambientClockBackdrop;
    private boolean ambientClockBrightBackground = false;
    private boolean ambientActive = false;
    private int ambientWakeKey = KeyEvent.KEYCODE_UNKNOWN;
    private final Runnable ambientIdleTask = new Runnable() {
        @Override public void run() {
            if (running && !ambientActive) enterAmbientMode();
        }
    };
    private int wallpaperIndex = -1;
    private volatile int wallpaperGeneration = 0;
    private boolean autoWallpaper = true;
    private String fixedWallpaper = "";
    // A megjelenitett fajl azonositoja. Azonos kep ujratoltese nelkul nincs villanas.
    private String displayedWallpaperPath = null;
    // Ultra: tiny, pre-blurred wallpaper sample shared by all glass panels.
    // No screenshots or live blur; ~0.5 MiB (480x270 ARGB_8888).
    private Bitmap ultraWallpaperGlass;
    private Bitmap sharedMediaHaloMask;


    private final Runnable rotateTask = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!autoWallpaper) return;
            nextWallpaper();
            mainHandler.postDelayed(this, wallpaperIntervalMs());
        }
    };

    /**
     * A ScrollView automatikus focus-scrollja eddig felulirta a dokk/appracs
     * animaciot: a kijelzo elobb ugrott, majd visszacsuszott.
     *
     * A fokusz normalisan tovabb terjed, de a nativ fokusz miatti gorgetest
     * ugyanabban a UI-hivasban visszavonjuk. A sajat ValueAnimator az
     * egyetlen scroll-pozicio iroja, igy nincs lathato oda-vissza ugras.
     */
    private static final class FocusControlledScrollView extends ScrollView {
        FocusControlledScrollView(Context context) { super(context); }

        @Override public void requestChildFocus(View child, View focused) {
            int previousX = getScrollX();
            int previousY = getScrollY();
            super.requestChildFocus(child, focused);
            if (getScrollX() != previousX || getScrollY() != previousY)
                scrollTo(previousX, previousY);
        }

        @Override public boolean requestChildRectangleOnScreen(View child,
                Rect rectangle, boolean immediate) {
            // A grid a kijelolest kezeli, a fokevernyo gorgeteset mi.
            return false;
        }

        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int beforeY = getScrollY();
            super.onLayout(changed, l, t, r, b);
            // Uj GridView-letrehozaskor az Android onLayout is ratolhatna.
            if (getScrollY() != beforeY) scrollTo(0, beforeY);
        }
    }

    @Override protected void onCreate(Bundle state) {
        startupAtMs = SystemClock.elapsedRealtime();
        super.onCreate(state);
        spotifyApi = new SpotifyWebApi(this);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        root = new FrameLayout(this);
        root.setClipChildren(false);
        root.setClipToPadding(false);
        root.setBackgroundColor(0xFF0A111A);  // fallback, ha meg nincs hatterkep

        bgA = addBackground();
        bgB = addBackground();
        bgB.setAlpha(0f);

        // Finom sotetites a kepekhez, hogy a feher szoveg mindig olvashato legyen.
        View tint = new View(this);
        tint.setBackgroundColor(0x14040A12);
        root.addView(tint, new FrameLayout.LayoutParams(-1, -1));

        View topShade = new View(this);
        topShade.setBackground(gradient(new int[]{0x960A1320, 0x000A1320}));
        root.addView(topShade, new FrameLayout.LayoutParams(-1, dp(190), Gravity.TOP));

        View bottomShade = new View(this);
        bottomShade.setBackground(gradient(new int[]{0x0004070C, 0x7004070C}));
        root.addView(bottomShade, new FrameLayout.LayoutParams(-1, dp(330), Gravity.BOTTOM));

        // Codex atmenet: a racsba lepve a FIX hatter finoman elsotetedik.
        // A ScrollView ez ELE kerul, tehat az appok es a dokk nem sotetednek.
        appGridShade = new View(this);
        appGridShade.setBackgroundColor(0xB3000000);
        appGridShade.setAlpha(0f);
        appGridShade.setFocusable(false);
        root.addView(appGridShade, new FrameLayout.LayoutParams(-1, -1));

        // A hatter a teljes kepernyon fix, a tartalom egy kozosen gorgetheto oldalon van.
        // Android ScrollView fokuszvaltasnal sajat magat is gorgeti.
        // A launchernek viszont sajat, egyetlen animalt gorgetese van.
        homeScroll = new FocusControlledScrollView(this);
        homeScroll.setFillViewport(true);
        homeScroll.setVerticalScrollBarEnabled(false);
        homeScroll.setSmoothScrollingEnabled(true);
        homeScroll.setClipToPadding(false);
        homeScroll.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        homeColumn = new LinearLayout(this);
        homeColumn.setOrientation(LinearLayout.VERTICAL);
        homeColumn.setClipChildren(false);
        homeColumn.setClipToPadding(false);
        homeTop = new FrameLayout(this);
        homeTop.setClipChildren(false);
        homeTop.setClipToPadding(false);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        homeColumn.addView(homeTop, new LinearLayout.LayoutParams(-1, metrics.heightPixels));
        homeScroll.addView(homeColumn, new ScrollView.LayoutParams(-1, -2));
        root.addView(homeScroll, new FrameLayout.LayoutParams(-1, -1));

        loadFavorites();
        readWallpaperSettings();
        readAppearanceSettings();
        addHeader();
        addSpotifyNowPlaying();
        addDock();
        installAmbientLayer();

        setContentView(root);
        Log.i(TAG, "TVHOME_LAYOUT_READY_MS=" + (SystemClock.elapsedRealtime() - startupAtMs));
        dock.post(new Runnable() {
            @Override public void run() { focusFirstDockItem(); }
        });
    }

    @Override protected void onStart() {
        super.onStart();
        running = true;
        mainHandler.removeCallbacks(refreshGreeting);
        refreshGreeting.run();
        mainHandler.removeCallbacks(spotifyRefresh);
        mainHandler.post(spotifyRefresh);
        mainHandler.removeCallbacks(szolnokWeatherRefresh);
        mainHandler.post(szolnokWeatherRefresh);
        showFirstWallpaper();
        scheduleWallpaperRotation();
        // Csak az eloterben levo TVHome szamlalja a tétlenseget.
        if (ambientActive) leaveAmbientMode(false);
        scheduleAmbientTimeout();
    }

    @Override protected void onStop() {
        cancelWallpaperGalleryHold();
        closeWallpaperDeleteOverlay(false);
        stopPhoneUpload(true);
        if (spotifyApi != null) spotifyApi.stopPairing();
        if (controlCenterView != null) closeControlCenter(false);
        running = false;
        mainHandler.removeCallbacks(ambientIdleTask);
        mainHandler.removeCallbacks(ambientMediaFocusTimeout);
        mainHandler.removeCallbacks(spotifyProgressTicker);
        if (mediaAccentAnimator != null) {
            mediaAccentAnimator.cancel();
            mediaAccentAnimator = null;
        }
        leaveAmbientMode(false);
        ambientWakeKey = KeyEvent.KEYCODE_UNKNOWN;
        wallpaperGeneration++;
        mainHandler.removeCallbacks(rotateTask);
        mainHandler.removeCallbacks(refreshGreeting);
        mainHandler.removeCallbacks(szolnokWeatherRefresh);
        mainHandler.removeCallbacks(spotifyRefresh);
        spotifyController = null;
        hideSpotifyPanel();
        bgA.animate().cancel();
        bgB.animate().cancel();
        if (homeScrollAnimator != null) {
            homeScrollAnimator.cancel();
            homeScrollAnimator = null;
        }
        enteringAppGrid = false;
        bgA.setImageDrawable(null);
        bgB.setImageDrawable(null);
        bgA.setAlpha(1f);
        bgB.setAlpha(0f);
        frontIsA = true;
        displayedWallpaperPath = null;
        if (ultraWallpaperGlass != null && !ultraWallpaperGlass.isRecycled())
            ultraWallpaperGlass.recycle();
        ultraWallpaperGlass = null;
        super.onStop();
    }

    @Override protected void onDestroy() {
        stopPhoneUpload(true);
        galleryThumbnailWaiters.clear();
        if (controlCenterView != null) closeControlCenter(false);
        mainHandler.removeCallbacks(ambientIdleTask);
        closeAppearanceMenu(false);
        if (modalView != null) closeLightweightMenu();
        closeSettingsDropdown();
        if (longPressRunnable != null) mainHandler.removeCallbacks(longPressRunnable);
        wallpaperExecutor.shutdownNow();
        galleryExecutor.shutdownNow();
        galleryThumbCache.evictAll();
        ++dockRevision; // kesoi UI-ikonfrissitesek mar ne ervenyesuljenek
        iconExecutor.shutdownNow();
        spotifyArtExecutor.shutdownNow();
        if (spotifyApi != null) spotifyApi.shutdown();
        super.onDestroy();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        stopPhoneUpload(true);
        if (controlCenterView != null) closeControlCenter(false);
        leaveAmbientMode(false);
        if (running) scheduleAmbientTimeout();
        closeAppearanceMenu(false);
        if (modalView != null) closeLightweightMenu();
        closeSettingsDropdown();
        hidePicker();
        hideEditor();
        hideAll();
        moving = false;
        movingPackage = null;
        focusFirstDockItem();
    }

    @Override protected void onResume() {
        super.onResume();
        if (orderReady && !moving) {
            // A PackageManager lekerdezese ne akassza meg a Home animaciojat.
            refreshInstalledApps();
        }
    }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            galleryThumbCache.evictAll();
            bannerCache.clear();
            SoftEdgeGlowDrawable.CACHE.evictAll();
        }
    }

    /** Egyetlen, atlatszo ora-layer a fix hatterkep fole.
     *  Alatta semmi uj bitmap vagy blur nem keszul, ezert az 1 GB RAM-os TV-n
     *  a meglevo hatterkepkezeles es liquid glass memoriahasznalata marad.
     */
    private void installAmbientLayer() {
        ambientLayer = new FrameLayout(this);
        ambientLayer.setVisibility(View.GONE);
        ambientLayer.setAlpha(0f);
        ambientLayer.setBackgroundColor(0x00000000);
        ambientLayer.setClickable(false);
        ambientLayer.setFocusable(false);

        LinearLayout timeStack = new LinearLayout(this);
        timeStack.setOrientation(LinearLayout.VERTICAL);
        timeStack.setGravity(Gravity.CENTER_HORIZONTAL);

        // TVHome 8.1.1: csak az ora + datum mogott van egy lathato,
        // peremnel teljesen kifuto, vilagossagfuggo sotet vignetta.
        // A zenei kapszula kivul marad ezen a hatteren.
        FrameLayout clockPanel = new FrameLayout(this);
        ambientClockBackdrop = new AmbientClockBackdropDrawable();
        clockPanel.setBackground(ambientClockBackdrop);
        LinearLayout clockTextStack = new LinearLayout(this);
        clockTextStack.setOrientation(LinearLayout.VERTICAL);
        clockTextStack.setGravity(Gravity.CENTER_HORIZONTAL);
        clockTextStack.setPadding(dp(24), dp(8), dp(24), dp(8));
        clockPanel.addView(clockTextStack, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams clockPanelLp = new LinearLayout.LayoutParams(dp(390), -2);
        clockPanelLp.gravity = Gravity.CENTER_HORIZONTAL;
        timeStack.addView(clockPanel, clockPanelLp);

        TextClock time = new TextClock(this);
        time.setFormat24Hour("HH:mm");
        time.setFormat12Hour("HH:mm");
        time.setTextSize(64);
        time.setTextColor(0xF7FFFFFF);
        time.setGravity(Gravity.CENTER);
        time.setIncludeFontPadding(false);
        time.setShadowLayer(dp(4), 0f, dp(2), 0xA6000000);
        clockTextStack.addView(time, new LinearLayout.LayoutParams(-2, -2));
        ambientClockTime = time;

        TextClock date = new TextClock(this);
        date.setFormat24Hour("MMM d., EEEE");
        date.setFormat12Hour("MMM d., EEEE");
        date.setTextSize(17);
        date.setTextColor(0xE6FFFFFF);
        date.setGravity(Gravity.CENTER);
        date.setIncludeFontPadding(false);
        date.setShadowLayer(dp(3), 0f, dp(1), 0xA6000000);
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(-2, -2);
        dateParams.topMargin = dp(11);
        clockTextStack.addView(date, dateParams);
        ambientClockDate = date;
        applyAmbientClockContrast(ambientClockBrightBackground);
        installAmbientSpotifyCapsule(timeStack);

        FrameLayout.LayoutParams timePosition = new FrameLayout.LayoutParams(
                -2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        timePosition.bottomMargin = dp(75);
        ambientLayer.addView(timeStack, timePosition);
        root.addView(ambientLayer, new FrameLayout.LayoutParams(-1, -1));
    }

    /** Folyamatos, ovalisan elhalvanyulo kontrasztvignetta.
     *  Nem rajzol csikokat, nem keszit blur bitmapet, es nem valtoztatja
     *  az ora helyet / a Spotify kapszula meretet.
     *  A RadialGradient csak hatterkepvaltaskor frissul, nem minden frame-ben.
     */
    private final class AmbientClockBackdropDrawable extends Drawable {
        private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean bright = false;
        private Shader shade;
        private int opacity = 255;

        void setBright(boolean next) {
            if (shade == null || bright != next) {
                bright = next;
                // Fenyes kepeknel az ora mogotti kozep lathatoan sotetebb;
                // a szel teljesen atlatszova valik, nincs merev uveglap.
                int center = bright ? 0xC5000000 : 0x45000000;
                int middle = bright ? 0x82000000 : 0x20000000;
                shade = new android.graphics.RadialGradient(0f, 0f, 1f,
                        new int[]{center, middle, 0x00000000},
                        new float[]{0f, 0.56f, 1f}, Shader.TileMode.CLAMP);
                ink.setShader(shade);
                invalidateSelf();
            }
        }

        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) return;
            if (shade == null) setBright(bright);
            ink.setAlpha(opacity);
            canvas.save();
            canvas.translate(b.exactCenterX(), b.exactCenterY());
            canvas.scale(b.width() * 0.5f, b.height() * 0.49f);
            canvas.drawCircle(0f, 0f, 1f, ink);
            canvas.restore();
        }
        @Override public void setAlpha(int a) {
            opacity = Math.max(0, Math.min(255, a));
            invalidateSelf();
        }
        @Override public void setColorFilter(ColorFilter ignored) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Az ora es a datum a meglevo layeren belul, finoman kulon jelenik meg.
     *  A home/ambient transition idozitesehez es a media gombokhoz nem nyulunk. */
    private void animateAmbientClockEntrance() {
        if (ambientClockTime == null || ambientClockDate == null) return;
        ambientClockTime.animate().cancel();
        ambientClockDate.animate().cancel();
        ambientClockTime.setAlpha(0f);
        ambientClockTime.setTranslationY(dp(9));
        ambientClockDate.setAlpha(0f);
        ambientClockDate.setTranslationY(dp(7));
        ambientClockTime.animate().alpha(1f).translationY(0f)
                .setStartDelay(70L).setDuration(470L).setInterpolator(tvEase).start();
        ambientClockDate.animate().alpha(1f).translationY(0f)
                .setStartDelay(135L).setDuration(510L).setInterpolator(tvEase).start();
    }

    /** Az ora helyen levo kepterulet kontrasztjahoz alkalmazkodik.
     *  Nem szurunk el ujra kepet: csupan a kesz hatterkep 63 pixeljet olvassuk. */
    private boolean sampleClockBackdropBrightness(Bitmap bmp) {
        if (bmp == null || bmp.isRecycled()) return false;
        try {
            float sum = 0f;
            int highlights = 0;
            int n = 0;
            for (int row = 0; row < 7; ++row) {
                int y = Math.min(bmp.getHeight() - 1,
                        Math.round((0.62f + row * 0.034f) * (bmp.getHeight() - 1)));
                for (int col = 0; col < 9; ++col) {
                    int x = Math.min(bmp.getWidth() - 1,
                            Math.round((0.36f + col * 0.035f) * (bmp.getWidth() - 1)));
                    int c = bmp.getPixel(x, y);
                    float luminance = (((c >> 16) & 255) * 0.2126f
                            + ((c >> 8) & 255) * 0.7152f
                            + (c & 255) * 0.0722f) / 255f;
                    sum += luminance;
                    if (luminance > 0.70f) ++highlights;
                    ++n;
                }
            }
            return n > 0 && (sum / n > 0.47f || highlights > n / 3);
        } catch (RuntimeException ignored) { return false; }
    }

    private void applyAmbientClockContrast(boolean brightBackground) {
        ambientClockBrightBackground = brightBackground;
        if (ambientClockBackdrop != null) ambientClockBackdrop.setBright(brightBackground);
        if (ambientClockTime == null || ambientClockDate == null) return;
        ambientClockTime.setTextColor(0xFFFFFFFF);
        ambientClockDate.setTextColor(0xF0FFFFFF);
        if (brightBackground) {
            // Fenyes hatteren karakteresebb, de puha sotet szovegarnyek.
            ambientClockTime.setShadowLayer(dp(7), 0f, dp(2), 0xE8000000);
            ambientClockDate.setShadowLayer(dp(4), 0f, dp(1), 0xD9000000);
        } else {
            // Sotet hatteren ropogos feher ora, alig eszreveheto arnyekkal.
            ambientClockTime.setShadowLayer(dp(2), 0f, dp(1), 0x67000000);
            ambientClockDate.setShadowLayer(dp(1.5f), 0f, dp(1), 0x55000000);
        }
        ambientClockTime.invalidate();
        ambientClockDate.invalidate();
    }

    private void scheduleAmbientTimeout() {
        mainHandler.removeCallbacks(ambientIdleTask);
        if (running && !ambientActive) mainHandler.postDelayed(ambientIdleTask, AMBIENT_IDLE_MS);
    }

    // Az kulon ablak nelkuli menuk a root-ban vannak, nem a homeScroll-ban:
    // ezeket is el kell tuntetni ambientben, megorzott fokusszal.
    private void hidePopupForAmbient(final View popup) {
        if (popup == null || popup.getVisibility() != View.VISIBLE) return;
        popup.animate().cancel();
        popup.animate().alpha(0f).setDuration(AMBIENT_FADE_MS)
                .setInterpolator(tvEase).withEndAction(new Runnable() {
                    @Override public void run() {
                        if (ambientActive) popup.setVisibility(View.INVISIBLE);
                    }
                }).start();
    }

    private void restorePopupAfterAmbient(View popup, boolean animate) {
        if (popup == null) return;
        popup.animate().cancel();
        popup.setVisibility(View.VISIBLE);
        if (animate) {
            popup.setAlpha(0f);
            popup.animate().alpha(1f).setDuration(AMBIENT_FADE_MS)
                    .setInterpolator(tvEase).start();
        } else {
            popup.setAlpha(1f);
        }
    }

    private void enterAmbientMode() {
        if (!running || ambientActive || ambientLayer == null) return;
        ambientActive = true;
        ambientReturnFocus = getCurrentFocus();
        ambientControlSelected = false;
        mainHandler.removeCallbacks(ambientMediaFocusTimeout);
        mainHandler.removeCallbacks(ambientIdleTask);
        syncMediaProgressVisibility();
        // A fokusz/sorrend/menu allapota nem valtozik, csak a latvany.
        if (homeScroll != null) {
            homeScroll.animate().cancel();
            homeScroll.animate().alpha(0f).setDuration(AMBIENT_FADE_MS)
                    .setInterpolator(tvEase).start();
        }
        hidePopupForAmbient(controlCenterView);
        hidePopupForAmbient(appearanceOverlay);
        hidePopupForAmbient(modalView);
        hidePopupForAmbient(editorView);
        hidePopupForAmbient(pickerView);
        ambientLayer.animate().cancel();
        ambientLayer.setAlpha(0f);
        ambientLayer.setVisibility(View.VISIBLE);
        animateAmbientClockEntrance();
        ambientLayer.animate().alpha(1f).setDuration(AMBIENT_FADE_MS + 90L)
                .setInterpolator(tvEase).start();
    }

    /** Visszaallitas: elso gomb csak ebreszt, nem inditja el a kijelolt appot. */
    private void leaveAmbientMode(boolean animate) {
        if (!ambientActive) return;
        // A kijeloles es annak idozitoje nem szivaroghat at a home kepernyore.
        clearAmbientMediaSelection();
        ambientActive = false;
        if (ambientReturnFocus != null) {
            ambientReturnFocus.requestFocus();
            ambientReturnFocus = null;
        }
        syncMediaProgressVisibility();
        if (homeScroll != null) {
            homeScroll.animate().cancel();
            if (animate) {
                homeScroll.animate().alpha(1f).setDuration(AMBIENT_FADE_MS)
                        .setInterpolator(tvEase).start();
            } else homeScroll.setAlpha(1f);
        }
        restorePopupAfterAmbient(controlCenterView, animate);
        restorePopupAfterAmbient(appearanceOverlay, animate);
        restorePopupAfterAmbient(modalView, animate);
        restorePopupAfterAmbient(editorView, animate);
        restorePopupAfterAmbient(pickerView, animate);
        if (ambientLayer != null) {
            ambientLayer.animate().cancel();
            if (animate) {
                ambientLayer.animate().alpha(0f).setDuration(AMBIENT_FADE_MS / 2L)
                        .withEndAction(new Runnable() {
                            @Override public void run() {
                                if (!ambientActive && ambientLayer != null)
                                    ambientLayer.setVisibility(View.GONE);
                            }
                        }).start();
            } else {
                ambientLayer.setAlpha(0f);
                ambientLayer.setVisibility(View.GONE);
            }
        }
        if (running) scheduleAmbientTimeout();
    }

    @Override public boolean dispatchTouchEvent(android.view.MotionEvent event) {
        if (ambientActive) {
            if (event.getActionMasked() == android.view.MotionEvent.ACTION_DOWN)
                leaveAmbientMode(true);
            // Az elso erintes se nyisson appot vagy menut.
            return true;
        }
        if (event.getActionMasked() == android.view.MotionEvent.ACTION_DOWN)
            scheduleAmbientTimeout();
        return super.dispatchTouchEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(android.view.MotionEvent event) {
        if (ambientActive) {
            leaveAmbientMode(true);
            return true;
        }
        scheduleAmbientTimeout();
        return super.dispatchGenericMotionEvent(event);
    }

    @Override public void onBackPressed() {
        if (ambientActive) { leaveAmbientMode(true); return; }
        if (spotifyButtonHasFocus(getCurrentFocus())) {
            focusFirstDockItem();
            return;
        }
        if (controlCenterView != null) { closeControlCenter(true); return; }
        if (modalView != null) { closeLightweightMenuGoingBack(); return; }
        if (settingsDropdown != null) {
            suppressSettingsAutoOpen = true;
            closeSettingsDropdown();
            if (settingsButton != null) settingsButton.requestFocus();
            return;
        }
        if (moving) { finishMove(false); return; }
        if (pickerView != null) hidePicker();
        else if (editorView != null) hideEditor();
        else if (allView != null) hideAll();
        // A home kepernyon a Vissza nem lep ki a launcherbol.
    }

    // Az udvozles az aktualis, a TV-n beallitott helyi ido alapjan valtozik.
    // A 5 perces idozites nem uj szolgalatas, csak egy TextView feliratot frissit.
    private String greetingForHour() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour >= 5 && hour < 11) return "Jó reggelt";
        if (hour >= 11 && hour < 18) return "Jó napot";
        return "Jó estét";
    }

    // Egyszeru ido-jaras ikonok; Android TV regi fontokkal is olvashatok.
    private String weatherSymbol(int code, boolean day) {
        if (code == 0) return day ? "☀" : "☾";
        if (code == 1 || code == 2) return day ? "⛅" : "☾";
        if (code == 3 || code == 45 || code == 48) return "☁";
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "☂";
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return "❄";
        if (code >= 95) return "⚡";
        return "☁";
    }

    private String weatherDescription(int code) {
        if (code == 0) return "Derült";
        if (code == 1) return "Többnyire derült";
        if (code == 2) return "Részben felhős";
        if (code == 3) return "Borult";
        if (code == 45 || code == 48) return "Ködös";
        if (code >= 51 && code <= 57) return "Szitálás";
        if (code >= 61 && code <= 67) return "Esős";
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return "Havas";
        if (code >= 80 && code <= 82) return "Záporok";
        if (code >= 95) return "Zivataros";
        return "Változékony";
    }

    // Diszkret TV-s uvegfelulet. Nem hasznal draga valos ideju elmosast.
    private GradientDrawable weatherGlassBackground(int radiusDp, int border) {
        GradientDrawable b = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xF528303D, 0xF51A202B, 0xF51B1B26});
        b.setCornerRadius(dp(radiusDp));
        b.setStroke(dp(1), border);
        return b;
    }

    private TextView weatherText(String text, int sp, int color, boolean bold) {
        TextView v = text(text, sp, color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        return v;
    }

    private LinearLayout weatherMetric(String heading, String value) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(12), dp(12), dp(12));
        card.setBackground(weatherGlassBackground(16, 0x346F92AB));
        TextView label = weatherText(heading, 12, 0xFFACBBCD, false);
        TextView reading = weatherText(value, 20, 0xFFFFFFFF, true);
        LinearLayout.LayoutParams valueLp = new LinearLayout.LayoutParams(-1, -2);
        valueLp.topMargin = dp(5);
        card.addView(label);
        card.addView(reading, valueLp);
        return card;
    }

    private void showSzolnokWeatherDetails() {
        final JSONObject data = szolnokWeatherSnapshot;
        if (data == null) {
            new AlertDialog.Builder(this).setMessage("Az időjárásadatok még nem érkeztek meg.")
                    .setPositiveButton("Rendben", null).show();
            return;
        }
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(25), dp(22), dp(25), dp(20));
        content.setBackground(weatherGlassBackground(24, 0x627B99B2));

        TextView place = weatherText("SZOLNOK  ·  HETÉNYI KÓRHÁZ KÖRNYÉKE", 12,
                0xFFC1D5E9, true);
        content.addView(place);

        LinearLayout headline = new LinearLayout(this);
        headline.setOrientation(LinearLayout.HORIZONTAL);
        headline.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams headLp = new LinearLayout.LayoutParams(-1, -2);
        headLp.topMargin = dp(13);
        content.addView(headline, headLp);
        TextView icon = weatherText(weatherSymbol(data.optInt("code", 3),
                data.optBoolean("day", true)), 45, 0xFFFFFFFF, false);
        headline.addView(icon, new LinearLayout.LayoutParams(dp(62), -2));
        TextView temperature = weatherText(data.optInt("temp") + "°", 53,
                0xFFFFFFFF, true);
        headline.addView(temperature);
        LinearLayout descriptionWrap = new LinearLayout(this);
        descriptionWrap.setOrientation(LinearLayout.VERTICAL);
        descriptionWrap.setPadding(dp(16), dp(4), 0, 0);
        TextView condition = weatherText(weatherDescription(data.optInt("code", 3)),
                17, 0xFFF2F6FF, true);
        TextView subtitle = weatherText("Jelenlegi időjárás", 12,
                0xFFACBACA, false);
        descriptionWrap.addView(condition);
        descriptionWrap.addView(subtitle);
        headline.addView(descriptionWrap);

        LinearLayout metricRow = new LinearLayout(this);
        metricRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(15);
        content.addView(metricRow, rowLp);
        LinearLayout feels = weatherMetric("HŐÉRZET", data.optInt("feels") + "°");
        LinearLayout humidity = weatherMetric("PÁRATARTALOM",
                data.optInt("humidity") < 0 ? "—" : data.optInt("humidity") + "%");
        LinearLayout wind = weatherMetric("SZÉL", data.optInt("wind") + " km/h");
        LinearLayout.LayoutParams cp1 = new LinearLayout.LayoutParams(0, -2, 1f);
        cp1.rightMargin = dp(8);
        metricRow.addView(feels, cp1);
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(0, -2, 1f);
        cp2.rightMargin = dp(8);
        metricRow.addView(humidity, cp2);
        metricRow.addView(wind, new LinearLayout.LayoutParams(0, -2, 1f));

        JSONArray hours = data.optJSONArray("hours");
        if (hours != null && hours.length() > 0) {
            TextView next = weatherText("KÖVETKEZŐ ÓRÁK", 12,
                    0xFFCAD9EA, true);
            LinearLayout.LayoutParams nextLp = new LinearLayout.LayoutParams(-1, -2);
            nextLp.topMargin = dp(19);
            content.addView(next, nextLp);
            LinearLayout forecast = new LinearLayout(this);
            forecast.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams forecastLp = new LinearLayout.LayoutParams(-1, -2);
            forecastLp.topMargin = dp(8);
            content.addView(forecast, forecastLp);
            for (int i = 0; i < Math.min(4, hours.length()); i++) {
                JSONObject item = hours.optJSONObject(i);
                if (item == null) continue;
                LinearLayout one = new LinearLayout(this);
                one.setOrientation(LinearLayout.VERTICAL);
                one.setGravity(Gravity.CENTER);
                one.setPadding(dp(6), dp(8), dp(6), dp(8));
                TextView time = weatherText(item.optString("t", ""), 12,
                        0xFFB6C6D5, false);
                TextView symbol = weatherText(weatherSymbol(item.optInt("c", 3),
                        data.optBoolean("day", true)), 22, 0xFFFFFFFF, false);
                TextView degrees = weatherText(item.optInt("v") + "°", 15,
                        0xFFFFFFFF, true);
                one.addView(time); one.addView(symbol); one.addView(degrees);
                forecast.addView(one, new LinearLayout.LayoutParams(0, -2, 1f));
            }
        }
        String source = data.optString("source", "Open-Meteo előrejelzési modell");
        String measuredAt = data.optString("at", "");
        String observationTime = data.optString("observationTime", "");
        TextView footer = weatherText("Forrás: " + source + "\nFrissítve: "
                + measuredAt + "  ·  Frissítés 5 percenként"
                + "\nAdat ideje: " + observationTime
                + "\nHőérzet és órás előrejelzés: Open-Meteo", 11,
                0xFFACBBCD, false);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(19);
        content.addView(footer, footerLp);
        if (source.startsWith("MetNet.hu")) {
            TextView attribution = weatherText("MetNet.hu · forrás megnyitása", 11,
                    0xFFB7DFFB, false);
            attribution.setPadding(0, dp(6), 0, dp(6));
            attribution.setFocusable(true);
            attribution.setOnClickListener(v -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.metnet.hu"))); }
                catch (Exception ignored) { }
            });
            content.addView(attribution);
        }
        TextView close = weatherText("BEZÁRÁS", 14, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(12), dp(11), dp(12), dp(11));
        close.setFocusable(true);
        close.setClickable(true);
        close.setBackground(weatherGlassBackground(14, 0xA8A8C9E3));
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, dp(43));
        closeLp.topMargin = dp(18);
        content.addView(close, closeLp);
        final AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        close.setOnClickListener(v -> dialog.dismiss());
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                dialog.getWindow().setLayout(dp(590), -2);
                dialog.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                android.view.WindowManager.LayoutParams a = dialog.getWindow().getAttributes();
                a.dimAmount = 0.68f;
                dialog.getWindow().setAttributes(a);
            }
            close.requestFocus();
        });
        dialog.show();
    }

    // Ha a MetNet legkozelebbi Szolnok-allomasanak friss merese JSON-kent
    // egyertelmuen felismerheto, azt hasznaljuk. Bizonytalan szerkezetnel
    // soha nem allitjuk, hogy az adat mért. Az Open-Meteo a biztos tartalek.
    private static final class StationReading {
        String name;
        double temperature;
        String time;
        StationReading(String n, double t, String tm) { name = n; temperature = t; time = tm; }
    }

    private String optText(JSONObject o, String... keys) {
        for (String key : keys) {
            String v = o.optString(key, "").trim();
            if (!v.isEmpty() && !v.equalsIgnoreCase("null")) return v;
        }
        return "";
    }

    private StationReading findStationReading(Object node, String inheritedName, int depth) {
        if (depth > 7) return null;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < Math.min(a.length(), 200); i++) {
                StationReading s = findStationReading(a.opt(i), inheritedName, depth + 1);
                if (s != null) return s;
            }
        }
        if (!(node instanceof JSONObject)) return null;
        JSONObject o = (JSONObject) node;
        String name = optText(o, "allomas_nev", "allomasNev", "station_name",
                "stationName", "nev", "name");
        if (name.isEmpty()) name = inheritedName;
        boolean nearSzolnok = name.toLowerCase(Locale.ROOT).contains("szolnok");
        // Only trust a clearly identified local measurement, not generic 'current' data.
        if (nearSzolnok) {
            String raw = optText(o, "homerseklet", "hőmérséklet", "temperature",
                    "temp", "temperature_c");
            try {
                if (!raw.isEmpty()) {
                    double t = Double.parseDouble(raw.replace(',', '.').replace("°C", "").trim());
                    if (t > -40 && t < 55) {
                        String tm = optText(o, "idopont", "időpont", "time", "timestamp");
                        if (stationMeasurementFresh(tm)) return new StationReading(name, t, tm);
                    }
                }
            } catch (NumberFormatException ignored) { }
        }
        JSONArray names = o.names();
        if (names == null) return null;
        for (int i = 0; i < Math.min(names.length(), 100); i++) {
            String key = names.optString(i);
            String deeperName = name;
            if (key.toLowerCase(Locale.ROOT).contains("szolnok")) deeperName = key;
            StationReading result = findStationReading(o.opt(key), deeperName, depth + 1);
            if (result != null) return result;
        }
        return null;
    }

    private boolean stationMeasurementFresh(String timestamp) {
        if (timestamp == null || timestamp.trim().isEmpty()) return false;
        String value = timestamp.trim();
        try {
            long unix = Long.parseLong(value);
            if (unix > 100000000000L) return Math.abs(System.currentTimeMillis() - unix) < 40L * 60000L;
            if (unix > 1000000000L) return Math.abs(System.currentTimeMillis() - unix * 1000L) < 40L * 60000L;
        } catch (NumberFormatException ignored) { }
        // If a day is provided, reject earlier-day measurements.
        java.text.SimpleDateFormat dayFmt = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String today = dayFmt.format(new java.util.Date());
        if (value.matches(".*\\d{4}-\\d{2}-\\d{2}.*") && !value.contains(today)) return false;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(value);
        if (!m.find()) return false;
        int hour = Integer.parseInt(m.group(1)), minute = Integer.parseInt(m.group(2));
        if (hour > 23 || minute > 59) return false;
        Calendar clock = Calendar.getInstance();
        int currentMinute = clock.get(Calendar.HOUR_OF_DAY) * 60 + clock.get(Calendar.MINUTE);
        int observationMinute = hour * 60 + minute;
        int delta = (currentMinute - observationMinute + 1440) % 1440;
        return delta <= 40 || delta >= 1435;
    }

    private StationReading getMetNetStation() {
        HttpURLConnection stationConn = null;
        try {
            String address = "https://www.metnet.hu/api/widget/v1/most?hely=Szolnok";
            stationConn = (HttpURLConnection) new URL(address).openConnection();
            stationConn.setConnectTimeout(2500);
            stationConn.setReadTimeout(2500);
            stationConn.setRequestProperty("Accept", "application/json");
            if (stationConn.getResponseCode() != 200) return null;
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            try (InputStream in = stationConn.getInputStream()) {
                byte[] buffer = new byte[1024]; int n;
                while ((n = in.read(buffer)) > 0 && output.size() < 24000)
                    output.write(buffer, 0, n);
            }
            return findStationReading(new JSONObject(output.toString("UTF-8")), "", 0);
        } catch (Exception e) {
            return null;
        } finally {
            if (stationConn != null) stationConn.disconnect();
        }
    }

    private void requestSzolnokWeather() {
        if (szolnokWeatherBusy) return;
        long now = System.currentTimeMillis();
        long age = now - szolnokWeatherLastRequestMs;
        if (age >= 0 && age < SZOLNOK_WEATHER_PERIOD_MS) return;
        szolnokWeatherLastRequestMs = now;
        szolnokWeatherBusy = true;
        Thread worker = new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection conn = null;
                try {
                    String endpoint = "https://api.open-meteo.com/v1/forecast"
                            + "?latitude=" + HETENYI_LAT + "&longitude=" + HETENYI_LON
                            + "&current=temperature_2m,relative_humidity_2m,"
                            + "apparent_temperature,weather_code,wind_speed_10m,is_day"
                            + "&hourly=temperature_2m,weather_code&forecast_hours=5"
                            + "&timezone=Europe%2FBudapest";
                    conn = (HttpURLConnection) new URL(endpoint).openConnection();
                    conn.setConnectTimeout(4500);
                    conn.setReadTimeout(4500);
                    conn.setRequestProperty("Accept", "application/json");
                    if (conn.getResponseCode() != 200) throw new IOException("HTTP " + conn.getResponseCode());
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    try (InputStream in = conn.getInputStream()) {
                        byte[] buf = new byte[2048]; int n;
                        while ((n = in.read(buf)) != -1 && bytes.size() < 32000)
                            bytes.write(buf, 0, n);
                    }
                    JSONObject response = new JSONObject(bytes.toString("UTF-8"));
                    JSONObject current = response.getJSONObject("current");
                    int temp = (int) Math.round(current.getDouble("temperature_2m"));
                    final int feels = (int) Math.round(current.getDouble("apparent_temperature"));
                    final int humidity = current.optInt("relative_humidity_2m", -1);
                    final int wind = (int) Math.round(current.optDouble("wind_speed_10m", 0));
                    final int code = current.getInt("weather_code");
                    boolean day = current.optInt("is_day", 1) == 1;
                    String source = "Open-Meteo · kórház környéki modellbecslés";
                    String observationTime = current.optString("time", "");
                    // A MetNet publikus endpointja friss helyi allomasmerest adhat;
                    // ha az idopont / homerseklet nem azonosithato, nem hasznaljuk.
                    StationReading station = getMetNetStation();
                    if (station != null) {
                        temp = (int)Math.round(station.temperature);
                        source = "MetNet.hu · " + station.name + " (közeli állomásmérés)";
                        observationTime = station.time;
                    }
                    final String updated = new java.text.SimpleDateFormat("HH:mm", Locale.forLanguageTag("hu-HU"))
                            .format(new java.util.Date());
                    JSONArray hours = new JSONArray();
                    JSONObject hourly = response.optJSONObject("hourly");
                    if (hourly != null) {
                        JSONArray times = hourly.optJSONArray("time");
                        JSONArray temps = hourly.optJSONArray("temperature_2m");
                        JSONArray codes = hourly.optJSONArray("weather_code");
                        if (times != null && temps != null && codes != null) {
                            for (int i = 0; i < Math.min(4, Math.min(times.length(),
                                    Math.min(temps.length(), codes.length()))); i++) {
                                String t = times.optString(i, "");
                                JSONObject item = new JSONObject();
                                item.put("t", t.length() >= 16 ? t.substring(11, 16) : t);
                                item.put("v", (int)Math.round(temps.optDouble(i)));
                                item.put("c", codes.optInt(i));
                                hours.put(item);
                            }
                        }
                    }
                    final JSONObject snapshot = new JSONObject();
                    snapshot.put("temp", temp); snapshot.put("feels", feels);
                    snapshot.put("humidity", humidity); snapshot.put("wind", wind);
                    snapshot.put("code", code); snapshot.put("day", day);
                    snapshot.put("source", source); snapshot.put("at", updated);
                    snapshot.put("observationTime", observationTime);
                    snapshot.put("hours", hours);
                    final String concise = weatherSymbol(code, day) + "  Szolnok  " + temp + "°";
                    final String full = weatherDescription(code) + "  ·  " + temp + " °C"
                            + "\nForrás: " + source + "\nFrissítve: " + updated;
                    long savedTime = System.currentTimeMillis();
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                            .putLong(WEATHER_TIME_KEY, savedTime)
                            .putString(WEATHER_LABEL_KEY, concise)
                            .putString(WEATHER_DETAILS_KEY, full)
                            .putString(WEATHER_JSON_KEY, snapshot.toString()).apply();
                    mainHandler.post(new Runnable() {
                        @Override public void run() {
                            if (szolnokWeatherChip != null && running) {
                                szolnokWeatherChip.setText(concise);
                                szolnokWeatherDetails = full;
                                szolnokWeatherSnapshot = snapshot;
                            }
                        }
                    });
                } catch (Exception ex) {
                    Log.w(TAG, "Szolnok időjárás lekérése sikertelen", ex);
                    mainHandler.post(new Runnable() {
                        @Override public void run() {
                            if (szolnokWeatherChip != null && running
                                    && szolnokWeatherChip.getText().toString().contains("--")) {
                                szolnokWeatherChip.setText("Szolnok  ·  nincs adat");
                                szolnokWeatherDetails = "Az időjárás most nem érhető el. Ellenőrizd az internetet.";
                            }
                        }
                    });
                } finally {
                    if (conn != null) conn.disconnect();
                    szolnokWeatherBusy = false;
                }
            }
        }, "TVHome-SzolnokWeather");
        worker.setDaemon(true);
        worker.start();
    }

    private void addHeader() {
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        greetingText = text(greetingForHour(), 29, 0xFFFFFFFF);
        greetingText.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        left.addView(greetingText);
        szolnokWeatherChip = text("Szolnok  ·  --°", 13, 0xE9FFFFFF);
        // Reuse the last successful weather result without loading the network on every Home.
        SharedPreferences weatherPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        long weatherSavedAt = weatherPrefs.getLong(WEATHER_TIME_KEY, 0L);
        long weatherAge = System.currentTimeMillis() - weatherSavedAt;
        if (weatherSavedAt > 0 && weatherAge >= 0
                && weatherAge < SZOLNOK_WEATHER_PERIOD_MS) {
            szolnokWeatherLastRequestMs = weatherSavedAt;
            szolnokWeatherChip.setText(weatherPrefs.getString(WEATHER_LABEL_KEY,
                    "Szolnok  ·  --°"));
            szolnokWeatherDetails = weatherPrefs.getString(WEATHER_DETAILS_KEY,
                    szolnokWeatherDetails);
            try {
                String json = weatherPrefs.getString(WEATHER_JSON_KEY, "");
                if (!json.isEmpty()) szolnokWeatherSnapshot = new JSONObject(json);
            } catch (JSONException ignored) { }
        }
        szolnokWeatherChip.setGravity(Gravity.CENTER_VERTICAL);
        szolnokWeatherChip.setPadding(dp(15), dp(6), dp(15), dp(6));
        szolnokWeatherChip.setBackground(new UltraGlassDrawable(18, 2));
        szolnokWeatherChip.setFocusable(true);
        szolnokWeatherChip.setId(View.generateViewId());
        szolnokWeatherChip.setClickable(true);
        szolnokWeatherChip.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                v.animate().scaleX(hasFocus ? 1.045f : 1f)
                        .scaleY(hasFocus ? 1.045f : 1f).setDuration(160L).start();
            }
        });
        szolnokWeatherChip.setContentDescription("Szolnok időjárása");
        LinearLayout.LayoutParams swp = new LinearLayout.LayoutParams(-2, dp(34));
        swp.topMargin = dp(8);
        left.addView(szolnokWeatherChip, swp);
        szolnokWeatherChip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSzolnokWeatherDetails(); }
        });
        // A datum es az ora tovabbra is jobboldalt, eredeti helyen marad.
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.TOP | Gravity.START);
        lp.setMargins(dp(48), dp(30), 0, 0);
        homeTop.addView(left, lp);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.RIGHT);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextSize(29);
        clock.setTextColor(0xFFFFFFFF);
        right.addView(clock);
        TextClock date = new TextClock(this);
        date.setFormat24Hour("MMM d., EEEE");
        date.setFormat12Hour("MMM d., EEEE");
        date.setTextSize(12);
        date.setTextColor(0xD5FFFFFF);
        date.setGravity(Gravity.RIGHT);
        right.addView(date);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.TOP | Gravity.END);
        rp.setMargins(0, dp(27), dp(48), 0);
        homeTop.addView(right, rp);

        // Az ora-datum nem mozdul; a ket kis gomb attol balra kap helyet.
        LinearLayout topActions = new LinearLayout(this);
        topActions.setOrientation(LinearLayout.HORIZONTAL);
        topActions.setGravity(Gravity.CENTER_VERTICAL);
        inputsButton = topButton("Források", new SourceIcon(), new Runnable() {
            @Override public void run() { showInputsMenu(); }
        });
        settingsButton = topButton("Beállítások", new GearIcon(), new Runnable() {
            @Override public void run() { showTvHomeSettings(); }
        });
        settingsClosedButtonBackground = settingsButton.getBackground();
        inputsButton.setId(View.generateViewId());
        settingsButton.setId(View.generateViewId());
        if (szolnokWeatherChip != null) {
            inputsButton.setNextFocusLeftId(szolnokWeatherChip.getId());
            szolnokWeatherChip.setNextFocusRightId(inputsButton.getId());
        }
        inputsButton.setNextFocusRightId(settingsButton.getId());
        settingsButton.setNextFocusLeftId(inputsButton.getId());
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(dp(39), dp(37));
        il.rightMargin = dp(7);
        topActions.addView(inputsButton, il);
        topActions.addView(settingsButton,
                new LinearLayout.LayoutParams(dp(39), dp(37)));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-2, -2,
                Gravity.TOP | Gravity.END);
        tl.setMargins(0, dp(33), dp(204), 0);
        homeTop.addView(topActions, tl);
    }

    // ================= TVHome 7.8 – Spotify Now Playing =================

    // TVHome 7.8.1 - kompakt, tiszta Liquid Glass zenevezerlo.
    private void addSpotifyNowPlaying() {
        spotifyPanel = new FrameLayout(this);
        spotifyPanel.setVisibility(View.GONE);
        spotifyPanel.setAlpha(0f);
        spotifyPanel.setClipChildren(false);
        spotifyPanel.setClipToPadding(false);
        // Nem uj nagy kartyat epitunk: csak a regi 300x54 dp-es kartya lesz kapszula.
        spotifyPanel.setBackground(new UltraGlassDrawable(27, 0));
        spotifyPanel.setElevation(dp(10));
        spotifyHaloView = new View(this);
        spotifyHaloDrawable = new MediaHaloDrawable();
        spotifyHaloView.setBackground(spotifyHaloDrawable);
        spotifyHaloView.setFocusable(false);
        spotifyHaloView.setVisibility(View.GONE);
        spotifyHaloView.setAlpha(0f);
        FrameLayout.LayoutParams haloPos = new FrameLayout.LayoutParams(
                dp(320), dp(74), Gravity.TOP | Gravity.START);
        haloPos.leftMargin = dp(188);
        haloPos.topMargin = dp(19);
        homeTop.addView(spotifyHaloView, haloPos);
        FrameLayout.LayoutParams panelPos = new FrameLayout.LayoutParams(
                dp(300), dp(54), Gravity.TOP | Gravity.START);
        panelPos.leftMargin = dp(198);
        panelPos.topMargin = dp(29);
        homeTop.addView(spotifyPanel, panelPos);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(dp(7), dp(5), dp(7), dp(5));
        spotifyPanel.addView(content, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout coverBox = new FrameLayout(this);
        coverBox.setBackground(glassRounded(new int[]{0xFF24354B, 0xFF101B2C}, 10,
                0x66FFFFFF, 1));
        // Fontos: a FrameLayout vagja le a borito sarkait is, ne csak a hatteret.
        coverBox.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(10));
            }
        });
        coverBox.setClipToOutline(true);
        spotifyAlbum = new ImageView(this);
        spotifyAlbum.setScaleType(ImageView.ScaleType.CENTER_CROP);
        spotifyAlbum.setVisibility(View.INVISIBLE);
        coverBox.addView(spotifyAlbum, new FrameLayout.LayoutParams(-1, -1));
        spotifyAlbumFallback = text("♪", 17, 0xDDFFFFFF);
        spotifyAlbumFallback.setGravity(Gravity.CENTER);
        coverBox.addView(spotifyAlbumFallback, new FrameLayout.LayoutParams(-1, -1));
        spotifyAlbumIncoming = new ImageView(this);
        spotifyAlbumIncoming.setScaleType(ImageView.ScaleType.CENTER_CROP);
        spotifyAlbumIncoming.setVisibility(View.GONE);
        coverBox.addView(spotifyAlbumIncoming, new FrameLayout.LayoutParams(-1, -1));
        // Borito 40 -> 35 dp, de a szoveg kezdopozicioja NEM valtozik: 40+8 = 35+13.
        LinearLayout.LayoutParams coverPos = new LinearLayout.LayoutParams(dp(35), dp(35));
        coverPos.rightMargin = dp(13);
        content.addView(coverBox, coverPos);

        spotifyTrackText = new MediaTrackTextAnimator();
        spotifySong = spotifyTrackText.steadyTitle;
        spotifyArtist = spotifyTrackText.steadyArtist;
        content.addView(spotifyTrackText.frame,
                new LinearLayout.LayoutParams(0, -1, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        spotifyPrevButton = spotifyButton(0, "Előző dal", new Runnable() {
            @Override public void run() { sendSpotifyCommand(0); }
        });
        spotifyPlayButton = spotifyButton(1, "Szünet / lejátszás", new Runnable() {
            @Override public void run() { sendSpotifyCommand(1); }
        });
        spotifyNextButton = spotifyButton(2, "Következő dal", new Runnable() {
            @Override public void run() { sendSpotifyCommand(2); }
        });
        spotifyPlayIcon = spotifyPlayButton;
        LinearLayout.LayoutParams prevPos = new LinearLayout.LayoutParams(dp(28), dp(28));
        prevPos.rightMargin = dp(4);
        controls.addView(spotifyPrevButton, prevPos);
        LinearLayout.LayoutParams playPos = new LinearLayout.LayoutParams(dp(28), dp(28));
        playPos.rightMargin = dp(4);
        controls.addView(spotifyPlayButton, playPos);
        controls.addView(spotifyNextButton, new LinearLayout.LayoutParams(dp(28), dp(28)));
        LinearLayout.LayoutParams controlPos = new LinearLayout.LayoutParams(-2, -2);
        controlPos.leftMargin = dp(6);
        content.addView(controls, controlPos);
        if (szolnokWeatherChip != null) {
            spotifyPrevButton.setNextFocusLeftId(szolnokWeatherChip.getId());
            szolnokWeatherChip.setNextFocusRightId(spotifyPrevButton.getId());
        }
        spotifyPrevButton.setNextFocusRightId(spotifyPlayButton.getId());
        spotifyPlayButton.setNextFocusLeftId(spotifyPrevButton.getId());
        spotifyPlayButton.setNextFocusRightId(spotifyNextButton.getId());
        spotifyNextButton.setNextFocusLeftId(spotifyPlayButton.getId());
        // Balrol jobbra: Spotify elozo > lejatszas > kovetkezo > Forrasok > Beallitasok.
        spotifyNextButton.setNextFocusRightId(inputsButton.getId());
        inputsButton.setNextFocusLeftId(spotifyNextButton.getId());
        if (szolnokWeatherChip != null) {
            spotifyPrevButton.setNextFocusLeftId(szolnokWeatherChip.getId());
            szolnokWeatherChip.setNextFocusRightId(spotifyPrevButton.getId());
        }
        spotifyProgressView = addMediaProgress(spotifyPanel);
    }

    /** Kompakt tvOS-szeru szovegvaltas. A szoveg helye nem valtozik,
     *  a regi dal BALRA kicsuszik, az uj JOBBROL erkezik. */
    private final class MediaTrackTextAnimator {
        final FrameLayout frame = new FrameLayout(MainActivity.this);
        final LinearLayout steady = createGroup();
        final LinearLayout arriving = createGroup();
        final TextView steadyTitle;
        final TextView steadyArtist;
        final TextView arrivingTitle;
        final TextView arrivingArtist;
        String displayedTitle = "";
        String displayedArtist = "";
        int serial = 0;

        MediaTrackTextAnimator() {
            frame.setClipChildren(true);
            frame.setClipToPadding(true);
            frame.addView(steady, new FrameLayout.LayoutParams(-1, -1));
            frame.addView(arriving, new FrameLayout.LayoutParams(-1, -1));
            arriving.setVisibility(View.GONE);
            steadyTitle = (TextView) steady.getChildAt(0);
            steadyArtist = (TextView) steady.getChildAt(1);
            arrivingTitle = (TextView) arriving.getChildAt(0);
            arrivingArtist = (TextView) arriving.getChildAt(1);
        }

        private LinearLayout createGroup() {
            LinearLayout group = new LinearLayout(MainActivity.this);
            group.setOrientation(LinearLayout.VERTICAL);
            group.setGravity(Gravity.CENTER_VERTICAL);
            TextView song = text("", 12, 0xFFFFFFFF);
            song.setTypeface(android.graphics.Typeface.DEFAULT,
                    android.graphics.Typeface.BOLD);
            song.setSingleLine(true);
            song.setEllipsize(TextUtils.TruncateAt.END);
            TextView artist = text("", 10, 0xC9FFFFFF);
            artist.setSingleLine(true);
            artist.setEllipsize(TextUtils.TruncateAt.END);
            group.addView(song);
            LinearLayout.LayoutParams artistLp = new LinearLayout.LayoutParams(-1, -2);
            artistLp.topMargin = dp(2);
            group.addView(artist, artistLp);
            return group;
        }

        /** @return true, ha valodi, mar lathato dalrol valtottunk ujra. */
        boolean setTrack(String title, String artist) {
            final String nextTitle = title == null ? "" : title;
            final String nextArtist = TextUtils.isEmpty(artist) ? "Spotify" : artist;
            if (TextUtils.equals(displayedTitle, nextTitle)
                    && TextUtils.equals(displayedArtist, nextArtist)) return false;
            final boolean realChange = !TextUtils.isEmpty(displayedTitle);
            ++serial;
            steady.animate().cancel();
            arriving.animate().cancel();
            steady.setAlpha(1f);
            steady.setTranslationX(0f);
            arriving.setVisibility(View.GONE);
            // Ha gyorsan egymas utan valt a felhasznalo, a legutobbi
            // elfogadott dal legyen a kovetkezo animacio kiindulasa.
            steadyTitle.setText(displayedTitle);
            steadyArtist.setText(displayedArtist);
            displayedTitle = nextTitle;
            displayedArtist = nextArtist;
            if (!realChange) {
                steadyTitle.setText(nextTitle);
                steadyArtist.setText(nextArtist);
                return false;
            }
            arrivingTitle.setText(nextTitle);
            arrivingArtist.setText(nextArtist);
            arriving.setVisibility(View.VISIBLE);
            arriving.setAlpha(0f);
            arriving.setTranslationX(dp(23));
            final int thisSerial = serial;
            steady.animate().translationX(-dp(23)).alpha(0f)
                    .setDuration(245L).setInterpolator(tvEase).start();
            arriving.animate().translationX(0f).alpha(1f)
                    .setStartDelay(48L).setDuration(310L).setInterpolator(tvEase)
                    .withEndAction(new Runnable() {
                        @Override public void run() {
                            if (serial != thisSerial) return;
                            steadyTitle.setText(nextTitle);
                            steadyArtist.setText(nextArtist);
                            steady.animate().cancel();
                            steady.setTranslationX(0f);
                            steady.setAlpha(1f);
                            arriving.setVisibility(View.GONE);
                            arriving.setTranslationX(0f);
                            arriving.setAlpha(0f);
                        }
                    }).start();
            return true;
        }

        void clear() {
            ++serial;
            steady.animate().cancel();
            arriving.animate().cancel();
            steady.setAlpha(1f);
            steady.setTranslationX(0f);
            arriving.setVisibility(View.GONE);
            arriving.setAlpha(0f);
            arriving.setTranslationX(0f);
            displayedTitle = "";
            displayedArtist = "";
            steadyTitle.setText("");
            steadyArtist.setText("");
        }
    }

    /** Amikor uj dal kezdodik: az idovonal finoman megfrissul, nem ugrik hirtelen. */
    private void animateProgressSongSwitch() {
        animateOneProgressSwitch(spotifyProgressView);
        animateOneProgressSwitch(ambientProgressView);
    }

    private void animateOneProgressSwitch(MediaProgressView bar) {
        if (bar == null || bar.getVisibility() != View.VISIBLE) return;
        bar.animate().cancel();
        bar.setAlpha(0.28f);
        bar.animate().alpha(1f).setDuration(345L).setInterpolator(tvEase).start();
    }

    // ================= TVHome 8.0 – Mini Music Capsule =================

    /** TVHome 8.1.1 - valodi, egybefuggo Gaussian Media Glow.
     *  Nincs egyetlen konturcsik sem. Egy elore letrehozott, kicsi alpha
     *  bitmapen levo elmosott kapszula adja a folytonos soft aurat.
     *  Szamvaltaskor csak a GPU-val tintelt bitmap szine valtozik; a TV-nek
     *  nem kell ujra blur-t szamolnia az animacio minden frame-jeben.
     */
    private final class MediaHaloDrawable extends Drawable {
        private int accent = MEDIA_NEUTRAL_ACCENT;
        private int drawableAlpha = 255;
        private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG
                | Paint.FILTER_BITMAP_FLAG);
        private android.graphics.PorterDuffColorFilter tint;
        private final float[] hsv = new float[3];

        void setAccent(int color) {
            if (accent == (0xFF000000 | (color & 0x00FFFFFF)) && tint != null) return;
            accent = 0xFF000000 | (color & 0x00FFFFFF);
            // Azonos alapszin, csak vilagosabb fenyero: az album hue-ja
            // megmarad, nem feheredik ki es nem valik minden borito kekke.
            android.graphics.Color.colorToHSV(accent, hsv);
            hsv[1] = Math.max(0.52f, hsv[1]);
            hsv[2] = Math.max(0.87f, hsv[2]);
            int light = android.graphics.Color.HSVToColor(hsv);
            tint = new android.graphics.PorterDuffColorFilter(
                    light, PorterDuff.Mode.SRC_IN);
            invalidateSelf();
        }

        private void ensureMask(int w, int h) {
            if (sharedMediaHaloMask != null && !sharedMediaHaloMask.isRecycled()
                    && w == sharedMediaHaloMask.getWidth() && h == sharedMediaHaloMask.getHeight()) return;
            // Both capsules have the same geometry. Their tint/alpha remain independent.
            // Drop the old reference; a recorded hardware display list may still use it.
            sharedMediaHaloMask = null;
            if (w <= 0 || h <= 0) return;
            try {
                Bitmap mask = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8);
                Canvas software = new Canvas(mask);
                Paint bloom = new Paint(Paint.ANTI_ALIAS_FLAG);
                bloom.setColor(0xFFFFFFFF);
                bloom.setStyle(Paint.Style.FILL);
                bloom.setMaskFilter(new BlurMaskFilter(dp(8f),
                        BlurMaskFilter.Blur.NORMAL));
                float left = (w - dp(300)) * 0.5f;
                float top = (h - dp(54)) * 0.5f;
                // Egyetlen tomor, elmosott alakzat. A kapszula eltakarja
                // a kozepet; csak a puhán eltuno kulso fenyudvar latszik.
                software.drawRoundRect(left, top, left + dp(300),
                        top + dp(54), dp(27), dp(27), bloom);
                bloom.setMaskFilter(null);
                sharedMediaHaloMask = mask;
            } catch (OutOfMemoryError memory) {
                // A launcher tovabb mukodik glow nelkul is, ha elfogy a RAM.
                sharedMediaHaloMask = null;
            }
        }

        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) return;
            ensureMask(b.width(), b.height());
            if (sharedMediaHaloMask == null) return;
            if (tint == null) setAccent(accent);
            haloPaint.setColorFilter(tint);
            // Joval lathatobb, ugyanakkor vonalak nelkuli, puhán kifuto halo.
            haloPaint.setAlpha(Math.round(drawableAlpha * 0.93f));
            canvas.drawBitmap(sharedMediaHaloMask, b.left, b.top, haloPaint);
        }

        @Override public void setAlpha(int alpha) {
            drawableAlpha = Math.max(0, Math.min(255, alpha));
            invalidateSelf();
        }
        @Override public void setColorFilter(ColorFilter ignored) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Allando, puha vegu zene-idovonal mini poziciojelolo pottyel. */
    private final class MediaProgressView extends View {
        private float fraction = 0f;
        private boolean progressKnown = false;
        private int accent = 0xFFCBEAFF;
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumb = new Paint(Paint.ANTI_ALIAS_FLAG);

        MediaProgressView() { super(MainActivity.this); setFocusable(false); }
        void setFraction(float progress) {
            float next = Math.max(0f, Math.min(1f, progress));
            if (Math.abs(next - fraction) * Math.max(1, getWidth()) < 0.5f) return;
            fraction = next;
            invalidate();
        }
        void setProgressKnown(boolean known) {
            if (progressKnown == known) return;
            progressKnown = known;
            invalidate();
        }
        void setAccent(int color) {
            if (accent == (0xFF000000 | (color & 0x00FFFFFF))) return;
            accent = 0xFF000000 | (color & 0x00FFFFFF);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth(), height = getHeight();
            if (width <= 0 || height <= 0) return;
            float cy = height / 2f;
            float dotRadius = dp(2.8f);
            float x0 = dotRadius + dp(1f);
            float x1 = width - dotRadius - dp(1f);
            if (x1 <= x0) return;
            float trackHalfHeight = dp(1.1f);
            float fillHalfHeight = dp(1.25f);
            float posX = x0 + fraction * (x1 - x0);
            track.setColor(0x55FFFFFF);
            track.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(x0, cy - trackHalfHeight,
                    x1, cy + trackHalfHeight, trackHalfHeight, trackHalfHeight, track);

            if (!progressKnown) return; // Ismeretlen dalhossz: nem mutat hamis poziciot.
            int r = (accent >> 16) & 255, g = (accent >> 8) & 255, b = accent & 255;
            // A vilagos szin a sotet uvegen jobban olvashato, nem rikito.
            r = Math.round(r * 0.27f + 255f * 0.73f);
            g = Math.round(g * 0.27f + 255f * 0.73f);
            b = Math.round(b * 0.27f + 255f * 0.73f);
            int softAccent = 0xFF000000 | (r << 16) | (g << 8) | b;
            fill.setColor(softAccent);
            fill.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(x0, cy - fillHalfHeight,
                    Math.max(x0 + dp(1f), posX), cy + fillHalfHeight,
                    fillHalfHeight, fillHalfHeight, fill);

            // Csak egy elegans mini potty: nagyon halvany kulso aura + eles feher mag.
            thumb.setColor((43 << 24) | (r << 16) | (g << 8) | b);
            canvas.drawCircle(posX, cy, dotRadius + dp(1.4f), thumb);
            thumb.setColor(0xFFF8FBFF);
            canvas.drawCircle(posX, cy, dotRadius, thumb);
        }
    }

    private MediaProgressView addMediaProgress(FrameLayout parent) {
        MediaProgressView bar = new MediaProgressView();
        bar.setVisibility(View.GONE);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                -1, dp(8), Gravity.BOTTOM);
        params.leftMargin = dp(12);
        params.rightMargin = dp(12);
        params.bottomMargin = 0;
        parent.addView(bar, params);
        return bar;
    }

    private boolean isMediaProgressVisible() {
        return (spotifyProgressView != null
                && spotifyProgressView.getVisibility() == View.VISIBLE)
                || (ambientProgressView != null
                && ambientProgressView.getVisibility() == View.VISIBLE);
    }

    private void syncMediaProgressVisibility() {
        // Mindket kapszulan ALLANDO a progress, fokusszal es anelkul is.
        // Az Ambient 10 mp-es fokuszidozitoje a savot NEM tunteti el.
        boolean showHome = !ambientActive && spotifyProgressView != null
                && spotifyPanel != null && spotifyPanel.getVisibility() == View.VISIBLE;
        boolean showAmbient = ambientActive && ambientProgressView != null
                && ambientSpotifyContainer != null
                && ambientSpotifyContainer.getVisibility() == View.VISIBLE;
        if (spotifyProgressView != null)
            spotifyProgressView.setVisibility(showHome ? View.VISIBLE : View.GONE);
        if (ambientProgressView != null)
            ambientProgressView.setVisibility(showAmbient ? View.VISIBLE : View.GONE);
        boolean known = spotifyDurationMs > 0;
        if (spotifyProgressView != null) spotifyProgressView.setProgressKnown(known);
        if (ambientProgressView != null) ambientProgressView.setProgressKnown(known);
        mainHandler.removeCallbacks(spotifyProgressTicker);
        if (showHome || showAmbient) {
            updateVisibleMediaProgress();
            if (known && spotifyProgressPlaying)
                mainHandler.postDelayed(spotifyProgressTicker, 250L);
        }
    }

    private void setSpotifyProgress(long elapsedMs, long durationMs, long sampledAtMs,
                                    boolean playing) {
        spotifyDurationMs = Math.max(0L, durationMs);
        spotifyProgressMs = Math.max(0L, elapsedMs);
        spotifyProgressSampleTimeMs = sampledAtMs;
        spotifyProgressPlaying = playing;
        syncMediaProgressVisibility();
    }

    private void updateVisibleMediaProgress() {
        if (spotifyDurationMs <= 0) return;
        long elapsed = spotifyProgressMs;
        if (spotifyProgressPlaying)
            elapsed += Math.max(0, SystemClock.elapsedRealtime() - spotifyProgressSampleTimeMs);
        float f = Math.min(1f, Math.max(0f, elapsed / (float) spotifyDurationMs));
        if (spotifyProgressView != null && spotifyProgressView.getVisibility() == View.VISIBLE)
            spotifyProgressView.setFraction(f);
        if (ambientProgressView != null && ambientProgressView.getVisibility() == View.VISIBLE)
            ambientProgressView.setFraction(f);
    }

    private void installAmbientSpotifyCapsule(LinearLayout timeStack) {
        // Ora -> datum -> ugyanakkora 300x54-es zenei kapszula, nincs expanded view.
        ambientSpotifyContainer = new FrameLayout(this);
        ambientSpotifyContainer.setVisibility(View.GONE);
        ambientSpotifyContainer.setClipChildren(false);
        ambientSpotifyContainer.setClipToPadding(false);
        LinearLayout.LayoutParams wrapper = new LinearLayout.LayoutParams(dp(320), dp(74));
        wrapper.topMargin = dp(14);
        wrapper.gravity = Gravity.CENTER_HORIZONTAL;
        timeStack.addView(ambientSpotifyContainer, wrapper);

        View halo = new View(this);
        ambientHaloDrawable = new MediaHaloDrawable();
        halo.setBackground(ambientHaloDrawable);
        ambientSpotifyContainer.addView(halo, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout capsule = new FrameLayout(this);
        capsule.setBackground(new UltraGlassDrawable(27, 0));
        capsule.setElevation(dp(10));
        capsule.setClipChildren(false);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                dp(300), dp(54), Gravity.CENTER);
        ambientSpotifyContainer.addView(capsule, cp);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(dp(7), dp(5), dp(7), dp(5));
        capsule.addView(content, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout cover = new FrameLayout(this);
        cover.setBackground(glassRounded(new int[]{0xFF24354B, 0xFF101B2C},
                10, 0x66FFFFFF, 1));
        cover.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(10));
            }
        });
        cover.setClipToOutline(true);
        ambientSpotifyAlbum = new ImageView(this);
        ambientSpotifyAlbum.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ambientSpotifyAlbum.setVisibility(View.INVISIBLE);
        cover.addView(ambientSpotifyAlbum, new FrameLayout.LayoutParams(-1, -1));
        ambientSpotifyAlbumFallback = text("♪", 17, 0xDDFFFFFF);
        ambientSpotifyAlbumFallback.setGravity(Gravity.CENTER);
        cover.addView(ambientSpotifyAlbumFallback, new FrameLayout.LayoutParams(-1, -1));
        ambientSpotifyAlbumIncoming = new ImageView(this);
        ambientSpotifyAlbumIncoming.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ambientSpotifyAlbumIncoming.setVisibility(View.GONE);
        cover.addView(ambientSpotifyAlbumIncoming, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams coverLp = new LinearLayout.LayoutParams(dp(35), dp(35));
        coverLp.rightMargin = dp(13);
        content.addView(cover, coverLp);

        ambientTrackText = new MediaTrackTextAnimator();
        ambientSpotifySong = ambientTrackText.steadyTitle;
        ambientSpotifyArtist = ambientTrackText.steadyArtist;
        content.addView(ambientTrackText.frame,
                new LinearLayout.LayoutParams(0, -1, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        ambientSpotifyPrevButton = spotifyButton(0, "Ambient – előző", new Runnable() {
            @Override public void run() { sendSpotifyCommand(0); }
        });
        ambientSpotifyPlayButton = spotifyButton(1, "Ambient – lejátszás / szünet", new Runnable() {
            @Override public void run() { sendSpotifyCommand(1); }
        });
        ambientSpotifyNextButton = spotifyButton(2, "Ambient – következő", new Runnable() {
            @Override public void run() { sendSpotifyCommand(2); }
        });
        ambientSpotifyPlayIcon = ambientSpotifyPlayButton;
        // Nyugalmi Ambientben egyik gomb sem vehet magatol fokuszt.
        ambientSpotifyPrevButton.setFocusable(false);
        ambientSpotifyPlayButton.setFocusable(false);
        ambientSpotifyNextButton.setFocusable(false);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(dp(28), dp(28));
        left.rightMargin = dp(4);
        controls.addView(ambientSpotifyPrevButton, left);
        LinearLayout.LayoutParams center = new LinearLayout.LayoutParams(dp(28), dp(28));
        center.rightMargin = dp(4);
        controls.addView(ambientSpotifyPlayButton, center);
        controls.addView(ambientSpotifyNextButton,
                new LinearLayout.LayoutParams(dp(28), dp(28)));
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(-2, -2);
        controlsLp.leftMargin = dp(6);
        content.addView(controls, controlsLp);
        ambientProgressView = addMediaProgress(capsule);
    }

    private void updateAmbientSpotifyData(String title, String artist, int playback) {
        if (ambientSpotifyContainer == null) return;
        if (ambientTrackText != null) ambientTrackText.setTrack(title, artist);
        int iconKind = playback == PlaybackState.STATE_PLAYING ? 1 : 3;
        Drawable shownIcon = ambientSpotifyPlayIcon.getDrawable();
        if (!(shownIcon instanceof SpotifyControlIcon)
                || ((SpotifyControlIcon) shownIcon).kind != iconKind)
            ambientSpotifyPlayIcon.setImageDrawable(new SpotifyControlIcon(iconKind));
        if (ambientSpotifyContainer.getVisibility() != View.VISIBLE) {
            ambientSpotifyContainer.setVisibility(View.VISIBLE);
            if (ambientActive) {
                ambientSpotifyContainer.setAlpha(0f);
                ambientSpotifyContainer.animate().alpha(1f).setDuration(220L).start();
            } else ambientSpotifyContainer.setAlpha(1f);
        }
        syncMediaProgressVisibility();
    }

    private void hideAmbientSpotifyPanel() {
        clearAmbientMediaSelection();
        if (ambientSpotifyContainer != null) {
            ambientSpotifyContainer.animate().cancel();
            ambientSpotifyContainer.setVisibility(View.GONE);
        }
        clearCoverAnimation(ambientSpotifyAlbum, ambientSpotifyAlbumIncoming,
                ambientSpotifyAlbumFallback);
        if (ambientTrackText != null) ambientTrackText.clear();
    }

    private void selectAmbientMediaControl() {
        if (ambientSpotifyContainer == null
                || ambientSpotifyContainer.getVisibility() != View.VISIBLE) return;
        ambientControlSelected = true;
        ambientSpotifyPrevButton.setFocusable(true);
        ambientSpotifyPlayButton.setFocusable(true);
        ambientSpotifyNextButton.setFocusable(true);
        ambientSpotifyPlayButton.requestFocus();
        syncMediaProgressVisibility();
        mainHandler.removeCallbacks(ambientMediaFocusTimeout);
        mainHandler.postDelayed(ambientMediaFocusTimeout, AMBIENT_MEDIA_FOCUS_TIMEOUT_MS);
    }

    private void clearAmbientMediaSelection() {
        mainHandler.removeCallbacks(ambientMediaFocusTimeout);
        if (!ambientControlSelected) return;
        ambientControlSelected = false;
        if (ambientSpotifyPrevButton != null) ambientSpotifyPrevButton.clearFocus();
        if (ambientSpotifyPlayButton != null) ambientSpotifyPlayButton.clearFocus();
        if (ambientSpotifyNextButton != null) ambientSpotifyNextButton.clearFocus();
        // A ViewGroup nem helyezheti vissza automatikusan a fokuszt a kapszulaba.
        if (ambientSpotifyPrevButton != null) ambientSpotifyPrevButton.setFocusable(false);
        if (ambientSpotifyPlayButton != null) ambientSpotifyPlayButton.setFocusable(false);
        if (ambientSpotifyNextButton != null) ambientSpotifyNextButton.setFocusable(false);
        syncMediaProgressVisibility();
    }

    /** Ambient: nyugalmi allapotbol CSAK LE aktivál, mas gomb felébreszt.
     * Aktiv vezerlesnel a nyilak a harom gomb kozott mozognak; Vissza=Home.
     * 10 s inaktivitas utan eltunik a fókusz, LE-vel ujra belephetunk. */
    private boolean handleAmbientMediaKey(KeyEvent event) {
        int key = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (!ambientControlSelected) {
            if (key == KeyEvent.KEYCODE_DPAD_DOWN
                    && ambientSpotifyContainer != null
                    && ambientSpotifyContainer.getVisibility() == View.VISIBLE) {
                if (down && event.getRepeatCount() == 0) selectAmbientMediaControl();
                return true;
            }
            if (down) { leaveAmbientMode(true); ambientWakeKey = key; }
            return true;
        }
        if (key == KeyEvent.KEYCODE_BACK) {
            if (down) { leaveAmbientMode(true); ambientWakeKey = key; }
            return true;
        }
        if (isOkKey(key)) {
            if (!down && !event.isCanceled()) {
                View focus = getCurrentFocus();
                sendSpotifyCommand(focus == ambientSpotifyPrevButton ? 0
                        : focus == ambientSpotifyNextButton ? 2 : 1);
            }
            if (down) resetAmbientMediaFocusTimer();
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT) {
            if (down) {
                View focused = getCurrentFocus();
                if (key == KeyEvent.KEYCODE_DPAD_LEFT) {
                    if (focused == ambientSpotifyNextButton) ambientSpotifyPlayButton.requestFocus();
                    else ambientSpotifyPrevButton.requestFocus();
                } else {
                    if (focused == ambientSpotifyPrevButton) ambientSpotifyPlayButton.requestFocus();
                    else ambientSpotifyNextButton.requestFocus();
                }
                resetAmbientMediaFocusTimer();
            }
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_UP) {
            if (down && event.getRepeatCount() == 0) clearAmbientMediaSelection();
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (down) resetAmbientMediaFocusTimer();
            return true;
        }
        // Ismeretlen gomb: ne induljon el a kijelolt alkalmazas a hatterben.
        if (down) { leaveAmbientMode(true); ambientWakeKey = key; }
        return true;
    }

    private void resetAmbientMediaFocusTimer() {
        mainHandler.removeCallbacks(ambientMediaFocusTimeout);
        mainHandler.postDelayed(ambientMediaFocusTimeout, AMBIENT_MEDIA_FOCUS_TIMEOUT_MS);
    }

    /** A borito karakteres szinenek kivalasztasa hue-szegmensek szerint.
     *  A teljes RGB atlag elfakult/szurke lehet. Itt a jellegzetes szines
     *  keppontok dominalnak, nem a fekete hatter vagy a feher felirat.
     *  Kicsi (max 200px) boriton fut, csak uj szamnal, egyszer.
     */
    private int artAccent(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return MEDIA_NEUTRAL_ACCENT;
        final int hueGroups = 24;
        float[] bins = new float[hueGroups];
        float[] hueSums = new float[hueGroups];
        float[] satSums = new float[hueGroups];
        float[] valSums = new float[hueGroups];
        float[] hsv = new float[3];
        float coloredWeight = 0f;
        int sampled = 0, colorful = 0;
        try {
            int step = Math.max(1,
                    Math.min(bitmap.getWidth(), bitmap.getHeight()) / 44);
            for (int y = step / 2; y < bitmap.getHeight(); y += step) {
                for (int x = step / 2; x < bitmap.getWidth(); x += step) {
                    int color = bitmap.getPixel(x, y);
                    if (((color >>> 24) & 255) < 160) continue;
                    ++sampled;
                    android.graphics.Color.colorToHSV(color, hsv);
                    float sat = hsv[1], value = hsv[2];
                    if (sat < 0.18f || value < 0.11f || value > 0.98f) continue;
                    ++colorful;
                    float weight = (0.3f + 1.7f * sat * sat)
                            * Math.min(1f, value * 1.4f);
                    int group = Math.min(hueGroups - 1,
                            (int) (hsv[0] * hueGroups / 360f));
                    bins[group] += weight;
                    hueSums[group] += hsv[0] * weight;
                    satSums[group] += sat * weight;
                    valSums[group] += value * weight;
                    coloredWeight += weight;
                }
            }
        } catch (RuntimeException ignored) { return MEDIA_NEUTRAL_ACCENT; }
        if (sampled == 0 || colorful < Math.max(3, sampled / 22)
                || coloredWeight < 0.5f) return MEDIA_NEUTRAL_ACCENT;
        int primary = 0;
        for (int i = 1; i < hueGroups; ++i) {
            if (bins[i] > bins[primary]) primary = i;
        }
        // Kozelebbi hue-k az egybefuggo szinmezot alkotjak (pl. piros/narancs).
        float h = 0f, sat = 0f, val = 0f, weightTotal = 0f;
        for (int offset = -1; offset <= 1; ++offset) {
            int group = (primary + offset + hueGroups) % hueGroups;
            float weight = bins[group];
            if (weight <= 0f) continue;
            float colorHue = hueSums[group] / weight;
            if (primary == 0 && group == hueGroups - 1) colorHue -= 360f;
            if (primary == hueGroups - 1 && group == 0) colorHue += 360f;
            h += colorHue * weight;
            sat += satSums[group];
            val += valSums[group];
            weightTotal += weight;
        }
        if (weightTotal <= 0f) return MEDIA_NEUTRAL_ACCENT;
        float hue = (h / weightTotal + 360f) % 360f;
        // Kellemes, de jol azonosithato boritoszin. Sotet boriton is lathato.
        float saturation = Math.max(0.42f, Math.min(0.76f, sat / weightTotal));
        float brightness = Math.max(0.55f, Math.min(0.83f, val / weightTotal));
        return android.graphics.Color.HSVToColor(new float[]{hue, saturation, brightness});
    }

    private void applyMediaAccentFrame(int color) {
        mediaAccentCurrent = color;
        if (spotifyHaloDrawable != null) spotifyHaloDrawable.setAccent(color);
        if (ambientHaloDrawable != null) ambientHaloDrawable.setAccent(color);
        if (spotifyProgressView != null) spotifyProgressView.setAccent(color);
        if (ambientProgressView != null) ambientProgressView.setAccent(color);
    }

    /** A home es az Ambient glow ugyanazt a boritoszint kapja,
     *  680 ms alatt egyenletesen atusztatva, villanas nelkul. */
    private void setMediaAccent(final int accent) {
        int next = 0xFF000000 | (accent & 0x00FFFFFF);
        if (next == mediaAccentTarget) return;
        if (mediaAccentAnimator != null) {
            mediaAccentAnimator.cancel();
            mediaAccentAnimator = null;
        }
        mediaAccentTarget = next;
        final ValueAnimator animator = ValueAnimator.ofObject(
                new android.animation.ArgbEvaluator(), mediaAccentCurrent, next);
        mediaAccentAnimator = animator;
        animator.setDuration(680L);
        animator.setInterpolator(tvEase);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                if (mediaAccentAnimator != a) return;
                applyMediaAccentFrame((Integer) a.getAnimatedValue());
            }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled = false;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (mediaAccentAnimator != a) return;
                mediaAccentAnimator = null;
                if (!cancelled) applyMediaAccentFrame(mediaAccentTarget);
            }
        });
        animator.start();
    }

    private void resetMediaAccent() {
        if (mediaAccentAnimator != null) {
            mediaAccentAnimator.cancel();
            mediaAccentAnimator = null;
        }
        mediaAccentTarget = MEDIA_NEUTRAL_ACCENT;
        applyMediaAccentFrame(MEDIA_NEUTRAL_ACCENT);
    }

    private Drawable spotifyCircle(boolean active) {
        GradientDrawable circle = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                active ? new int[]{0xF26AB5F3, 0xEF306A9E}
                       : new int[]{0x80425875, 0x6830415A});
        circle.setShape(GradientDrawable.OVAL);
        circle.setStroke(dp(1), active ? 0xFFFFFFFF : 0x77FFFFFF);
        return circle;
    }

    private ImageView spotifyButton(int glyph, String description, final Runnable callback) {
        ImageView button = new ImageView(this);
        button.setImageDrawable(new SpotifyControlIcon(glyph));
        button.setScaleType(ImageView.ScaleType.FIT_CENTER);
        button.setPadding(dp(4), dp(4), dp(4), dp(4));
        button.setFocusable(true);
        button.setClickable(true);
        button.setId(View.generateViewId());
        button.setContentDescription(description);
        StateListDrawable background = new StateListDrawable();
        background.addState(new int[]{android.R.attr.state_focused}, spotifyCircle(true));
        background.addState(new int[]{android.R.attr.state_pressed}, spotifyCircle(true));
        background.addState(new int[]{}, spotifyCircle(false));
        button.setBackground(background);
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { callback.run(); }
        });
        return button;
    }

    /** Egyszeru, eles, anti-aliasolt zeneikonok a bizonytalan betukeszlet helyett. */
    private static final class SpotifyControlIcon extends Drawable {
        // 0: previous, 1: pause, 2: next, 3: play
        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path shape = new Path();
        private int alpha = 255;
        SpotifyControlIcon(int kind) {
            this.kind = kind;
            if (kind == 3) {
                shape.moveTo(10.5f, 7.4f); shape.lineTo(10.5f, 20.6f);
                shape.lineTo(21f, 14f); shape.close();
            } else if (kind == 2) {
                shape.moveTo(5.7f, 8f); shape.lineTo(5.7f, 20f);
                shape.lineTo(12.7f, 14f); shape.close();
                shape.moveTo(12.6f, 8f); shape.lineTo(12.6f, 20f);
                shape.lineTo(19.6f, 14f); shape.close();
            } else if (kind != 1) {
                shape.moveTo(22.3f, 8f); shape.lineTo(22.3f, 20f);
                shape.lineTo(15.3f, 14f); shape.close();
                shape.moveTo(15.4f, 8f); shape.lineTo(15.4f, 20f);
                shape.lineTo(8.4f, 14f); shape.close();
            }
        }
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.isEmpty()) return;
            canvas.save();
            float scale = Math.min(b.width(), b.height()) / 28f;
            canvas.translate(b.centerX(), b.centerY());
            canvas.scale(scale, scale);
            canvas.translate(-14f, -14f);
            p.setColor(0xFFFFFFFF);
            p.setAlpha(alpha);
            p.setStyle(Paint.Style.FILL);
            if (kind == 1) {
                canvas.drawRoundRect(9, 7.5f, 12.5f, 20.5f, 1.2f, 1.2f, p);
                canvas.drawRoundRect(15.5f, 7.5f, 19, 20.5f, 1.2f, 1.2f, p);
            } else if (kind == 3) {
                canvas.drawPath(shape, p);
            } else {
                boolean forward = kind == 2;
                if (forward) {
                    canvas.drawRoundRect(20.2f, 8f, 22.3f, 20f, 0.7f, 0.7f, p);
                    canvas.drawPath(shape, p);
                } else {
                    canvas.drawRoundRect(5.7f, 8f, 7.8f, 20f, 0.7f, 0.7f, p);
                    canvas.drawPath(shape, p);
                }
            }
            canvas.restore();
        }
        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { p.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private boolean spotifyButtonHasFocus(View focus) {
        return focus != null && (focus == spotifyPrevButton
                || focus == spotifyPlayButton || focus == spotifyNextButton);
    }

    /** A TV D-pad OK lenyomasat kulon iranyitjuk, nem bizzuk az alapertelmezett
     * TextView/ImageView felengedesi esemenyekre. */
    private boolean handleSpotifyControlKey(KeyEvent event) {
        View focused = getCurrentFocus();
        if (spotifyPanel == null || spotifyPanel.getVisibility() != View.VISIBLE
                || !spotifyButtonHasFocus(focused) || gridMode || modalView != null
                || pickerView != null || editorView != null || moving) return false;
        int key = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (isOkKey(key)) {
            // Az Android TV taviranyitok egy resze nem ugyanazzal a koddal
            // adja a DOWN/UP jelet. A felengedes mindig pontosan egyszer aktival.
            if (!down && !event.isCanceled()) {
                final int which = focused == spotifyPrevButton ? 0
                        : focused == spotifyNextButton ? 2 : 1;
                Log.i(TAG, "Spotify TV gomb aktiv: " + which);
                sendSpotifyCommand(which);
            }
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT
                || key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (down && event.getRepeatCount() == 0) {
                View target = null;
                if (key == KeyEvent.KEYCODE_DPAD_LEFT)
                    target = focused == spotifyNextButton ? spotifyPlayButton
                            : focused == spotifyPlayButton ? spotifyPrevButton : szolnokWeatherChip;
                else if (key == KeyEvent.KEYCODE_DPAD_RIGHT)
                    target = focused == spotifyPrevButton ? spotifyPlayButton
                            : focused == spotifyPlayButton ? spotifyNextButton : inputsButton;
                else if (key == KeyEvent.KEYCODE_DPAD_UP) target = inputsButton;
                else if (dock != null && dock.getChildCount() > 0)
                    target = dock.getChildAt(Math.max(0, Math.min(lastFocusedDockIndex,
                            dock.getChildCount() - 1)));
                if (target != null) target.requestFocus();
            }
            return true;
        }
        return false;
    }

    private void updateSpotifySession() {
        if (spotifyPanel == null) return;
        // Spotify Web API: koveti a fiok AKTIV eszkozet (PC / iPhone / Android),
        // a TV-s MediaSession-nek nem kell futnia.
        if (spotifyApi != null && spotifyApi.isLinked()) {
            spotifyApi.poll(new Runnable() {
                @Override public void run() { if (running) updateSpotifySession(); }
            });
            SpotifyWebApi.Snapshot item = spotifyApi.snapshot();
            if (item == null || TextUtils.isEmpty(item.title)) {
                hideSpotifyPanel();
                return;
            }
            int playback = item.playing ? PlaybackState.STATE_PLAYING
                    : PlaybackState.STATE_PAUSED;
            spotifyPlaybackState = playback;
            long now = SystemClock.elapsedRealtime();
            if (item.playing) spotifyLastPlayingAt = now;
            if (!item.playing && (spotifyLastPlayingAt == 0
                    || now - spotifyLastPlayingAt > SPOTIFY_PAUSE_GRACE_MS)) {
                hideSpotifyPanel();
                return;
            }
            boolean changedSong = spotifyTrackText.setTrack(item.title, item.artist);
            updateAmbientSpotifyData(item.title, item.artist, playback);
            setSpotifyProgress(item.progressMs, item.durationMs, item.sampledAtMs, item.playing);
            if (changedSong) animateProgressSongSwitch();
            if (spotifyShownPlaybackState != playback) {
                spotifyPlayIcon.setImageDrawable(new SpotifyControlIcon(item.playing ? 1 : 3));
                spotifyShownPlaybackState = playback;
            }
            if (spotifyPanel.getVisibility() != View.VISIBLE) {
                spotifyPanel.animate().cancel();
                spotifyPanel.setVisibility(View.VISIBLE);
                spotifyPanel.setAlpha(0f);
                spotifyPanel.animate().alpha(1f).setDuration(220L).start();
                showSpotifyHalo();
                syncMediaProgressVisibility(); // Azonnal megjelenik a progress is.
            }
            // Meglevo, HTTPS kepbetolto; a 35 dp-es borito 10 dp-re lekerekitett.
            String artKey = item.title + "|" + (TextUtils.isEmpty(item.coverUrl) ? "bitmap" : item.coverUrl);
            if (!artKey.equals(spotifyArtKey)) {
                MediaMetadata meta = new MediaMetadata.Builder()
                        .putString(MediaMetadata.METADATA_KEY_TITLE, item.title)
                        .putString(MediaMetadata.METADATA_KEY_ARTIST, item.artist)
                        .putString(MediaMetadata.METADATA_KEY_ART_URI, item.coverUrl)
                        .build();
                updateSpotifyArt(meta, meta.getDescription(), item.title);
            }
            return;
        }

        MediaController controller = null;
        try {
            MediaSessionManager manager = (MediaSessionManager)
                    getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (manager != null) {
                ComponentName listener = new ComponentName(this,
                        SpotifyNotificationListener.class);
                for (MediaController item : manager.getActiveSessions(listener)) {
                    if (SPOTIFY_PACKAGE.equals(item.getPackageName())) {
                        controller = item;
                        break;
                    }
                }
            }
        } catch (SecurityException ex) {
            // A TV-n meg nincs engedelyezve az ertesites-hozzaferes.
            controller = null;
        } catch (Exception ex) {
            Log.w(TAG, "Spotify munkamenet nem elerheto", ex);
        }
        spotifyController = controller;
        if (controller == null) {
            hideSpotifyPanel();
            return;
        }
        PlaybackState state;
        MediaMetadata metadata;
        try {
            state = controller.getPlaybackState();
            metadata = controller.getMetadata();
        } catch (RuntimeException ex) {
            hideSpotifyPanel();
            return;
        }
        if (state == null || metadata == null) {
            hideSpotifyPanel();
            return;
        }
        int playback = state.getState();
        spotifyPlaybackState = playback;
        long now = SystemClock.elapsedRealtime();
        if (playback == PlaybackState.STATE_PLAYING) spotifyLastPlayingAt = now;
        if (playback != PlaybackState.STATE_PLAYING
                && (playback != PlaybackState.STATE_PAUSED || spotifyLastPlayingAt == 0
                || now - spotifyLastPlayingAt > SPOTIFY_PAUSE_GRACE_MS)) {
            hideSpotifyPanel();
            return;
        }
        MediaDescription desc = metadata.getDescription();
        CharSequence title = desc == null ? null : desc.getTitle();
        CharSequence subtitle = desc == null ? null : desc.getSubtitle();
        if (TextUtils.isEmpty(title)) title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        if (TextUtils.isEmpty(subtitle)) subtitle = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
        if (TextUtils.isEmpty(title)) {
            hideSpotifyPanel();
            return;
        }
        boolean changedSong = spotifyTrackText.setTrack(title.toString(),
                subtitle == null ? "Spotify" : subtitle.toString());
        updateAmbientSpotifyData(title.toString(),
                subtitle == null ? "Spotify" : subtitle.toString(), playback);
        long at = SystemClock.elapsedRealtime();
        long pos = Math.max(0, state.getPosition());
        if (playback == PlaybackState.STATE_PLAYING && state.getLastPositionUpdateTime() > 0)
            pos += Math.max(0, at - state.getLastPositionUpdateTime())
                    * Math.max(0f, state.getPlaybackSpeed());
        setSpotifyProgress(pos,
                metadata.getLong(MediaMetadata.METADATA_KEY_DURATION), at,
                playback == PlaybackState.STATE_PLAYING);
        if (changedSong) animateProgressSongSwitch();
        if (spotifyShownPlaybackState != playback) {
            spotifyPlayIcon.setImageDrawable(new SpotifyControlIcon(
                    playback == PlaybackState.STATE_PLAYING ? 1 : 3));
            spotifyShownPlaybackState = playback;
        }
        if (spotifyPanel.getVisibility() != View.VISIBLE) {
            spotifyPanel.animate().cancel();
            spotifyPanel.setVisibility(View.VISIBLE);
            spotifyPanel.setAlpha(0f);
            spotifyPanel.animate().alpha(1f).setDuration(220L).start();
            showSpotifyHalo();
            syncMediaProgressVisibility(); // Azonnal megjelenik a progress is.
        }
        updateSpotifyArt(metadata, desc, title.toString());
    }

    private void showSpotifyHalo() {
        if (spotifyHaloView == null) return;
        spotifyHaloView.animate().cancel();
        spotifyHaloView.setVisibility(View.VISIBLE);
        spotifyHaloView.setAlpha(0f);
        spotifyHaloView.animate().alpha(1f).setDuration(220L).start();
    }

    private void hideSpotifyPanel() {
        if (spotifyPanel == null) return;
        if (spotifyHaloView != null) {
            spotifyHaloView.animate().cancel();
            spotifyHaloView.setVisibility(View.GONE);
            spotifyHaloView.setAlpha(0f);
        }
        hideAmbientSpotifyPanel();
        spotifyDurationMs = 0;
        spotifyProgressPlaying = false;
        mainHandler.removeCallbacks(spotifyProgressTicker);
        if (spotifyProgressView != null) spotifyProgressView.setVisibility(View.GONE);
        if (ambientProgressView != null) ambientProgressView.setVisibility(View.GONE);
        if (spotifyButtonHasFocus(getCurrentFocus()) && dock != null
                && dock.getChildCount() > 0) {
            int focus = Math.max(0, Math.min(lastFocusedDockIndex, dock.getChildCount()-1));
            dock.getChildAt(focus).requestFocus();
        }
        spotifyConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
        spotifyPanel.animate().cancel();
        spotifyPanel.setVisibility(View.GONE);
        spotifyPanel.setAlpha(0f);
        if (spotifyAlbum != null) {
            ++spotifyArtRevision;
            spotifyArtKey = "";
            clearCoverAnimation(spotifyAlbum, spotifyAlbumIncoming,
                    spotifyAlbumFallback);
        }
        if (spotifyTrackText != null) spotifyTrackText.clear();
        resetMediaAccent();
    }

    /** Kulso PC-segedprogram HELYETT kozvetlen Spotify Connect Web API parancs. */
    private void sendSpotifyCommand(final int command) {
        if (spotifyApi != null && spotifyApi.isLinked()) {
            spotifyApi.command(command, spotifyPlaybackState == PlaybackState.STATE_PLAYING,
                    new Runnable() {
                        @Override public void run() {
                            if (!running) return;
                            String error = spotifyApi.error();
                            if (!TextUtils.isEmpty(error))
                                Toast.makeText(MainActivity.this, error, Toast.LENGTH_SHORT).show();
                            mainHandler.removeCallbacks(spotifyRefresh);
                            mainHandler.postDelayed(spotifyRefresh, 700L);
                        }
                    });
            return;
        }
        // A regi MediaSession megmarad, ha nincs API-osszekotes.
        MediaController controller = spotifyController;
        if (controller == null) {
            Toast.makeText(this, "Spotify kapcsolat: Beállítások → Spotify kapcsolat",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            MediaController.TransportControls tr = controller.getTransportControls();
            if (command == 0) tr.skipToPrevious();
            else if (command == 2) tr.skipToNext();
            else if (spotifyPlaybackState == PlaybackState.STATE_PLAYING) tr.pause();
            else tr.play();
        } catch (Exception e) {
            Toast.makeText(this, "Spotify vezérléshez kösd össze az API-t",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /** Az egyetlen PIN-es, atmeneti LAN fogadopont az EGYSZERI OAuth parositashoz. */
    private void showSpotifyConnectionDialog() {
        if (spotifyApi == null) return;
        if (spotifyApi.isLinked()) {
            String currentError = spotifyApi.error();
            new AlertDialog.Builder(this)
                    .setTitle("Spotify Connect – összekapcsolva")
                    .setMessage("A TVHome közvetlenül vezérli a Spotify-fiókod "
                            + "aktív lejátszóját PC-n és telefonon is. "
                            + "Nem kell Windows-segédprogram.\n\n"
                            + (TextUtils.isEmpty(currentError) ? "Állapot: aktív kapcsolat."
                            : "Utolsó API-válasz: " + currentError))
                    .setPositiveButton("Rendben", null)
                    .setNegativeButton("Kapcsolat bontása", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) {
                            spotifyApi.unlink();
                            hideSpotifyPanel();
                            Toast.makeText(MainActivity.this, "Spotify kapcsolat bontva",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }).show();
            return;
        }
        String ip=phoneUploadLocalIp();
        if (ip == null) {
            Toast.makeText(this, "Csatlakoztasd a TV-t Wi-Fi-hez", Toast.LENGTH_LONG).show();
            return;
        }
        final String pin=String.format(Locale.US, "%06d",new SecureRandom().nextInt(1000000));
        final AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("Spotify Connect – egyszeri belépés")
                .setMessage("1. Spotify Developer Dashboard: hozz létre egy Web API appot.\n"
                        + "2. Redirect URI: http://127.0.0.1:8769/callback\n"
                        + "3. PC-n EGYSZER indítsd el a Spotify_Egyszeri_Osszekotes_Inditas.cmd fájlt.\n"
                        + "4. Add meg a Client ID-t, TV IP-címét és PIN-t.\n\n"
                        + "TV: " + ip + "\nPÁROSÍTÁSI PIN: " + pin + "\n\n"
                        + "Hagyd nyitva ezt az ablakot az összekötésig.\n"
                        + "Utána a PC-s script végleg bezárható.")
                .setNegativeButton("Mégse", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d,int w) {spotifyApi.stopPairing();}
                }).create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d){spotifyApi.stopPairing();}
        });
        dialog.show();
        spotifyApi.startPairing(pin, new Runnable() {
            @Override public void run(){
                dialog.dismiss();
                Toast.makeText(MainActivity.this,
                        "Spotify összekapcsolva! PC és telefon is vezérelhető.",
                        Toast.LENGTH_LONG).show();
                updateSpotifySession();
            }
        }, new Runnable(){
            @Override public void run(){
                if(dialog.isShowing())Toast.makeText(MainActivity.this,
                        "Spotify párosítószerver nem indítható",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateSpotifyArt(MediaMetadata metadata,
            MediaDescription desc, String title) {
        Bitmap inline = desc == null ? null : desc.getIconBitmap();
        if (inline == null) inline = metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if (inline == null) inline = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        Uri uri = desc == null ? null : desc.getIconUri();
        if (uri == null) {
            String u = metadata.getString(MediaMetadata.METADATA_KEY_ART_URI);
            if (TextUtils.isEmpty(u)) u = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
            if (!TextUtils.isEmpty(u)) uri = Uri.parse(u);
        }
        final String key = title + "|" + (uri == null ? "bitmap" : uri.toString());
        if (key.equals(spotifyArtKey)) return;
        spotifyArtKey = key;
        final int revision = ++spotifyArtRevision;
        // A regi borito a helyen marad a HTTPS-letoltesig, nincsen ures villanas.
        if (inline != null) {
            setSpotifyArt(Bitmap.createScaledBitmap(inline, dp(35), dp(35), true), revision);
            return;
        }
        if (uri == null) { setSpotifyArt(null, revision); return; }
        final Uri artUri = uri;
        spotifyArtExecutor.execute(new Runnable() {
            @Override public void run() {
                Bitmap art = null;
                InputStream stream = null;
                HttpURLConnection connection = null;
                try {
                    String scheme = artUri.getScheme();
                    if ("content".equalsIgnoreCase(scheme)
                            || "android.resource".equalsIgnoreCase(scheme)) {
                        stream = getContentResolver().openInputStream(artUri);
                    } else if ("https".equalsIgnoreCase(scheme)
                            || "http".equalsIgnoreCase(scheme)) {
                        URL url = new URL(artUri.toString());
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setConnectTimeout(3500);
                        connection.setReadTimeout(4500);
                        connection.setInstanceFollowRedirects(true);
                        if (connection.getResponseCode() == 200) stream = connection.getInputStream();
                    }
                    if (stream != null) {
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        byte[] buffer = new byte[8192];
                        int length;
                        while ((length = stream.read(buffer)) != -1) {
                            if (bytes.size() + length > 2 * 1024 * 1024) break;
                            bytes.write(buffer, 0, length);
                        }
                        byte[] data = bytes.toByteArray();
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inJustDecodeBounds = true;
                        BitmapFactory.decodeByteArray(data, 0, data.length, options);
                        options.inSampleSize = 1;
                        while (options.outWidth / options.inSampleSize > 200
                                || options.outHeight / options.inSampleSize > 200)
                            options.inSampleSize *= 2;
                        options.inJustDecodeBounds = false;
                        art = BitmapFactory.decodeByteArray(data, 0, data.length, options);
                    }
                } catch (Exception ignored) {
                    // A Spotify nem minden esetben ad hozzaferheto album-art URI-t.
                } finally {
                    try { if (stream != null) stream.close(); } catch (IOException ignored) {}
                    if (connection != null) connection.disconnect();
                }
                final Bitmap result = art;
                mainHandler.post(new Runnable() {
                    @Override public void run() { setSpotifyArt(result, revision); }
                });
            }
        });
    }

    private void clearCoverAnimation(ImageView cover, ImageView incoming,
                                      TextView fallback) {
        if (cover != null) {
            cover.animate().cancel();
            cover.setAlpha(1f);
            cover.setScaleX(1f);
            cover.setScaleY(1f);
            cover.setImageDrawable(null);
            cover.setVisibility(View.INVISIBLE);
        }
        if (incoming != null) {
            incoming.animate().cancel();
            incoming.setImageDrawable(null);
            incoming.setVisibility(View.GONE);
            incoming.setAlpha(0f);
            incoming.setScaleX(1f);
            incoming.setScaleY(1f);
        }
        if (fallback != null) fallback.setVisibility(View.VISIBLE);
    }

    /** Haromszaz ms koruli, szelid crossfade + 96%->100% zoom.
     *  A masik kep csak akkor valtozik, amikor sikerult letolteni az ujat. */
    private void animateNewMediaArt(final ImageView oldImage, final ImageView incoming,
                                    final TextView fallback, final Bitmap image,
                                    final int revision) {
        if (oldImage == null || incoming == null) return;
        oldImage.animate().cancel();
        incoming.animate().cancel();
        // Folytatodhat a valtas gyors szamlepgetes kozben is.
        incoming.setImageDrawable(null);
        incoming.setVisibility(View.GONE);
        oldImage.setAlpha(1f);
        oldImage.setScaleX(1f);
        oldImage.setScaleY(1f);
        if (image == null) {
            if (oldImage.getDrawable() != null) {
                oldImage.animate().alpha(0f).setDuration(220L)
                        .withEndAction(new Runnable() {
                            @Override public void run() {
                                if (revision != spotifyArtRevision) return;
                                clearCoverAnimation(oldImage, incoming, fallback);
                            }
                        }).start();
            } else clearCoverAnimation(oldImage, incoming, fallback);
            return;
        }
        if (oldImage.getDrawable() == null
                || oldImage.getVisibility() != View.VISIBLE) {
            oldImage.setImageBitmap(image);
            oldImage.setAlpha(0f);
            oldImage.setScaleX(0.96f);
            oldImage.setScaleY(0.96f);
            oldImage.setVisibility(View.VISIBLE);
            fallback.setVisibility(View.GONE);
            oldImage.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(300L).setInterpolator(tvEase).start();
            return;
        }
        incoming.setImageBitmap(image);
        incoming.setAlpha(0f);
        incoming.setScaleX(0.96f);
        incoming.setScaleY(0.96f);
        incoming.setVisibility(View.VISIBLE);
        fallback.setVisibility(View.GONE);
        oldImage.animate().alpha(0.16f).setDuration(260L)
                .setInterpolator(tvEase).start();
        incoming.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(330L).setInterpolator(tvEase)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        if (revision != spotifyArtRevision) return;
                        oldImage.animate().cancel();
                        oldImage.setImageBitmap(image);
                        oldImage.setAlpha(1f);
                        oldImage.setScaleX(1f);
                        oldImage.setScaleY(1f);
                        oldImage.setVisibility(View.VISIBLE);
                        incoming.setVisibility(View.GONE);
                        incoming.setImageDrawable(null);
                        incoming.setAlpha(0f);
                        incoming.setScaleX(1f);
                        incoming.setScaleY(1f);
                    }
                }).start();
    }

    private void setSpotifyArt(Bitmap art, int revision) {
        if (revision != spotifyArtRevision || spotifyAlbum == null
                || spotifyPanel.getVisibility() != View.VISIBLE) return;
        animateNewMediaArt(spotifyAlbum, spotifyAlbumIncoming,
                spotifyAlbumFallback, art, revision);
        if (ambientSpotifyAlbum != null)
            animateNewMediaArt(ambientSpotifyAlbum, ambientSpotifyAlbumIncoming,
                    ambientSpotifyAlbumFallback, art, revision);
        setMediaAccent(art == null ? MEDIA_NEUTRAL_ACCENT : artAccent(art));
    }

    /** A ket ikon a megadott peldak alapjan kozvetlenul kodbol rajzolodik.
     * Igy nem kell PNG-t kulon telepiteni, es nem kerul a programba vizjel.
     */
    private LinearLayout topButton(final String caption, Drawable icon, final Runnable action) {
        final LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.HORIZONTAL);
        // Forrasok: az ikon mindig ugyanazon a belso pozicion maradjon.
        // Korabban a CENTER igazitas + a felirat GONE-ra valtasa okozott
        // egy hirtelen ikon-ugrast a gomb osszecsukodasanak vegen.
        if ("Források".equals(caption)) {
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            b.setPadding(dp(10), 0, dp(4), 0);
        } else {
            b.setGravity(Gravity.CENTER);
        }
        b.setFocusable(true);
        b.setClickable(true);
        b.setClipChildren(true);
        b.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        b.setBackground(ultraHeaderSelector());

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        iv.setFocusable(false);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(18), dp(18));
        b.addView(iv, ip);

        final TextView label = text(caption, 12, 0xF7FFFFFF);
        label.setSingleLine(true);
        label.setVisibility(View.GONE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(7);
        b.addView(label, lp);
        b.setContentDescription(caption);
        b.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                final boolean keepExpanded = hasFocus ||
                        ("Beállítások".equals(caption) && settingsDropdown != null) ||
                        ("Források".equals(caption) && isSourcesMenuVisible());
                final int target = dp(keepExpanded
                        ? ("Források".equals(caption) ? 112
                        : settingsDropdown != null ? CONNECTED_SETTINGS_WIDTH_DP : 133)
                        : 39);
                // Szoveg attunes: a gomb szelessegvaltozasa mellett sem ugrik fel.
                label.animate().cancel();
                if (keepExpanded) {
                    if (label.getVisibility() != View.VISIBLE) {
                        label.setAlpha(0f);
                        label.setVisibility(View.VISIBLE);
                    }
                    label.animate().alpha(1f).setStartDelay(35L)
                            .setDuration(145L).setInterpolator(tvEase).start();
                } else {
                    label.animate().alpha(0f).setStartDelay(0L)
                            .setDuration(95L).start();
                }
                // A ket szomszedos gomb SZÉLESSÉGE mindig animaltan valtozik:
                // igy a Forrasok nem ugrik el, amikor a Beallitasok lenyilik.
                animateHeaderButtonWidth(b, label, target, caption);
                if ("Beállítások".equals(caption)) {
                    b.post(new Runnable() {
                        @Override public void run() {
                            if (b.hasFocus()) {
                                if (!suppressSettingsAutoOpen) showSettingsDropdown(false);
                            } else {
                                suppressSettingsAutoOpen = false;
                                if (!settingsDropdownHasFocus()) closeSettingsDropdown();
                            }
                        }
                    });
                }
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        return b;
    }

    /**
     * A felso gombok merete mindig animalt: a lenyilo menu ne irja felul
     * az aktiv animaciot egy azonnali setLayoutParams-szal. A megszakitott
     * animacio nem rejtheti el a feliratot (Android cancel -> end sorrend).
     */
    private void animateHeaderButtonWidth(final LinearLayout button,
            final TextView label, int target, final String caption) {
        ValueAnimator previous = (ValueAnimator) button.getTag();
        if (previous != null) previous.cancel();
        ViewGroup.LayoutParams layout = button.getLayoutParams();
        if (layout == null) return;
        if (layout.width == target) return;
        final ValueAnimator animator = ValueAnimator.ofInt(layout.width, target);
        animator.setDuration(PANEL_MS);
        animator.setInterpolator(tvEase);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                ViewGroup.LayoutParams p = button.getLayoutParams();
                if (p != null) {
                    p.width = (Integer) a.getAnimatedValue();
                    button.setLayoutParams(p);
                }
            }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (button.getTag() == a) button.setTag(null);
                if (cancelled) return;
                if (!button.hasFocus() && !("Beállítások".equals(caption)
                        && settingsDropdown != null)
                        && !("Források".equals(caption) && isSourcesMenuVisible())) {
                    label.setAlpha(0f);
                    label.setVisibility(View.GONE);
                }
            }
        });
        button.setTag(animator);
        animator.start();
    }

    private void setSettingsHeaderExpanded(boolean expanded) {
        if (settingsButton == null || settingsButton.getChildCount() < 2) return;
        final TextView label = (TextView) settingsButton.getChildAt(1);
        label.animate().cancel();
        if (expanded) {
            if (label.getVisibility() != View.VISIBLE) {
                label.setAlpha(0f);
                label.setVisibility(View.VISIBLE);
            }
            label.animate().alpha(1f).setDuration(145L)
                    .setInterpolator(tvEase).start();
        } else {
            label.animate().alpha(0f).setDuration(95L).start();
        }
        animateHeaderButtonWidth(settingsButton, label,
                dp(expanded
                        ? (settingsDropdown != null ? CONNECTED_SETTINGS_WIDTH_DP : 133)
                        : 39), "Beállítások");
    }

    private void showTvHomeKeyboardOptions() {
        final String[] choices = {
                "1. TVHome Keyboard engedélyezése (Android)",
                "2. Billentyűzet kiválasztása",
                "3. Kapcsolat bontása / új telefon párosítása",
                "Használati útmutató"
        };
        new AlertDialog.Builder(this)
                .setTitle("TVHome Keyboard · QR-szövegbevitel")
                .setItems(choices, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            try { startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); }
                            catch (Exception error) {
                                Toast.makeText(MainActivity.this,
                                        "Nyisd meg az Android beállításaiban a Billentyűzetek menüt.",
                                        Toast.LENGTH_LONG).show();
                            }
                        } else if (which == 1) {
                            android.view.inputmethod.InputMethodManager imm =
                                    (android.view.inputmethod.InputMethodManager)
                                    getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) imm.showInputMethodPicker();
                        } else if (which == 2) {
                            boolean disconnected = TvHomeInputService.disconnectConnectedPhone();
                            Toast.makeText(MainActivity.this, disconnected
                                    ? "Telefon leválasztva. Az új QR-kód a billentyűzet következő megnyitásakor jelenik meg."
                                    : "Nincs aktív TVHome Keyboard szerver.",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("TVHome Keyboard használata")
                                    .setMessage("A TVHome Keyboardot az Android billentyűzetbeállításaiban "
                                            + "engedélyezd, majd válaszd ki aktív billentyűzetnek.\n\n"
                                            + "Ha egy alkalmazás normál Android-szövegmezőjét megnyitod, "
                                            + "a TVHome Keyboard megjeleníti a QR-kódot. "
                                            + "Telefonról így tudsz szöveget beírni az aktív mezőbe.\n\n"
                                            + "LE = Kapcsolat bontása, OK = megerősítés, "
                                            + "VISSZA = billentyűzet bezárása.\n\n"
                                            + "Az alkalmazások saját, különálló billentyűzetei "
                                            + "(például a YouTube saját keresője) nem támogatottak.\n\n"
                                            + "Csak megbízható helyi Wi-Fi-n használd; jelszót ne küldj.")
                                    .setPositiveButton("Értem", null).show();
                        }
                    }
                }).setNegativeButton("Bezárás", null).show();
    }

    private void showTvHomeSettings() {
        // OK-ra a mar nyitott lenyilo menu elso eleme kap fokuszt.
        suppressSettingsAutoOpen = false;
        showSettingsDropdown(true);
    }

    private boolean settingsDropdownHasFocus() {
        return settingsDropdown != null && settingsDropdown.hasFocus();
    }

    /**
     * Egyetlen kozos hatter jon letre a gomb ES a ket menupont ala.
     * A gombon NINCS sajat keret/also el, ezert nem jelenhet meg a
     * ket korabbi GradientDrawable kozotti vizszintes varrat.
     */
    private void setSettingsHeaderAttached(boolean attached) {
        if (settingsButton == null) return;
        if (!attached) {
            if (settingsClosedButtonBackground != null)
                settingsButton.setBackground(settingsClosedButtonBackground);
            return;
        }
        // A hatter es az egyetlen kulso keret a settingsUnifiedShell-en van.
        // A fokusz csak a felso savot emeli ki, KERET NELKUL.
        float radius = dp(16);
        float[] topCorners = {radius, radius, radius, radius, 0f, 0f, 0f, 0f};
        GradientDrawable focused = new GradientDrawable();
        focused.setColor(0x18FFFFFF);
        focused.setCornerRadii(topCorners);
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused}, focused);
        states.addState(new int[]{}, new ColorDrawable(0x00000000));
        settingsButton.setBackground(states);
    }

    private TextView connectedSettingsRow(String caption) {
        TextView row = text(caption, 13, 0xFFFFFFFF);
        row.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        row.setPadding(dp(13), 0, dp(8), 0);
        row.setFocusable(true);
        row.setClickable(true);
        row.setSingleLine(true);
        // Nincsenek kulon, nagy szurke dobozok: csak a kijelolt sor
        // kap kiemelest, a ket opcio kozott finom elvalaszto lesz.
        row.setBackground(ultraMenuRowSelector(11));
        row.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focused) {
                ((TextView) v).setTypeface(focused
                        ? android.graphics.Typeface.DEFAULT_BOLD
                        : android.graphics.Typeface.DEFAULT);
                v.animate().cancel();
                v.animate().scaleX(focused ? 1.032f : 1f)
                        .scaleY(focused ? 1.045f : 1f)
                        .setDuration(195L).setInterpolator(tvEase).start();
            }
        });
        return row;
    }

    private void removeClosingSettingsDropdown() {
        if (closingSettingsDropdown != null) {
            LinearLayout old = closingSettingsDropdown;
            closingSettingsDropdown = null;
            old.animate().cancel();
            if (old.getParent() == homeTop) homeTop.removeView(old);
        }
        if (closingSettingsShell != null) {
            View old = closingSettingsShell;
            closingSettingsShell = null;
            old.animate().cancel();
            if (old.getParent() == homeTop) homeTop.removeView(old);
        }
    }

    private void closeSettingsDropdown() {
        if (settingsDropdown == null) return;
        final LinearLayout old = settingsDropdown;
        final View oldShell = settingsUnifiedShell;
        settingsDropdown = null;
        settingsUnifiedShell = null;
        settingsWallpaperRow = null;
        settingsAppearanceRow = null;
        settingsControlRow = null;
        settingsHiddenRow = null;
        settingsSpotifyRow = null;
        settingsInputRow = null;
        settingsAndroidRow = null;
        removeClosingSettingsDropdown();
        closingSettingsDropdown = old;
        closingSettingsShell = oldShell;
        old.animate().cancel();
        old.setFocusable(false);
        old.setClickable(false);
        // A valaszto finoman visszacsuszik a gomb ala.
        old.animate().alpha(0f).translationY(-dp(8)).scaleY(0.90f)
                .setDuration(145L).setInterpolator(tvEase)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        if (old.getParent() == homeTop) homeTop.removeView(old);
                        if (closingSettingsDropdown == old) closingSettingsDropdown = null;
                    }
                }).start();
        if (oldShell != null) {
            oldShell.animate().cancel();
            oldShell.animate()
                    .scaleY(37f / CONNECTED_SETTINGS_HEIGHT_DP)
                    .alpha(0f).setDuration(145L).setInterpolator(tvEase)
                    .withEndAction(new Runnable() {
                        @Override public void run() {
                            if (oldShell.getParent() == homeTop)
                                homeTop.removeView(oldShell);
                            if (closingSettingsShell == oldShell) closingSettingsShell = null;
                        }
                    }).start();
        }
        setSettingsHeaderAttached(false);
        if (settingsButton != null && !settingsButton.hasFocus())
            setSettingsHeaderExpanded(false);
    }

    private void showSettingsDropdown(boolean focusFirst) {
        if (root == null || settingsButton == null || modalView != null || moving) return;
        if (settingsDropdown != null) {
            if (focusFirst && settingsWallpaperRow != null) settingsWallpaperRow.requestFocus();
            return;
        }
        removeClosingSettingsDropdown();

        // A TELJES menunek egy darab kozos kerete/hattere van, a gomb
        // tetejetol az also menu aljaig. A ket kulon hatter okozta
        // vizszintes varrat es az eltero bal szeleket is megszuntetjuk.
        View shellView = new View(this);
        shellView.setBackground(new UltraGlassDrawable(17, 2));
        FrameLayout.LayoutParams shellParams = new FrameLayout.LayoutParams(
                dp(CONNECTED_SETTINGS_WIDTH_DP),
                dp(CONNECTED_SETTINGS_HEIGHT_DP), Gravity.TOP | Gravity.END);
        shellParams.setMargins(0, dp(33), dp(204), 0);
        // A gomb ala kerul (nem takarja el az ikont vagy a szoveget).
        homeTop.addView(shellView, 0, shellParams);
        settingsUnifiedShell = shellView;
        shellView.setPivotY(0f);
        shellView.setScaleY(37f / CONNECTED_SETTINGS_HEIGHT_DP);
        shellView.animate().scaleY(1f).setDuration(215L)
                .setInterpolator(tvEase).start();

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7), dp(7), dp(7), dp(7));
        // A panel NEM rajzol se hatteret, se kulso keretet:
        // csak a sorokat tartalmazza az egyseges kozos feluleten.

        settingsWallpaperRow = connectedSettingsRow("Háttérképek");
        settingsAppearanceRow = connectedSettingsRow("Megjelenés");
        settingsControlRow = connectedSettingsRow("Vezérlőközpont");
        settingsHiddenRow = connectedSettingsRow("Rejtett alkalmazások");
        settingsSpotifyRow = connectedSettingsRow("Spotify kapcsolat");
        settingsInputRow = connectedSettingsRow("Telefonos billentyűzet");
        settingsAndroidRow = connectedSettingsRow("Android beállítások");
        panel.addView(settingsWallpaperRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        addConnectedSettingsDivider(panel);
        panel.addView(settingsAppearanceRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        addConnectedSettingsDivider(panel);
        panel.addView(settingsControlRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        addConnectedSettingsDivider(panel);
        panel.addView(settingsHiddenRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        addConnectedSettingsDivider(panel);
        panel.addView(settingsSpotifyRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        addConnectedSettingsDivider(panel);
        panel.addView(settingsInputRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        addConnectedSettingsDivider(panel);
        panel.addView(settingsAndroidRow,
                new LinearLayout.LayoutParams(-1, dp(40)));
        settingsWallpaperRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                showWallpaperMenu();
            }
        });
        settingsAppearanceRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                showAppearanceMenu();
            }
        });
        settingsControlRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                showControlCenter(settingsButton);
            }
        });
        settingsHiddenRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                showHiddenAppsMenu();
            }
        });
        settingsSpotifyRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                showSpotifyConnectionDialog();
            }
        });
        settingsInputRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                showTvHomeKeyboardOptions();
            }
        });
        settingsAndroidRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSettingsDropdown();
                openTvSettings();
            }
        });

        // Pontosan azonos BAL es JOBB szel a fejleccel.
        // Ezzel a gomb nem egy keskenyebb kulon buborek a panel folott.
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                dp(CONNECTED_SETTINGS_WIDTH_DP), -2, Gravity.TOP | Gravity.END);
        pp.setMargins(0, dp(70), dp(204), 0);
        settingsDropdown = panel;
        homeTop.addView(panel, pp);
        setSettingsHeaderAttached(true);
        setSettingsHeaderExpanded(true);

        panel.setPivotY(0f);
        panel.setAlpha(0f);
        panel.setScaleY(0.90f);
        panel.setTranslationY(-dp(10));
        panel.animate().alpha(1f).scaleY(1f).translationY(0f)
                .setInterpolator(tvEase).setDuration(205L).start();
        if (focusFirst) settingsWallpaperRow.requestFocus();
    }

    private void addConnectedSettingsDivider(LinearLayout panel) {
        View separator = new View(this);
        separator.setBackgroundColor(0x18FFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1));
        p.leftMargin = dp(11);
        p.rightMargin = dp(11);
        panel.addView(separator, p);
    }

    private void readAppearanceSettings() {
        SharedPreferences p = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        glassStrength = Math.max(0, Math.min(100, p.getInt(PREF_GLASS_STRENGTH, BASE_GLASS)));
        glowStrength = Math.max(0, Math.min(100, p.getInt(PREF_GLOW_STRENGTH, BASE_GLOW)));
        animationSpeed = Math.max(0, Math.min(2, p.getInt(PREF_ANIMATION_SPEED, 1)));
        dockStyle = Math.max(0, Math.min(2, p.getInt(PREF_DOCK_STYLE, 0)));
        applyAnimationSpeed();
        SoftEdgeGlowDrawable.setGlowPercent(glowStrength);
    }

    private void applyAnimationSpeed() {
        FOCUS_MS = animationSpeed == 0 ? 100L : animationSpeed == 2 ? 275L : 175L;
        PANEL_MS = Math.round(195f * FOCUS_MS / 175f);
        SCROLL_MS = Math.round(235f * FOCUS_MS / 175f);
    }

    private void persistAppearance() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putInt(PREF_GLASS_STRENGTH, glassStrength)
                .putInt(PREF_GLOW_STRENGTH, glowStrength)
                .putInt(PREF_ANIMATION_SPEED, animationSpeed)
                .putInt(PREF_DOCK_STYLE, dockStyle).apply();
    }

    private static int clampAlpha(float value) {
        return Math.max(0, Math.min(255, Math.round(value)));
    }

    /** Redraw only existing Views; the wallpaper blur bitmap is NOT recomputed. */
    private void applyAppearanceLive() {
        applyAnimationSpeed();
        SoftEdgeGlowDrawable.setGlowPercent(glowStrength);
        invalidateUltraGlassSurfaces(root);
        if (allGrid != null) allGrid.invalidate();
        // A dokk fokuszkerete a sajat csempen marad.
        if (dock != null) {
            for (int i = 0; i < dock.getChildCount(); i++) {
                View card = dock.getChildAt(i);
                if (card instanceof FrameLayout) card.invalidate();
            }
        }
    }

    private String appearanceValue(int i) {
        switch (i) {
            case 0: return "Liquid Glass erőssége          " + glassStrength + "%";
            case 1: return "Glow erőssége                        " + glowStrength + "%";
            case 2: return "Animáció sebessége              " +
                    (animationSpeed == 0 ? "Gyors" : animationSpeed == 2 ? "Lassú" : "Normál");
            case 3: return "Dokk stílusa                           " +
                    (dockStyle == 0 ? "Liquid Glass" : dockStyle == 1 ? "Clear Glass" : "Frosted Glass");
            case 4: return "↺  Alapértékek visszaállítása";
            default: return "Bezárás";
        }
    }

    private void renderAppearanceValues() {
        for (int i = 0; i < appearanceOptions.size(); i++) {
            TextView row = appearanceOptions.get(i);
            row.setText(appearanceValue(i));
        }
    }

    private void changeAppearance(int index, int delta) {
        if (index == 0) glassStrength = Math.max(0, Math.min(100, glassStrength + 5 * delta));
        else if (index == 1) glowStrength = Math.max(0, Math.min(100, glowStrength + 5 * delta));
        else if (index == 2) animationSpeed = (animationSpeed + delta + 3) % 3;
        else if (index == 3) dockStyle = (dockStyle + delta + 3) % 3;
        else if (index == 4) {
            glassStrength = BASE_GLASS;
            glowStrength = BASE_GLOW;
            animationSpeed = 1;
            dockStyle = 0;
            Toast.makeText(this, "A 6.6-os alapmegjelenés visszaállítva",
                    Toast.LENGTH_SHORT).show();
        } else if (index == 5) {
            closeAppearanceMenu(true);
            return;
        }
        persistAppearance();
        applyAppearanceLive();
        renderAppearanceValues();
    }

    /** No new Window, no third-party UI library: light D-pad-controlled glass panel. */
    private void showAppearanceMenu() {
        if (appearanceOverlay != null || root == null) return;
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0x36030A14);
        overlay.setFocusable(false);
        overlay.setClickable(true);
        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(19), dp(18), dp(19));
        panel.setBackground(new UltraGlassDrawable(23, 2));
        panel.setElevation(dp(23));

        TextView title = text("Megjelenés", 25, 0xFFFFFFFF);
        title.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.bottomMargin = dp(7);
        panel.addView(title, titleLp);
        TextView guide = text("◀ / ▶: módosítás    •    OK: következő érték", 12, 0xD6FFFFFF);
        LinearLayout.LayoutParams guideLp = new LinearLayout.LayoutParams(-1, -2);
        guideLp.bottomMargin = dp(13);
        panel.addView(guide, guideLp);

        appearanceOptions.clear();
        for (int i = 0; i < 6; i++) {
            final int selected = i;
            TextView item = text(appearanceValue(i), 15, 0xFFFFFFFF);
            item.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            item.setPadding(dp(15), 0, dp(12), 0);
            item.setFocusable(true);
            item.setClickable(true);
            item.setSingleLine(true);
            item.setBackground(ultraActionSelector(13));
            item.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override public void onFocusChange(View v, boolean focused) {
                    ((TextView) v).setTypeface(focused
                            ? android.graphics.Typeface.DEFAULT_BOLD
                            : android.graphics.Typeface.DEFAULT);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,
                    dp(i >= 4 ? 44 : 52));
            lp.bottomMargin = dp(i == 3 ? 16 : 7);
            panel.addView(item, lp);
            appearanceOptions.add(item);
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { changeAppearance(selected, +1); }
            });
        }
        TextView hint = text("A módosítások azonnal látszanak és mentődnek.",
                11, 0xBFFFFFFF);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.topMargin = dp(5);
        panel.addView(hint, hintLp);

        // Place on the left so the TVHome glass dock remains visible on the right.
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                dp(490), -2, Gravity.START | Gravity.CENTER_VERTICAL);
        lp.leftMargin = dp(42);
        overlay.addView(panel, lp);
        appearanceOverlay = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        panel.setAlpha(0f);
        panel.setScaleX(0.97f); panel.setScaleY(0.97f);
        panel.setTranslationY(dp(12));
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .translationY(0f).setDuration(PANEL_MS)
                .setInterpolator(tvEase).start();
        appearanceFocusIndex = 0;
        appearanceOptions.get(0).requestFocus();
    }

    private void closeAppearanceMenu(boolean returnFocus) {
        if (appearanceOverlay == null) return;
        FrameLayout overlay = appearanceOverlay;
        appearanceOverlay = null;
        appearanceOptions.clear();
        if (overlay.getParent() == root) root.removeView(overlay);
        if (returnFocus && settingsButton != null) {
            suppressSettingsAutoOpen = true;
            settingsButton.requestFocus();
        }
    }

    private boolean handleAppearanceKey(KeyEvent event) {
        int key = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (key == KeyEvent.KEYCODE_BACK) {
            if (down) closeAppearanceMenu(true);
            return true;
        }
        if (appearanceOptions.isEmpty()) return true;
        if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (down && event.getRepeatCount() == 0) {
                appearanceFocusIndex = (appearanceFocusIndex +
                        (key == KeyEvent.KEYCODE_DPAD_DOWN ? 1 : -1)
                        + appearanceOptions.size()) % appearanceOptions.size();
                appearanceOptions.get(appearanceFocusIndex).requestFocus();
            }
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT) {
            if (down) changeAppearance(appearanceFocusIndex,
                    key == KeyEvent.KEYCODE_DPAD_RIGHT ? +1 : -1);
            return true;
        }
        if (isOkKey(key)) {
            if (!down) changeAppearance(appearanceFocusIndex, +1);
            return true;
        }
        // Do not let unrelated remote keys navigate the launcher below the panel.
        return true;
    }

    private void openTvSettings() {
        Intent settings = launchIntent(getPackageManager(), "com.android.tv.settings");
        if (settings == null) settings = new Intent(Settings.ACTION_SETTINGS);
        launch(settings);
    }

    // A menu CSAK HDMI 1, HDMI 2, HDMI 3 opciokat mutatja, ebben a sorrendben.
    // Nem hasznaljuk a TV Input lista sorrendjet a portokhoz! A valodi HDMI
    // bemeneteket nev/azonosito (vagy HDMI portId) alapjan parositjuk.
    private int hdmiPortFromText(String value) {
        if (value == null) return -1;
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(
                "(?i)HDMI\\s*[-_:#./]*\\s*([1-3])(?=[^0-9]|$)").matcher(value);
        if (matcher.find()) return Integer.parseInt(matcher.group(1));
        return -1;
    }

    private int hdmiPortOf(TvInputInfo info) {
        CharSequence title = info.loadLabel(this);
        int port = hdmiPortFromText(title == null ? null : title.toString());
        if (port != -1) return port;
        port = hdmiPortFromText(info.getId());
        if (port != -1) return port;
        return -1;
    }

    private void showInputsMenu() {
        final TvInputInfo[] hdmiInputs = new TvInputInfo[3];
        try {
            TvInputManager manager = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
            if (manager != null) {
                for (TvInputInfo info : manager.getTvInputList()) {
                    if (!info.isPassthroughInput()) continue;
                    int port = hdmiPortOf(info);
                    if (port >= 1 && port <= 3 && hdmiInputs[port - 1] == null) {
                        hdmiInputs[port - 1] = info;
                    }
                }
            }
        } catch (Exception ex) {
            Log.w(TAG, "HDMI bemenetek lekerdezese sikertelen", ex);
        }
        showAnchoredSourcesMenu(new String[]{"Számítógép", "HDMI 2", "Beltéri"},
                new MenuAction() {
                    @Override public void onSelected(int choice) {
                        TvInputInfo selected = hdmiInputs[choice];
                        if (selected == null) {
                            Toast.makeText(MainActivity.this,
                                    "A TV nem adta at a HDMI " + (choice + 1)
                                            + " bemenetet. A SOURCE gomb tovabbra is hasznalhato.",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW,
                                    TvContract.buildChannelUriForPassthroughInput(selected.getId()));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            if (intent.resolveActivity(getPackageManager()) == null) {
                                Toast.makeText(MainActivity.this,
                                        "A TV ezen a rendszeren nem engedi a kozvetlen HDMI valtast.",
                                        Toast.LENGTH_LONG).show();
                            } else {
                                launch(intent);
                            }
                        } catch (Exception ex) {
                            Log.w(TAG, "HDMI inditas sikertelen", ex);
                            Toast.makeText(MainActivity.this,
                                    "Ezt a bemenetet a TV rendszere nem engedi valtani.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                 });
    }

    /**
     * 9.0.9: Codex-style anchored three-row Sources panel, but the panel
     * surface and focus highlight follow TVHome's Liquid Glass design.
     * Reuse the existing modalView/modalOptions key handling so Back, OK,
     * and D-pad behavior works exactly like the earlier HDMI chooser.
     */
    private boolean isSourcesMenuVisible() {
        return modalView != null && SOURCES_MENU_TAG.equals(modalView.getTag());
    }

    private void showAnchoredSourcesMenu(String[] choices, final MenuAction action) {
        if (root == null || inputsButton == null || choices == null || choices.length == 0) return;
        if (isSourcesMenuVisible()) return;
        if (modalView != null) closeLightweightMenu();
        closeSettingsDropdown();

        modalReturnFocus = getCurrentFocus();
        modalBackAction = null;
        modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
        modalOptions.clear();

        // Very subtle, tap-to-dismiss backdrop, not the old dark centered dialog.
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setTag(SOURCES_MENU_TAG);
        overlay.setBackgroundColor(0x22030A15);
        overlay.setClickable(true);
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { closeLightweightMenu(); }
        });

        final int width = dp(244);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(12));
        panel.setClipChildren(false);
        panel.setClipToPadding(false);
        panel.setFocusable(false);
        panel.setClickable(true); // Touching the pane must not dismiss it.
        panel.setBackground(new UltraGlassDrawable(18, 2));
        panel.setElevation(dp(10));

        TextView header = text("FORRÁSOK", 10, 0xB7F2F8FF);
        header.setLetterSpacing(0.20f);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(13), 0, 0, 0);
        LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(-1, dp(29));
        headerLp.bottomMargin = dp(2);
        panel.addView(header, headerLp);

        for (int i = 0; i < choices.length; i++) {
            final int index = i;
            TextView row = connectedSettingsRow(choices[i]);
            row.setContentDescription("HDMI " + (i + 1) + " – " + choices[i]);
            panel.addView(row, new LinearLayout.LayoutParams(-1, dp(46)));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    closeLightweightMenu();
                    action.onSelected(index); // Keep the tested HDMI mapping unchanged.
                }
            });
            modalOptions.add(row);
            if (i < choices.length - 1) addConnectedSettingsDivider(panel);
        }

        // Same-window coordinates: the panel lines up with the Sources icon,
        // including on TVs with a different density or screen resolution.
        final int[] anchorPosition = new int[2];
        final int[] rootPosition = new int[2];
        inputsButton.getLocationInWindow(anchorPosition);
        root.getLocationInWindow(rootPosition);
        int rootWidth = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
        int x = anchorPosition[0] - rootPosition[0] + inputsButton.getWidth() - width;
        int y = anchorPosition[1] - rootPosition[1] + inputsButton.getHeight() + dp(7);
        int estimatedHeight = dp(10 + 29 + 2 + 46 * choices.length
                + choices.length - 1 + 12);
        x = Math.max(dp(12), Math.min(x, rootWidth - width - dp(12)));
        y = Math.max(dp(12), Math.min(y, rootHeight - estimatedHeight - dp(12)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, -2,
                Gravity.TOP | Gravity.LEFT);
        lp.leftMargin = x;
        lp.topMargin = y;
        overlay.addView(panel, lp);

        modalView = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setAlpha(0f);
        // Grow from the header button, not the center of the screen.
        panel.setPivotX(width - dp(22));
        panel.setPivotY(0f);
        panel.setAlpha(0f);
        panel.setScaleX(0.94f);
        panel.setScaleY(0.88f);
        panel.setTranslationY(-dp(13));
        overlay.animate().alpha(1f).setDuration(115L).setInterpolator(tvEase).start();
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(215L).setInterpolator(tvEase).start();
        modalOptions.get(0).requestFocus();
    }

    private void addDock() {
        LinearLayout dockGroup = new LinearLayout(this);
        dockGroup.setOrientation(LinearLayout.VERTICAL);
        dockGroup.setGravity(Gravity.CENTER_HORIZONTAL);
        dockGroup.setClipChildren(false);
        dockGroup.setClipToPadding(false);

        // Az app neve mindig a dokk FELETT jelenik meg, nem az ikon alatt.
        // TVHome 9.0.6: a Codex/Imcsikee minimal TV Home nyugodt, 16:9 dokkjat
        // kovetjuk. A Spotify, QR es Liquid Glass tobbi resze erintetlen.
        selectedDockLabel = text("", 32, 0xFFFFFFFF);
        selectedDockLabel.setShadowLayer(dp(12), 0f, dp(1), 0x77000000);
        selectedDockLabel.setSingleLine(true);
        selectedDockLabel.setEllipsize(TextUtils.TruncateAt.END);
        selectedDockLabel.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(36));
        cp.leftMargin = dp(8);
        cp.bottomMargin = dp(14);
        dockGroup.addView(selectedDockLabel, cp);

        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setClipChildren(false);
        dock.setClipToPadding(false);
        dock.setPadding(dp(20), dp(20), dp(20), dp(20));
        // Statikus, alacsony tulrajzolasu uvegsav a korabbi
        // tobbpasszos, pixelenkenti UltraGlass helyett.
        GradientDrawable codexBand = new GradientDrawable();
        codexBand.setColor(0x1FFFFFFF);
        codexBand.setCornerRadius(dp(26));
        codexBand.setStroke(dp(1), 0x14FFFFFF);
        dock.setBackground(codexBand);
        dock.setElevation(dp(4));
        dockGroup.addView(dock, new LinearLayout.LayoutParams(-2, -2));

        buildDockFastStart();
        FrameLayout.LayoutParams groupLp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        groupLp.bottomMargin = dp(34);
        homeTop.addView(dockGroup, groupLp);
    }

    /**
     * 9.0.6: a ritkabban hasznalt ujraepites is a gyors utat hasznalja.
     * A PackageManager es a bannerek olvasasa nem blokkolja a TV kepernyot.
     */
    private void buildDock() {
        buildDockFastStart();
    }

    /** A 5.5-os gyors indulas megmarad: az ikon-cache azonnal megjelenik. */
    private void buildDockFastStart() {
        final int revision = ++dockRevision;
        final ArrayList<String> packages = new ArrayList<>(favoritePackages);
        dock.removeAllViews();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenDp = (int) (dm.widthPixels / dm.density);
        int count = Math.max(1, packages.size());
        // Egyetlen kedvenc se nojon teljes kepernyosre (Codex 1.0.1 fix).
        final int width = Math.min(164, Math.max(100, (screenDp - 100) / count - 14));
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        for (final String pkg : packages) {
            String title = prefs.getString("dock_title_" + pkg, pkg);
            Drawable icon = Drawable.createFromPath(cachedDockIcon(pkg).getAbsolutePath());
            if (icon == null) icon = getDrawable(android.R.drawable.sym_def_app_icon);
            View tile = makeAppleCard(title, icon, null, width, width * 9 / 16, true,
                    new Runnable() {
                        @Override public void run() { launchFavoritePackage(pkg); }
                    });
            tile.setTag(pkg);
            addDockTile(tile, width);
        }
        iconExecutor.execute(new Runnable() {
            @Override public void run() {
                final PackageManager pm = getPackageManager();
                final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                for (final String pkg : packages) {
                    if (Thread.currentThread().isInterrupted() || revision != dockRevision) break;
                    try {
                        if (launchIntent(pm, pkg) == null) {
                            mainHandler.post(new Runnable() {
                                @Override public void run() { removeMissingDockTile(pkg, revision); }
                            });
                            continue;
                        }
                        ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                        final String title = pm.getApplicationLabel(ai).toString();
                        PackageInfo info = pm.getPackageInfo(pkg, 0);
                        File file = cachedDockIcon(pkg);
                        boolean iconUpdated = !file.isFile() ||
                                prefs.getLong("dock_version_" + pkg, -1L) != info.lastUpdateTime;
                        SharedPreferences.Editor iconPrefs = prefs.edit();
                        if (iconUpdated && writeIconCache(file, pm.getApplicationIcon(ai)))
                            iconPrefs.putLong("dock_version_" + pkg, info.lastUpdateTime);
                        iconPrefs.putString("dock_title_" + pkg, title).apply();
                        // A banner betoltese korabban a UI-szalon futott: nagy
                        // appcsomagoknal ez kimarado kepeket okozhatott.
                        Drawable loadedBanner = null;
                        try { loadedBanner = pm.getApplicationBanner(pkg); }
                        catch (RuntimeException ignored) { }
                        final Drawable banner = loadedBanner;
                        final boolean updated = iconUpdated;
                        mainHandler.post(new Runnable() {
                            @Override public void run() {
                                updateDockTile(pkg, title, updated, revision, banner);
                            }
                        });
                    } catch (Exception ex) { Log.w(TAG, "Dokk ikon: " + pkg, ex); }
                }
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        if (revision == dockRevision) Log.i(TAG, "TVHOME_DOCK_READY_MS=" +
                                (SystemClock.elapsedRealtime() - startupAtMs));
                    }
                });
            }
        });
    }

private void launchFavoritePackage(String pkg) {
    Intent intent = launchIntent(getPackageManager(), pkg);
    if (intent != null) launch(intent);
    else Toast.makeText(this, "Ez az alkalmazás már nem elérhető", Toast.LENGTH_SHORT).show();
}

private File cachedDockIcon(String pkg) {
    File dir = new File(getFilesDir(), "dock-icon-cache");
    // Csomagnevben nincs elvalaszto, de a biztonsag kedveert szurjuk.
    return new File(dir, pkg.replaceAll("[^A-Za-z0-9._-]", "_") + ".png");
}

private boolean writeIconCache(File target, Drawable icon) {
    if (icon == null) return false;
    File parent = target.getParentFile();
    if (!parent.isDirectory() && !parent.mkdirs()) return false;
    File temp = new File(parent, target.getName() + ".tmp");
    Bitmap bitmap = null;
    try {
        final int px = 128;
        bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        android.graphics.Rect oldBounds = icon.copyBounds();
        icon.setBounds(0, 0, px, px);
        icon.draw(canvas);
        icon.setBounds(oldBounds);
        try (FileOutputStream out = new FileOutputStream(temp)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) return false;
        }
        // Ne hagyjunk feltoltott, hibas ikont ha a TV kifejezetten leall.
        if (target.exists() && !target.delete()) return false;
        return temp.renameTo(target);
    } catch (Exception ex) {
        Log.w(TAG, "Ikon cache mentes sikertelen", ex);
        return false;
    } finally {
        if (bitmap != null) bitmap.recycle();
        if (temp.exists()) temp.delete();
    }
}

private View findDockTile(String pkg) {
    for (int i = 0; i < dock.getChildCount(); i++) {
        View child = dock.getChildAt(i);
        if (pkg.equals(child.getTag())) return child;
    }
    return null;
}

private void removeMissingDockTile(String pkg, int revision) {
    if (revision != dockRevision || dock == null) return;
    View tile = findDockTile(pkg);
    if (tile != null) dock.removeView(tile);
}

private void updateDockTile(String pkg, String title, boolean iconUpdated, int revision, Drawable loadedBanner) {
    if (revision != dockRevision || dock == null) return;
    View tile = findDockTile(pkg);
    if (!(tile instanceof FrameLayout)) return;
    if (!TextUtils.equals(tile.getContentDescription(), title)) tile.setContentDescription(title);
    if (tile.hasFocus() && selectedDockLabel != null
            && !TextUtils.equals(selectedDockLabel.getText(), title))
        selectedDockLabel.setText(title);
    FrameLayout frame = (FrameLayout) tile;
    if (frame.getChildCount() == 0 || !(frame.getChildAt(0) instanceof ImageView)) return;
    ImageView iv = (ImageView) frame.getChildAt(0);
    if (loadedBanner != null) {
        if (bannerCache.size() < 14) bannerCache.put(pkg, loadedBanner);
        // Az ImageView-hoz sajat Drawable instancia, a cache-t nem mutaljuk.
        Drawable.ConstantState state = loadedBanner.getConstantState();
        Drawable toShow = state != null
                ? state.newDrawable(getResources()).mutate() : loadedBanner;
        iv.setPadding(0, 0, 0, 0);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setImageDrawable(toShow);
    } else if (iconUpdated) {
        Drawable icon = Drawable.createFromPath(cachedDockIcon(pkg).getAbsolutePath());
        if (icon != null) {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(20), dp(12), dp(20), dp(12));
            iv.setImageDrawable(icon);
        }
    }
}

private Drawable bannerFor(String pkg) {
    if (bannerCache.containsKey(pkg)) return bannerCache.get(pkg);
    Drawable banner = null;
    try { banner = getPackageManager().getApplicationBanner(pkg); }
    catch (Exception ignored) { }
    // Nagy mennyisegu betoltott kepet ne tartsunk meg: cache csak a kepernyon levo appoknal.
    if (bannerCache.size() < 14) bannerCache.put(pkg, banner);
    return banner;
}

/**
 * TVHome 9.0.6: 16:9 banneres csempe, minimalis erosforrasigenyu
 * feher fokuszperemmel. A Codex-varians dokkjanak vizualis elveit koveti.
 * Nincs per-kartya blur-bitmap, shader vagy ujrageneralt soft-glow.
 * A 0. gyermek az ImageView marad (aszinkron banner frissites).
 */
private View makeAppleCard(CharSequence label, Drawable icon, Drawable banner,
                           int widthDp, int heightDp, boolean interactive,
                           final Runnable click) {
    FrameLayout card = new FrameLayout(this);
    card.setClipChildren(false);
    card.setClipToPadding(false);
    GradientDrawable cardBg = new GradientDrawable();
    cardBg.setColor(0xFF1C1C1E);
    cardBg.setCornerRadius(dp(10));
    card.setBackground(cardBg);
    card.setOutlineProvider(new ViewOutlineProvider() {
        @Override public void getOutline(View view, Outline outline) {
            outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(10));
        }
    });
    card.setClipToOutline(true);

    ImageView art = new ImageView(this);
    art.setScaleType(banner == null ? ImageView.ScaleType.FIT_CENTER
            : ImageView.ScaleType.CENTER_CROP);
    art.setImageDrawable(banner == null ? icon : banner);
    if (banner == null) art.setPadding(dp(20), dp(12), dp(20), dp(12));
    card.addView(art, new FrameLayout.LayoutParams(-1, -1));

    GradientDrawable focusRing = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{0x26FFFFFF, 0x00FFFFFF, 0x00FFFFFF});
    focusRing.setCornerRadius(dp(10));
    focusRing.setStroke(dp(2), 0xE6FFFFFF);
    View shine = new View(this);
    shine.setBackground(focusRing);
    shine.setAlpha(0f);
    shine.setFocusable(false);
    card.addView(shine, new FrameLayout.LayoutParams(-1, -1));

    card.setContentDescription(label);
    card.setFocusable(interactive);
    card.setClickable(interactive);
    if (interactive) {
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                if (click != null) click.run();
            }
        });
        card.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focused) {
                v.animate().cancel();
                v.animate().scaleX(focused ? 1.12f : 1f)
                        .scaleY(focused ? 1.12f : 1f)
                        .translationZ(focused ? dp(12) : 0f)
                        .setInterpolator(focused
                                ? new android.view.animation.OvershootInterpolator(1.65f)
                                : tvEase)
                        .setDuration(focused ? 265L : 175L).start();
                shine.animate().cancel();
                shine.animate().alpha(focused ? 1f : 0f)
                        .setDuration(150L).start();
                if (focused && selectedDockLabel != null) {
                    if (!TextUtils.equals(selectedDockLabel.getText(), v.getContentDescription()))
                        selectedDockLabel.setText(v.getContentDescription());
                    if (dock != null && v.getParent() == dock)
                        lastFocusedDockIndex = dock.indexOfChild(v);
                }
            }
        });
    }
    return card;
}

private void addDockTile(View tile, int widthDp) {
    // Fix 16:9 banner ratio, akkor is, ha csak egy app van a dokkban.
    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            dp(widthDp), dp(Math.max(56, Math.round(widthDp * 9f / 16f))));
    params.setMargins(dp(7), 0, dp(7), 0);
    dock.addView(tile, params);
}

    /** Dokknal fokuszkal es OK-val kattinthato; a GridView-ban nem, mert ott a racs kezel. */
    private View makeTile(CharSequence label, Drawable icon, int widthDp, int iconDp,
                          boolean interactive, final Runnable action) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tile.setPadding(dp(5), dp(11), dp(5), dp(7));
        // V5.1: elore elkeszitett allapotfuggo hatter.
        // A D-pad fokusz valtasakor mar nem allitunk elo uj GradientDrawable-t.
        if (interactive) {
            tile.setBackground(ultraActionSelector(20));
        } else {
            tile.setBackground(glassRounded(new int[]{0x20F4F8FF, 0x0D7D94B0}, 20, 0x18FFFFFF, 1));
        }
        tile.setClipChildren(false);
        tile.setClipToPadding(false);

        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(innerImageGlassBackground(15));
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp));
        tile.addView(iconBox, boxLp);

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams ivLp = new FrameLayout.LayoutParams(-1, -1);
        ivLp.setMargins(dp(5), dp(5), dp(5), dp(5));
        iconBox.addView(iv, ivLp);

        TextView tv = text(label, 12, 0xEDFFFFFF);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        // A GridView-k tovabbra is nevvel egyutt mutatjak az appokat.
        // Csak a fokepernyo (interactive) csempei rejtik el a belso feliratot.
        if (interactive) tv.setVisibility(View.GONE);
        tile.setContentDescription(label);
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(-1, dp(29));
        tvLp.topMargin = dp(2);
        tile.addView(tv, tvLp);

        tile.setFocusable(interactive);
        tile.setClickable(interactive);
        if (interactive) {
            tile.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (action != null) action.run(); }
            });
            tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override public void onFocusChange(View v, boolean focused) {
                    v.animate().cancel();
                    v.animate().scaleX(focused ? 1.115f : 1f)
                            .scaleY(focused ? 1.115f : 1f)
                            .setInterpolator(tvEase).setDuration(FOCUS_MS).start();
                    // A fokuszkeretet a StateListDrawable automatikusan allitja.
                    // A megszokott 3D kiemelest megtartjuk.
                    v.setElevation(dp(focused ? 18 : 0));
                    if (focused && selectedDockLabel != null) {
                        selectedDockLabel.setText(v.getContentDescription());
                        if (dock != null && v.getParent() == dock)
                            lastFocusedDockIndex = dock.indexOfChild(v);
                    }
                }
            });
        }
        return tile;
    }

    /**
     * V5.1: GridView-csempek ujrahasznositasa. A convertView-t eddig mindharom
     * listaban eldobtuk, ami gorgetesnel uj View-okat es hatterrajzokat
     * generalhatott. Az OK tovabbra is a GridView OnItemClickListener-e.
     */
    private View bindGridTile(View old, CharSequence label, Drawable icon,
                              int widthDp, int iconDp, int heightDp) {
        if (!(old instanceof LinearLayout)) {
            View created = makeTile(label, icon, widthDp, iconDp, false, null);
            created.setLayoutParams(new AbsListView.LayoutParams(-1, dp(heightDp)));
            return created;
        }
        LinearLayout tile = (LinearLayout) old;
        if (tile.getChildCount() != 2 || !(tile.getChildAt(0) instanceof FrameLayout)
                || !(tile.getChildAt(1) instanceof TextView)) {
            View created = makeTile(label, icon, widthDp, iconDp, false, null);
            created.setLayoutParams(new AbsListView.LayoutParams(-1, dp(heightDp)));
            return created;
        }
        FrameLayout iconBox = (FrameLayout) tile.getChildAt(0);
        if (iconBox.getChildCount() == 0 || !(iconBox.getChildAt(0) instanceof ImageView)) {
            View created = makeTile(label, icon, widthDp, iconDp, false, null);
            created.setLayoutParams(new AbsListView.LayoutParams(-1, dp(heightDp)));
            return created;
        }
        ((ImageView) iconBox.getChildAt(0)).setImageDrawable(icon);
        ((TextView) tile.getChildAt(1)).setText(label);
        return tile;
    }

    private void focusFirstDockItem() {
        if (dock != null && dock.getChildCount() > 0) dock.getChildAt(0).requestFocus();
    }

    // ---------- Mentett kedvencek es taviranyitos dokkszerkeszto ----------

    private void loadFavorites() {
        favoritePackages.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (!prefs.contains(PREFS_FAVS)) {
            favoritePackages.addAll(Arrays.asList(DEFAULT_FAVS));
            return;
        }
        try {
            JSONArray array = new JSONArray(prefs.getString(PREFS_FAVS, "[]"));
            for (int i = 0; i < array.length() && favoritePackages.size() < MAX_FAVS; i++) {
                String pkg = array.optString(i, "");
                if (!pkg.isEmpty() && !favoritePackages.contains(pkg)) favoritePackages.add(pkg);
            }
        } catch (JSONException ex) {
            Log.e(TAG, "Hibas mentett kedvenc lista, gyari kedvencek visszatoltese", ex);
            favoritePackages.clear();
            favoritePackages.addAll(Arrays.asList(DEFAULT_FAVS));
        }
    }

    private void saveFavorites() {
        JSONArray array = new JSONArray();
        for (String pkg : favoritePackages) array.put(pkg);
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putString(PREFS_FAVS, array.toString()).apply();
        buildDock();
    }

    private List<ResolveInfo> availableApps() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String[] categories = { Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER };
        for (String category : categories) {
            Intent query = new Intent(Intent.ACTION_MAIN).addCategory(category);
            for (ResolveInfo info : pm.queryIntentActivities(query, 0)) {
                if (info.activityInfo == null || info.activityInfo.packageName == null) continue;
                String pkg = info.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                if (seen.add(pkg) && launchIntent(pm, pkg) != null) result.add(info);
            }
        }
        // A Java sort sokszor meghivja a komparatort. A loadLabel() viszont
        // APK-eroforrast is olvashat: nev/app egyszer, nem nev/osszehasonlitas.
        final HashMap<String, String> sortLabels = new HashMap<>();
        for (ResolveInfo ri : result) {
            sortLabels.put(ri.activityInfo.packageName, ri.loadLabel(pm).toString());
        }
        Collections.sort(result, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return String.CASE_INSENSITIVE_ORDER.compare(
                        sortLabels.get(a.activityInfo.packageName),
                        sortLabels.get(b.activityInfo.packageName));
            }
        });
        return result;
    }

    // --- V6: egyetlen alkalmazassorrend, dokk = elso N elem ---
    private void ensureAppOrder() {
        if (orderReady) return;
        PackageManager pm = getPackageManager();
        List<ResolveInfo> entries = availableApps();
        appMetadata.clear();
        for (ResolveInfo ri : entries) appMetadata.put(ri.activityInfo.packageName, ri);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        hiddenPackages.clear();
        hiddenPackages.addAll(prefs.getStringSet(PREF_HIDDEN_APPS,
                Collections.<String>emptySet()));
        appOrder.clear();
        String saved = prefs.getString(PREF_APP_ORDER, null);
        if (saved != null) {
            try {
                JSONArray items = new JSONArray(saved);
                for (int i = 0; i < items.length(); i++) {
                    String pkg = items.optString(i, "");
                    if (appMetadata.containsKey(pkg) && !hiddenPackages.contains(pkg)
                            && !appOrder.contains(pkg)) appOrder.add(pkg);
                }
            } catch (JSONException ex) { Log.w(TAG, "Hibas v6 appsorrend", ex); }
        } else {
            for (String pkg : favoritePackages) {
                if (appMetadata.containsKey(pkg) && !hiddenPackages.contains(pkg)
                        && !appOrder.contains(pkg)) appOrder.add(pkg);
            }
        }
        int initialDock = saved == null ? appOrder.size()
                : prefs.getInt(PREF_DOCK_SLOTS, favoritePackages.size());
        for (ResolveInfo ri : entries) {
            String pkg = ri.activityInfo.packageName;
            if (!hiddenPackages.contains(pkg) && !appOrder.contains(pkg)) appOrder.add(pkg);
        }
        // A korabbi hatodik kedvenc helye megmarad az appOrder listaban,
        // tehat automatikusan az Osszes alkalmazas elso elemeve valik.
        dockSlots = Math.min(MAX_FAVS, appOrder.size());
        if (dockSlots == 0 && !appOrder.isEmpty()) dockSlots = 1;
        orderReady = true;
        syncDockFromOrder();
    }

    private void refreshInstalledApps() {
        if (!orderReady || moving || !running) return;
        final int revision = ++installedAppsScanRevision;
        iconExecutor.execute(new Runnable() {
            @Override public void run() {
                // A leglassabb resz, a PackageManager-query es a nev szerinti rendezes,
                // mar nem a TV kepernyot megjelenito foszalon tortenik.
                final List<ResolveInfo> available;
                try {
                    available = availableApps();
                } catch (RuntimeException error) {
                    Log.w(TAG, "App-lista hatterlekerdezese sikertelen", error);
                    return;
                }
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        if (!running || !orderReady || moving
                                || revision != installedAppsScanRevision) return;
                        applyInstalledAppsSnapshot(available);
                    }
                });
            }
        });
    }

    /** A kesz, hatterben lekert csomaglistat a UI-szalon alkalmazzuk. */
    private void applyInstalledAppsSnapshot(List<ResolveInfo> available) {
        HashMap<String, ResolveInfo> found = new HashMap<>();
        for (ResolveInfo ri : available) found.put(ri.activityInfo.packageName, ri);
        ArrayList<String> newOrder = new ArrayList<>();
        HashSet<String> included = new HashSet<>();
        for (String pkg : appOrder) {
            if (found.containsKey(pkg) && !hiddenPackages.contains(pkg)
                    && included.add(pkg)) newOrder.add(pkg);
        }
        for (ResolveInfo ri : available) {
            String pkg = ri.activityInfo.packageName;
            if (!hiddenPackages.contains(pkg) && included.add(pkg)) newOrder.add(pkg);
        }
        boolean changed = !appOrder.equals(newOrder);
        // Ha telepult vagy eltunt egy alkalmazas, a korabbi label-cache elavulhat.
        if (changed) appLabelCache.clear();
        appMetadata.clear();
        appMetadata.putAll(found);
        if (changed) {
            appOrder.clear();
            appOrder.addAll(newOrder);
            dockSlots = Math.min(MAX_FAVS, appOrder.size());
            if (dockSlots == 0 && !appOrder.isEmpty()) dockSlots = 1;
            syncDockFromOrder();
            saveOrder();
            if (allGrid != null && allGrid.getAdapter() instanceof BaseAdapter) {
                int oldPos = Math.max(0, allGrid.getSelectedItemPosition());
                ((BaseAdapter) allGrid.getAdapter()).notifyDataSetChanged();
                updateAllGridHeight();
                if (gridMode && allGrid.getCount() > 0) allGrid.setSelection(
                        Math.min(oldPos, allGrid.getCount() - 1));
                else if (gridMode) hideAll();
            }
        }
    }

    private void syncDockFromOrder() {
        favoritePackages.clear();
        for (int i = 0; i < Math.min(dockSlots, appOrder.size()); i++) {
            favoritePackages.add(appOrder.get(i));
        }
        if (dock != null) buildDock();
    }

    private void saveOrder() {
        JSONArray all = new JSONArray();
        for (String pkg : appOrder) all.put(pkg);
        JSONArray favorites = new JSONArray();
        for (String pkg : favoritePackages) favorites.put(pkg);
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putString(PREF_APP_ORDER, all.toString())
                .putInt(PREF_DOCK_SLOTS, dockSlots)
                .putString(PREFS_FAVS, favorites.toString()).apply();
    }

    private boolean isOkKey(int key) {
        return key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER
                || key == KeyEvent.KEYCODE_NUMPAD_ENTER;
    }

    /** 7.5: Az elrejtés nem uninstall. Csak a TVHome alkalmazáslistájából vesszük ki. */
    private void hideApp(String pkg) {
        ensureAppOrder();
        if (pkg == null || !appOrder.contains(pkg)) return;
        if (appOrder.size() <= 1) {
            Toast.makeText(this, "Az utolsó alkalmazás nem rejthető el",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        HashSet<String> updated = new HashSet<>(hiddenPackages);
        updated.add(pkg);
        boolean saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putStringSet(PREF_HIDDEN_APPS, updated).commit();
        if (!saved) {
            Toast.makeText(this, "Nem sikerült elmenteni az elrejtést",
                    Toast.LENGTH_LONG).show();
            return;
        }
        boolean wasDockItem = appOrder.indexOf(pkg) < dockSlots;
        hiddenPackages.clear();
        hiddenPackages.addAll(updated);
        appOrder.remove(pkg);
        dockSlots = Math.min(MAX_FAVS, appOrder.size());
        syncDockFromOrder();
        saveOrder();
        refreshGridAfterVisibilityChange();
        if (wasDockItem) focusFirstDockItem();
        Toast.makeText(this, "Alkalmazás elrejtve (nem lett törölve)",
                Toast.LENGTH_SHORT).show();
    }

    private void unhideApp(String pkg) {
        if (pkg == null || !hiddenPackages.contains(pkg)) return;
        HashSet<String> updated = new HashSet<>(hiddenPackages);
        updated.remove(pkg);
        boolean saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putStringSet(PREF_HIDDEN_APPS, updated).commit();
        if (!saved) {
            Toast.makeText(this, "Nem sikerült elmenteni a visszaállítást",
                    Toast.LENGTH_LONG).show();
            return;
        }
        hiddenPackages.clear();
        hiddenPackages.addAll(updated);
        // A visszahozott alkalmazás az Összes alkalmazás VÉGÉRE kerül,
        // így a már beállított ötös dokk sorrendjét nem borítja fel.
        if (appMetadata.containsKey(pkg) && !appOrder.contains(pkg)) appOrder.add(pkg);
        dockSlots = Math.min(MAX_FAVS, appOrder.size());
        syncDockFromOrder();
        saveOrder();
        refreshGridAfterVisibilityChange();
        Toast.makeText(this, "Alkalmazás ismét látható", Toast.LENGTH_SHORT).show();
    }

    private void refreshGridAfterVisibilityChange() {
        if (allGrid == null) return;
        int oldSelection = Math.max(0, allGrid.getSelectedItemPosition());
        if (allGrid.getAdapter() instanceof BaseAdapter)
            ((BaseAdapter) allGrid.getAdapter()).notifyDataSetChanged();
        updateAllGridHeight();
        if (gridMode && allGrid.getCount() == 0) {
            hideAll();
        } else if (gridMode) {
            allGrid.setSelection(Math.min(oldSelection, allGrid.getCount() - 1));
            allGrid.requestFocus();
        }
        allGrid.post(new Runnable() {
            @Override public void run() {
                if (allGrid != null) refreshVisibleGridFocus(allGrid);
            }
        });
    }

    /** Az összes elrejtett appot itt lehet visszaállítani, törlés nélkül. */
    private void showHiddenAppsMenu() {
        ensureAppOrder();
        final ArrayList<String> packages = new ArrayList<>();
        for (String pkg : hiddenPackages) {
            if (appMetadata.containsKey(pkg)) packages.add(pkg);
        }
        Collections.sort(packages, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                return appTitle(a).compareToIgnoreCase(appTitle(b));
            }
        });
        if (packages.isEmpty()) {
            showLightweightMenu("Rejtett alkalmazások",
                    new String[]{"Nincs elrejtett alkalmazás"}, new MenuAction() {
                        @Override public void onSelected(int which) { showTvHomeSettings(); }
                    }, new Runnable() {
                        @Override public void run() { showTvHomeSettings(); }
                    });
            return;
        }
        String[] choices = new String[packages.size()];
        for (int i = 0; i < packages.size(); i++) {
            choices[i] = "Visszaállítás: " + appTitle(packages.get(i));
        }
        showLightweightMenu("Rejtett alkalmazások", choices, new MenuAction() {
            @Override public void onSelected(int index) {
                unhideApp(packages.get(index));
                showHiddenAppsMenu();
            }
        }, new Runnable() {
            @Override public void run() { showTvHomeSettings(); }
        });
    }

    private String selectedPackage() {
        if (gridMode && allGrid != null && getCurrentFocus() == allGrid) {
            int selected = allGrid.getSelectedItemPosition();
            int idx = dockSlots + selected;
            return selected >= 0 && idx < appOrder.size() ? appOrder.get(idx) : null;
        }
        if (dock != null && getCurrentFocus() != null
                && getCurrentFocus().getParent() == dock) {
            Object pkg = getCurrentFocus().getTag();
            return pkg instanceof String ? (String) pkg : null;
        }
        return null;
    }

    private void showAppActions(final String pkg) {
        pressedPackage = null;
        pressedConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
        if (longPressRunnable != null) mainHandler.removeCallbacks(longPressRunnable);
        // Nem kozepre ugras: a kijelolt app csempeje mellett jelenik meg.
        View anchor = (gridMode && allGrid != null)
                ? allGrid.getSelectedView() : findDockTile(pkg);
        if (anchor == null) anchor = getCurrentFocus();
        showAnchoredAppMenu(anchor, pkg);
    }

    private void showAnchoredAppMenu(View anchor, final String pkg) {
        if (modalView != null) closeLightweightMenu();
        closeSettingsDropdown();
        modalReturnFocus = getCurrentFocus();
        modalBackAction = null;
        modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
        modalOptions.clear();
        FrameLayout overlay = new FrameLayout(this);
        // A jelenlegi appracs lathato marad a menu mogott.
        overlay.setBackgroundColor(0x16050A10);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(9), dp(9), dp(9), dp(9));
        panel.setBackground(new UltraGlassDrawable(19, 2));
        panel.setElevation(dp(22));
        String[] labels = {"Áthelyezés", "Elrejtés", "Eltávolítás"};
        for (int i = 0; i < labels.length; i++) {
            final int which = i;
            TextView option = actionButton(labels[i]);
            option.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            option.setTextSize(15);
            option.setCompoundDrawablePadding(dp(10));
            if (i == 0) {
                Drawable arrows = new FourWayIcon();
                arrows.setBounds(0, 0, dp(20), dp(20));
                option.setCompoundDrawables(arrows, null, null, null);
            } else if (i == 1) {
                Drawable eye = getDrawable(android.R.drawable.ic_menu_close_clear_cancel);
                if (eye != null) {
                    eye = eye.mutate();
                    eye.setTint(0xFFE6F3FF);
                    eye.setBounds(0, 0, dp(20), dp(20));
                    option.setCompoundDrawables(eye, null, null, null);
                }
            } else {
                Drawable trash = getDrawable(android.R.drawable.ic_menu_delete);
                if (trash != null) {
                    trash = trash.mutate();
                    trash.setTint(0xFFFF6475);
                    trash.setBounds(0, 0, dp(20), dp(20));
                    option.setCompoundDrawables(trash, null, null, null);
                }
                option.setTextColor(0xFFFF6475);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(49));
            if (i == 0) lp.bottomMargin = dp(6);
            panel.addView(option, lp);
            option.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    closeLightweightMenu();
                    if (which == 0) beginMove(pkg);
                    else if (which == 1) hideApp(pkg);
                    else uninstallApp(pkg);
                }
            });
            modalOptions.add(option);
        }
        final int menuWidth = dp(235);
        final int menuHeight = dp(183);
        int x = dp(30);
        int y = dp(80);
        if (anchor != null && anchor.isAttachedToWindow()) {
            Rect r = new Rect();
            anchor.getGlobalVisibleRect(r);
            int[] xy = new int[2];
            root.getLocationOnScreen(xy);
            int rightX = r.right - xy[0] + dp(13);
            int leftX = r.left - xy[0] - menuWidth - dp(13);
            x = (rightX + menuWidth < root.getWidth() - dp(12)) ? rightX : leftX;
            y = r.top - xy[1] + dp(8);
        }
        x = Math.max(dp(10), Math.min(x, root.getWidth() - menuWidth - dp(10)));
        y = Math.max(dp(10), Math.min(y, root.getHeight() - menuHeight - dp(10)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(menuWidth, menuHeight);
        lp.leftMargin = x;
        lp.topMargin = y;
        overlay.addView(panel, lp);
        modalView = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        panel.setPivotY(dp(5));
        panel.setScaleX(0.91f); panel.setScaleY(0.91f); panel.setAlpha(0f);
        panel.setTranslationY(dp(20));
        panel.animate().scaleX(1f).scaleY(1f).alpha(1f).translationY(0f)
                .setInterpolator(tvEase).setDuration(Math.max(PANEL_MS, 235L)).start();
        modalOptions.get(0).requestFocus();
    }

    private void uninstallApp(String pkg) {
        if (pkg == null || pkg.equals(getPackageName())) {
            Toast.makeText(this, "A TVHome saját magát nem törölheti", Toast.LENGTH_LONG).show();
            return;
        }
        Uri uri = Uri.parse("package:" + pkg);
        // Android 9+ cel-API eseten REQUEST_DELETE_PACKAGES kell a manifestbe.
        // Az eltavolitast mindig a rendszer hagyatja jova a felhasznaloval.
        try {
            Intent intent = new Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri);
            startActivity(intent);
            return;
        } catch (Exception primary) {
            Log.w(TAG, "Android eltavolito nem indult; ACTION_DELETE tartalek", primary);
        }
        try {
            startActivity(new Intent(Intent.ACTION_DELETE, uri));
            return;
        } catch (Exception secondary) {
            Log.w(TAG, "ACTION_DELETE sem erheto el, appreszletek megnyitasa", secondary);
        }
        try {
            Intent info = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri);
            startActivity(info);
            Toast.makeText(this,
                    "Az alkalmazás adatlapján válaszd az Eltávolítás lehetőséget",
                    Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Log.e(TAG, "Nincs elerheto alkalmazaseltavolito", ex);
            Toast.makeText(this,
                    "A TV nem adott elérhető eltávolítófelületet ehhez az apphoz",
                    Toast.LENGTH_LONG).show();
        }
    }

    private String appTitle(String pkg) {
        String title = appLabelCache.get(pkg);
        if (title != null) return title;
        ResolveInfo ri = appMetadata.get(pkg);
        if (ri != null) {
            title = ri.loadLabel(getPackageManager()).toString();
            appLabelCache.put(pkg, title);
            return title;
        }
        String cached = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString("dock_title_" + pkg, pkg);
        return cached == null ? pkg : cached;
    }

    private void beginMove(String pkg) {
        ensureAppOrder();
        int index = appOrder.indexOf(pkg);
        if (index < 0) return;
        beforeMove = new ArrayList<>(appOrder);
        moving = true;
        movingPackage = pkg;
        focusMoved(index);
        View picked = index < dockSlots && dock != null && index < dock.getChildCount()
                ? dock.getChildAt(index) : (allGrid == null ? null : allGrid.getSelectedView());
        wiggleMovingTile(picked);
        Toast.makeText(this, "Nyilakkal mozgatás  •  OK: mentés  •  Vissza: mégse",
                Toast.LENGTH_SHORT).show();
    }

    // Az elozo kepernyo-kepet (csomag -> dokkpozicio) hasznaljuk a FLIP
    // animaciohoz; az appok valodi sorrendje tovabbra is az eredeti swap logika.
    private HashMap<String, Integer> snapshotDockPositions() {
        HashMap<String, Integer> positions = new HashMap<>();
        if (dock != null) {
            for (int i = 0; i < dock.getChildCount(); i++) {
                Object pkg = dock.getChildAt(i).getTag();
                if (pkg instanceof String) positions.put((String) pkg, i);
            }
        }
        return positions;
    }

    private HashMap<Integer, String> snapshotGridPositions() {
        HashMap<Integer, String> positions = new HashMap<>();
        if (allGrid != null) {
            int first = allGrid.getFirstVisiblePosition();
            for (int i = 0; i < allGrid.getChildCount(); i++) {
                Object pkg = allGrid.getChildAt(i).getTag();
                if (pkg instanceof String) positions.put(first + i, (String) pkg);
            }
        }
        return positions;
    }

    private void animateReorderedTiles(final HashMap<String, Integer> oldDock,
                                       final HashMap<Integer, String> oldGrid) {
        final int revision = ++rearrangeRevision;
        if (dock != null && oldDock != null) {
            dock.post(new Runnable() {
                @Override public void run() {
                    if (revision != rearrangeRevision || dock == null) return;
                    for (int i = 0; i < dock.getChildCount(); i++) {
                        View tile = dock.getChildAt(i);
                        Object tag = tile.getTag();
                        Integer was = tag instanceof String ? oldDock.get((String) tag) : null;
                        tile.animate().cancel();
                        tile.setTranslationX(0f);
                        tile.setAlpha(1f);
                        if (was != null && was != i) {
                            float step = tile.getWidth() + dp(6);
                            tile.setTranslationX((was - i) * step);
                            tile.animate().translationX(0f).setDuration(205L)
                                    .setInterpolator(tvEase).start();
                        } else if (was == null) {
                            tile.setAlpha(0.72f);
                            tile.animate().alpha(1f).setDuration(195L)
                                    .setInterpolator(tvEase).start();
                        }
                    }
                }
            });
        }
        if (allGrid != null && oldGrid != null) {
            final GridView grid = allGrid;
            grid.post(new Runnable() {
                @Override public void run() {
                    if (revision != rearrangeRevision || allGrid != grid) return;
                    int first = grid.getFirstVisiblePosition();
                    for (int i = 0; i < grid.getChildCount(); i++) {
                        View tile = grid.getChildAt(i);
                        Object pkg = tile.getTag();
                        String was = oldGrid.get(first + i);
                        if (was != null && pkg instanceof String && !was.equals(pkg)) {
                            tile.animate().cancel();
                            tile.setAlpha(0.72f);
                            tile.setTranslationX(dp(8));
                            tile.animate().alpha(1f).translationX(0f)
                                    .setDuration(205L).setInterpolator(tvEase).start();
                        }
                    }
                }
            });
        }
    }

    private void wiggleMovingTile(View tile) {
        if (tile == null) return;
        ObjectAnimator wiggle = ObjectAnimator.ofFloat(tile, "rotation",
                0f, -1.8f, 1.7f, -1.1f, 0f);
        wiggle.setDuration(310L);
        wiggle.setInterpolator(tvEase);
        wiggle.start();
    }

    private void moveByArrow(int key) {
        if (!moving || movingPackage == null) return;
        int i = appOrder.indexOf(movingPackage);
        if (i < 0) return;
        int target = i;
        if (i < dockSlots) {
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) target = Math.max(0, i - 1);
            if (key == KeyEvent.KEYCODE_DPAD_RIGHT) target = Math.min(dockSlots - 1, i + 1);
            if (key == KeyEvent.KEYCODE_DPAD_DOWN && appOrder.size() > dockSlots)
                target = Math.min(appOrder.size() - 1,
                        dockSlots + Math.min(i, GRID_COLUMNS - 1));
        } else {
            int inGrid = i - dockSlots;
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) target = Math.max(dockSlots, i - 1);
            if (key == KeyEvent.KEYCODE_DPAD_RIGHT) target = Math.min(appOrder.size() - 1, i + 1);
            if (key == KeyEvent.KEYCODE_DPAD_DOWN)
                target = Math.min(appOrder.size() - 1, i + GRID_COLUMNS);
            if (key == KeyEvent.KEYCODE_DPAD_UP) {
                if (inGrid < GRID_COLUMNS && dockSlots > 0) {
                    target = Math.min(dockSlots - 1, inGrid);
                } else target = Math.max(dockSlots, i - GRID_COLUMNS);
            }
        }
        if (target != i) {
            // ELOZETES mozgatasi nezet: egyetlen appot huzunk vegig a helyeken.
            // Minden egyes nyil lenyomasanal visszaallitjuk a mozgataskor
            // rogzitett eredeti sorrendet, majd csak a MOSTANI celhellyel
            // cserelunk. Ezert a korabban erintett dokkhelyek azonnal
            // visszakapjak a sajat appjukat, nem maradnak a racsban.
            // Az eredmenyt csak az OK menti, a Vissza teljesen visszavonja.
            if (beforeMove == null) return;
            int originalIndex = beforeMove.indexOf(movingPackage);
            if (originalIndex < 0 || target >= beforeMove.size()) return;
            HashMap<String, Integer> dockBefore = snapshotDockPositions();
            HashMap<Integer, String> gridBefore = snapshotGridPositions();
            appOrder.clear();
            appOrder.addAll(beforeMove);
            Collections.swap(appOrder, originalIndex, target);
            if (i < dockSlots || target < dockSlots) syncDockFromOrder();
            if (allGrid != null && allGrid.getAdapter() instanceof BaseAdapter)
                ((BaseAdapter) allGrid.getAdapter()).notifyDataSetChanged();
            focusMoved(target);
            animateReorderedTiles(dockBefore, gridBefore);
        }
    }

    private void focusMoved(final int index) {
        if (index < dockSlots) {
            if (gridMode) hideAll();
            if (dock != null && index >= 0 && index < dock.getChildCount()) {
                View tile = dock.getChildAt(index);
                tile.requestFocus();
                tile.animate().rotation(moving ? 1.3f : 0f)
                        .setInterpolator(tvEase).setDuration(FOCUS_MS).start();
            }
        } else {
            int pos = index - dockSlots;
            if (!gridMode) {
                gridFocusIndexOnOpen = pos;
                showAll();
            }
            if (allGrid != null) {
                allGrid.setSelection(pos);
                allGrid.requestFocus();
            }
        }
    }

    private void finishMove(boolean keep) {
        if (!moving) return;
        int pos = appOrder.indexOf(movingPackage);
        if (!keep && beforeMove != null) {
            appOrder.clear();
            appOrder.addAll(beforeMove);
            pos = appOrder.indexOf(movingPackage);
        }
        moving = false;
        movingPackage = null;
        beforeMove = null;
        syncDockFromOrder();
        if (keep) saveOrder();
        if (allGrid != null && allGrid.getAdapter() instanceof BaseAdapter)
            ((BaseAdapter) allGrid.getAdapter()).notifyDataSetChanged();
        if (pos >= 0) focusMoved(pos);
    }

    // V3.1: A TV taviranyito nyilai nem lephetnek ki a szerkeszto ablaka moge.
    // A GridView kezelje az OK gombot, mi csak a negy iranyt iranyitjuk.
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        final int keyCode = event.getKeyCode();
        final boolean keyDown = event.getAction() == KeyEvent.ACTION_DOWN;
        if (ambientActive) return handleAmbientMediaKey(event);
        if (ambientWakeKey == keyCode) {
            if (!keyDown || event.isCanceled()) ambientWakeKey = KeyEvent.KEYCODE_UNKNOWN;
            return true;
        }
        if (keyDown && event.getRepeatCount() == 0) scheduleAmbientTimeout();
        if (phoneUploadClosingKey == keyCode) {
            if (!keyDown) phoneUploadClosingKey = KeyEvent.KEYCODE_UNKNOWN;
            return true;
        }
        if (phoneUploadOverlay != null) {
            if (keyDown && event.getRepeatCount() == 0
                    && (keyCode == KeyEvent.KEYCODE_BACK || isOkKey(keyCode))) {
                phoneUploadClosingKey = keyCode;
                stopPhoneUpload(false);
                showWallpaperMenu();
            }
            // No key is allowed to reach the dock/menu while the upload screen is open.
            return true;
        }
        if (controlCenterView != null) return handleControlCenterKey(event);
        if (appearanceOverlay != null) return handleAppearanceKey(event);
        if (handleSpotifyControlKey(event)) return true;
        // MENU on the remote is an optional shortcut, only if the TV forwards it.
        // The Beallitasok menu entry is the guaranteed alternative.
        if (keyCode == KeyEvent.KEYCODE_MENU && modalView == null
                && editorView == null && pickerView == null && !moving) {
            if (keyDown && event.getRepeatCount() == 0) showControlCenter(null);
            return true;
        }
        // A torlesmegerosites mindig elsoseget kap a galeria sajat gombkezelojevel szemben.
        if (wallpaperDeleteOverlay != null) return handleWallpaperDeleteKey(event);
        // A kepgaleria sajat D-pad / OK kezelest kap. A kozos modal-menu
        // kulonben elnyelne az OSSZES nyilat es a kepvalaszto OK gombjat.
        if (wallpaperGalleryGrid != null && modalView != null
                && handleWallpaperGalleryKey(event)) return true;
        // Ne tekintsuk uj LE/FEL lepesnek ugyanannak a lenyomasnak az ismetleseit,
        // amikor a Beallitasok / Forrasok felso resz es a dokk kozott valtok.
        // Kulonben a Beallitasokbol visszalepve azonnal megnyilhatna az appracs.
        if (keyDown && keyCode == headerNavKey && event.getRepeatCount() > 0)
            return true;
        if (moving) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                    || keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (keyDown) moveByArrow(keyCode);
                return true;
            }
            if (isOkKey(keyCode)) {
                if (!keyDown) finishMove(true);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (keyDown) finishMove(false);
                return true;
            }
        }
        // OK: rovid lenyomas = inditas, 620 ms felett = ketopcios helyi menu.
        if (modalView == null && editorView == null && pickerView == null
                && isOkKey(keyCode)) {
            final String focusPkg = selectedPackage();
            if (focusPkg != null) {
                if (keyDown) {
                    if (event.getRepeatCount() == 0) {
                        pressedConfirmKey = keyCode;
                        pressedPackage = focusPkg;
                        longPressOpened = false;
                        if (longPressRunnable != null) mainHandler.removeCallbacks(longPressRunnable);
                        final String pkg = focusPkg;
                        longPressRunnable = new Runnable() {
                            @Override public void run() {
                                if (pkg.equals(pressedPackage)) {
                                    longPressOpened = true;
                                    showAppActions(pkg);
                                }
                            }
                        };
                        mainHandler.postDelayed(longPressRunnable, 620L);
                    }
                } else if (pressedConfirmKey == keyCode) {
                    if (longPressRunnable != null) mainHandler.removeCallbacks(longPressRunnable);
                    String pkg = pressedPackage;
                    boolean wasLong = longPressOpened;
                    pressedPackage = null;
                    pressedConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
                    longPressOpened = false;
                    if (!wasLong && pkg != null) launchFavoritePackage(pkg);
                }
                return true;
            }
        }
        if (modalView == null && !moving && pressedPackage == null) {
            if (event.getAction() == KeyEvent.ACTION_UP && keyCode == gridNavKey) {
                gridNavKey = KeyEvent.KEYCODE_UNKNOWN;
                return true;
            }
            if (keyDown && keyCode == KeyEvent.KEYCODE_DPAD_DOWN && !gridMode
                    && dock != null && getCurrentFocus() != null
                    && getCurrentFocus().getParent() == dock) {
                gridFocusIndexOnOpen = 0;
                showAll();
                gridNavKey = keyCode;
                return true;
            }
            // Never let RIGHT on the last app leave the app grid for the dock.
            // Wrap within the CURRENT row (including a short last row).
            // LEFT from the first app behaves symmetrically.
            if (gridMode && allGrid != null && getCurrentFocus() == allGrid
                    && (keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                    || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                if (keyDown && allGrid.getCount() > 0) {
                    int current = allGrid.getSelectedItemPosition();
                    if (current < 0) current = 0;
                    int first = (current / GRID_COLUMNS) * GRID_COLUMNS;
                    int last = Math.min(first + GRID_COLUMNS, allGrid.getCount()) - 1;
                    int next = keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                            ? (current >= last ? first : current + 1)
                            : (current <= first ? last : current - 1);
                    allGrid.setSelection(next);
                    allGrid.requestFocus();
                    // Recycler/layout timing may change the visible child after setSelection.
                    allGrid.post(new Runnable() {
                        @Override public void run() {
                            if (gridMode && allGrid != null) refreshVisibleGridFocus(allGrid);
                        }
                    });
                }
                return true;
            }
            if (keyDown && keyCode == KeyEvent.KEYCODE_DPAD_UP
                    && gridMode && allGrid != null && getCurrentFocus() == allGrid
                    && allGrid.getSelectedItemPosition() >= 0
                    && allGrid.getSelectedItemPosition() < GRID_COLUMNS) {
                int preferred = Math.min(dock.getChildCount() - 1,
                        allGrid.getSelectedItemPosition());
                hideAll();
                if (preferred >= 0) dock.getChildAt(preferred).requestFocus();
                gridNavKey = keyCode;
                return true;
            }
        }
        // Beallitasok: mar fokuszra megjelenik az also ket menupont, LE-vel belelepunk.
        if (settingsDropdown != null && modalView == null && !moving) {
            View focused = getCurrentFocus();
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (keyDown) {
                    suppressSettingsAutoOpen = true;
                    closeSettingsDropdown();
                    if (settingsButton != null) settingsButton.requestFocus();
                }
                return true;
            }
            if (focused == settingsButton && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (keyDown && settingsWallpaperRow != null) settingsWallpaperRow.requestFocus();
                return true;
            }
            if (focused == settingsWallpaperRow || focused == settingsAppearanceRow
                    || focused == settingsControlRow || focused == settingsHiddenRow
                    || focused == settingsSpotifyRow || focused == settingsInputRow
                    || focused == settingsAndroidRow) {
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                    if (keyDown) {
                        if (focused == settingsAndroidRow) settingsInputRow.requestFocus();
                        else if (focused == settingsInputRow) settingsSpotifyRow.requestFocus();
                        else if (focused == settingsSpotifyRow) settingsHiddenRow.requestFocus();
                        else if (focused == settingsHiddenRow) settingsControlRow.requestFocus();
                        else if (focused == settingsControlRow) settingsAppearanceRow.requestFocus();
                        else if (focused == settingsAppearanceRow) settingsWallpaperRow.requestFocus();
                        else settingsButton.requestFocus();
                    }
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    if (keyDown && event.getRepeatCount() == 0) {
                        if (focused == settingsWallpaperRow) {
                            settingsAppearanceRow.requestFocus();
                        } else if (focused == settingsAppearanceRow) {
                            settingsControlRow.requestFocus();
                        } else if (focused == settingsControlRow) {
                            settingsHiddenRow.requestFocus();
                        } else if (focused == settingsHiddenRow) {
                            settingsSpotifyRow.requestFocus();
                        } else if (focused == settingsSpotifyRow) {
                            settingsInputRow.requestFocus();
                        } else if (focused == settingsInputRow) {
                            settingsAndroidRow.requestFocus();
                        } else if (focused == settingsAndroidRow && dock != null
                                && dock.getChildCount() > 0) {
                            // Utolso lepes: Android beallitasok -> utoljara kijelolt dokkelem.
                            int index = Math.max(0, Math.min(lastFocusedDockIndex,
                                    dock.getChildCount() - 1));
                            if (dock.getChildAt(index).requestFocus()) {
                                closeSettingsDropdown();
                                // Az azonos gombnyomas felengedese (es ismetlese)
                                // ne keruljon at az appracs LE gombos kezelesebe.
                                headerNavKey = keyCode;
                            }
                        }
                    }
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                        || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    if (keyDown) {
                        closeSettingsDropdown();
                        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && inputsButton != null)
                            inputsButton.requestFocus();
                        else settingsButton.requestFocus();
                    }
                    return true;
                }
                if (isOkKey(keyCode)) {
                    if (!keyDown) focused.performClick();
                    return true;
                }
            }
        }
        // A sajat opciovalaszto megtartja a fokuszt a fokepernyo ablakan belul.
        if (modalView != null) {
            int key = event.getKeyCode();
            boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
            if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (down && !modalOptions.isEmpty()) {
                    int selected = 0;
                    View focus = getCurrentFocus();
                    for (int i = 0; i < modalOptions.size(); i++) {
                        if (modalOptions.get(i) == focus) { selected = i; break; }
                    }
                    int direction = key == KeyEvent.KEYCODE_DPAD_DOWN ? 1 : -1;
                    int target = (selected + direction + modalOptions.size()) % modalOptions.size();
                    modalOptions.get(target).requestFocus();
                }
                return true;
            }
            if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT) return true;
            if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER
                    || key == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    // Az eredeti csempen mar lenyomott hosszu OK ismétléseit nem
                    // tekintjuk uj menuvalasztasnak.
                    if (event.getRepeatCount() == 0) modalConfirmDownKey = key;
                } else if (event.getAction() == KeyEvent.ACTION_UP) {
                    boolean freshPress = modalConfirmDownKey == key;
                    modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
                    if (freshPress) {
                        View focus = getCurrentFocus();
                        if (modalOptions.contains(focus)) focus.performClick();
                    }
                }
                return true;
            }
        }
        if (editorView != null && pickerView == null) {
            final int key = event.getKeyCode();
            if (key == KeyEvent.KEYCODE_DPAD_LEFT
                    || key == KeyEvent.KEYCODE_DPAD_RIGHT
                    || key == KeyEvent.KEYCODE_DPAD_UP
                    || key == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    navigateEditor(key);
                }
                // Az ACTION_UP-ot is elnyeljuk, nehogy a hatterben levo dokk kapja.
                return true;
            }
        }
        // Dokk -> felso Inputs / Beallitasok, majd LE -> ugyanaz a dokkelem.
        // A menuk sajat D-pad kezelesebe nem avatkozunk bele.
        if (modalView == null && editorView == null && pickerView == null && !gridMode) {
            int key = event.getKeyCode();
            if (event.getAction() == KeyEvent.ACTION_UP && key == headerNavKey) {
                headerNavKey = KeyEvent.KEYCODE_UNKNOWN;
                return true;
            }
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                View focused = getCurrentFocus();
                if (key == KeyEvent.KEYCODE_DPAD_UP && focused != null &&
                        focused.getParent() == dock && inputsButton != null && settingsButton != null) {
                    int index = dock.indexOfChild(focused);
                    View target = spotifyPanel != null && spotifyPanel.getVisibility() == View.VISIBLE
                            && index < Math.max(2, dock.getChildCount() - 2)
                            ? spotifyPlayButton
                            : (index < dock.getChildCount() / 2 ? inputsButton : settingsButton);
                    if (index == 0 && szolnokWeatherChip != null)
                        target = szolnokWeatherChip;
                    if (target != null && target.requestFocus()) {
                        headerNavKey = key;
                        return true;
                    }
                } else if (focused == szolnokWeatherChip) {
                    if (key == KeyEvent.KEYCODE_DPAD_RIGHT && inputsButton != null) {
                        View target = spotifyPanel != null && spotifyPanel.getVisibility() == View.VISIBLE
                                ? spotifyPrevButton : inputsButton;
                        if (target != null) target.requestFocus();
                        headerNavKey = key; return true;
                    }
                    if (key == KeyEvent.KEYCODE_DPAD_DOWN && dock != null
                            && dock.getChildCount() > 0) {
                        dock.getChildAt(0).requestFocus(); headerNavKey = key; return true;
                    }
                } else if (focused == inputsButton && key == KeyEvent.KEYCODE_DPAD_LEFT) {
                    View target = spotifyPanel != null && spotifyPanel.getVisibility() == View.VISIBLE
                            ? spotifyNextButton : szolnokWeatherChip;
                    if (target != null && target.requestFocus()) headerNavKey = key;
                    return true;
                } else if (spotifyButtonHasFocus(focused)) {
                    if (key == KeyEvent.KEYCODE_DPAD_DOWN && dock != null && dock.getChildCount() > 0) {
                        int index = Math.max(0, Math.min(lastFocusedDockIndex,
                                dock.getChildCount() - 1));
                        if (dock.getChildAt(index).requestFocus()) headerNavKey = key;
                        return true;
                    }
                    if (key == KeyEvent.KEYCODE_DPAD_UP) {
                        if (inputsButton != null && inputsButton.requestFocus()) headerNavKey = key;
                        return true;
                    }
                    if (key == KeyEvent.KEYCODE_DPAD_LEFT && focused == spotifyPrevButton) {
                        if (szolnokWeatherChip != null && szolnokWeatherChip.requestFocus())
                            headerNavKey = key;
                        return true;
                    }
                    if (key == KeyEvent.KEYCODE_DPAD_RIGHT && focused == spotifyNextButton) {
                        if (inputsButton != null && inputsButton.requestFocus()) headerNavKey = key;
                        return true;
                    }
                } else if (key == KeyEvent.KEYCODE_DPAD_DOWN &&
                        (focused == inputsButton || focused == settingsButton) &&
                        dock != null && dock.getChildCount() > 0) {
                    int index = Math.max(0, Math.min(lastFocusedDockIndex,
                            dock.getChildCount() - 1));
                    if (dock.getChildAt(index).requestFocus()) {
                        headerNavKey = key;
                        return true;
                    }
                }
            }
        }
        // TVHome 5.0: a fokepernyo dokkja korbefordul.
        // Az overlay-k (szerkeszto, osszes app, appvalaszto) tovabbra is a sajat
        // fokusszabalyaikat hasznaljak; itt csak a tenyleges dokk kapja a nyilakat.
        if (editorView == null && pickerView == null && !gridMode
                && dock != null && dock.getChildCount() > 1) {
            final int key = event.getKeyCode();
            if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (event.getAction() == KeyEvent.ACTION_UP && key == wrappedDockKey) {
                    wrappedDockKey = KeyEvent.KEYCODE_UNKNOWN;
                    return true;
                }
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    View focused = getCurrentFocus();
                    if (focused != null && focused.getParent() == dock) {
                        int position = dock.indexOfChild(focused);
                        int target = -1;
                        if (key == KeyEvent.KEYCODE_DPAD_LEFT && position == 0) {
                            target = dock.getChildCount() - 1;
                        } else if (key == KeyEvent.KEYCODE_DPAD_RIGHT
                                && position == dock.getChildCount() - 1) {
                            target = 0;
                        }
                        if (target >= 0 && dock.getChildAt(target).requestFocus()) {
                            wrappedDockKey = key;
                            return true;
                        }
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void navigateEditor(int key) {
        if (editorGrid == null || editorAddButton == null || editorDoneButton == null) return;
        View focused = getCurrentFocus();
        int count = editorGrid.getCount();

        // Ket also gomb: az egyikrol a masikra mindig el lehessen lepni.
        if (focused == editorAddButton || focused == editorDoneButton || count == 0) {
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) {
                editorAddButton.requestFocus();
            } else if (key == KeyEvent.KEYCODE_DPAD_RIGHT) {
                editorDoneButton.requestFocus();
            } else if (key == KeyEvent.KEYCODE_DPAD_UP && count > 0) {
                int firstInLastRow = ((count - 1) / 4) * 4;
                int target = (focused == editorDoneButton) ? count - 1 : firstInLastRow;
                editorGrid.setSelection(target);
                editorGrid.requestFocus();
            } // LE: a gombon marad, nem ugrik at a hatter-dokkra
            return;
        }

        // Ha a fokusz valamiert mashol volt, visszahozzuk a szerkesztobe.
        if (focused != editorGrid) {
            editorGrid.requestFocus();
            if (editorGrid.getSelectedItemPosition() < 0) editorGrid.setSelection(0);
            return;
        }

        int selected = editorGrid.getSelectedItemPosition();
        if (selected < 0) selected = 0;
        int next = selected;
        switch (key) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (selected % 4 > 0) next = selected - 1;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (selected % 4 < 3 && selected + 1 < count) next = selected + 1;
                break;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (selected >= 4) next = selected - 4;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (selected + 4 < count) {
                    next = selected + 4;
                } else {
                    // Az also sorbol mindig az also vezerlogombokra lepunk.
                    if (selected % 4 == 3) editorDoneButton.requestFocus();
                    else editorAddButton.requestFocus();
                    return;
                }
                break;
            default:
                return;
        }
        if (next != selected) editorGrid.setSelection(next);
    }

    private void showEditor(final int focusPosition) {
        if (pickerView != null) hidePicker();
        if (editorView != null) hideEditor();
        hideAll();
        final PackageManager pm = getPackageManager();
        final List<String> visible = new ArrayList<>(favoritePackages);

        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xBE07111D);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(46), dp(24), dp(46), dp(22));
        overlay.addView(body, new FrameLayout.LayoutParams(-1, -1));

        TextView heading = text("Dokk szerkesztése", 27, 0xFFFFFFFF);
        heading.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        body.addView(heading);
        TextView help = text("Válassz egy kedvencet az áthelyezéshez vagy eltávolításhoz. Az OK gomb nyitja a lehetőségeket.", 13, 0xC8FFFFFF);
        LinearLayout.LayoutParams helpLp = new LinearLayout.LayoutParams(-1, -2);
        helpLp.topMargin = dp(8);
        body.addView(help, helpLp);

        TextView section = text("K E D V E N C E K  (" + visible.size() + "/" + MAX_FAVS + ")", 12, 0xD6FFFFFF);
        LinearLayout.LayoutParams secLp = new LinearLayout.LayoutParams(-1, -2);
        secLp.topMargin = dp(20);
        secLp.bottomMargin = dp(8);
        body.addView(section, secLp);

        final GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setHorizontalSpacing(dp(10));
        grid.setVerticalSpacing(dp(10));
        grid.setVerticalScrollBarEnabled(false);
        grid.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        grid.setFocusable(true);
        grid.setClickable(true);
        final Drawable selectedInGrid = rounded(0x55FFFFFF, 18, 0xFFFFFFFF, 2);
        final Drawable invisibleWhenOutside = new ColorDrawable(0x00000000);
        grid.setSelector(selectedInGrid);
        grid.setDrawSelectorOnTop(true);
        // GridView a legutobbi kijelolt elemet akkor is kirajzolhatja,
        // ha mar az also Hozzaadas/Kesz gomb viszi a fokuszt.
        grid.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focused) {
                grid.setSelector(focused ? selectedInGrid : invisibleWhenOutside);
                grid.invalidate();
            }
        });
        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return visible.size(); }
            @Override public Object getItem(int p) { return visible.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View convert, ViewGroup parent) {
                String pkg = visible.get(p);
                // A recycler gyakran ugyanazt a poziciot keri ujra. Ilyenkor
                // ne olvassuk be ismet az APK ikonjait es a csomagadatokat.
                String key = "fav:" + pkg;
                if (convert != null && key.equals(convert.getTag())) return convert;
                View result;
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    result = bindGridTile(convert, pm.getApplicationLabel(ai),
                            pm.getApplicationIcon(ai), 122, 70, 120);
                } catch (PackageManager.NameNotFoundException ex) {
                    result = bindGridTile(convert, pkg,
                            getDrawable(android.R.drawable.ic_menu_help), 122, 70, 120);
                }
                result.setTag(key);
                return result;
            }
        });
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                showFavoriteActions(visible.get(pos), pos);
            }
        });
        int screenHeightDp = (int) (getResources().getDisplayMetrics().heightPixels /
                getResources().getDisplayMetrics().density);
        int rows = Math.max(1, (visible.size() + 3) / 4);
        int gridHeight = Math.min(rows * 132, Math.max(132, screenHeightDp - 295));
        body.addView(grid, new LinearLayout.LayoutParams(-1, dp(gridHeight)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, dp(54));
        actionLp.topMargin = dp(16);
        body.addView(actions, actionLp);

        TextView add = actionButton("+ Alkalmazás hozzáadása");
        actions.addView(add, new LinearLayout.LayoutParams(0, -1, 1f));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showPicker(); }
        });
        editorAddButton = add;
        add.setId(View.generateViewId());
        grid.setNextFocusDownId(add.getId());

        TextView done = actionButton("Kész");
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(0, -1, 0.40f);
        doneLp.leftMargin = dp(12);
        actions.addView(done, doneLp);
        editorDoneButton = done;
        done.setId(View.generateViewId());
        add.setNextFocusRightId(done.getId());
        done.setNextFocusLeftId(add.getId());
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hideEditor(); }
        });

        TextView footnote = text("Vissza: kilépés a szerkesztésből    •    A módosítások automatikusan mentődnek", 12, 0xAFFFFFFF);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = dp(15);
        body.addView(footnote, footLp);

        editorView = overlay;
        editorGrid = grid;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        grid.post(new Runnable() {
            @Override public void run() {
                if (editorView != overlay) return;
                if (visible.isEmpty()) editorAddButton.requestFocus();
                else {
                    grid.setSelection(Math.min(focusPosition, visible.size() - 1));
                    grid.requestFocus();
                }
            }
        });
    }

    private TextView actionButton(String label) {
        TextView button = text(label, 16, 0xFFFFFFFF);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(14), dp(5), dp(14), dp(5));
        button.setFocusable(true);
        button.setClickable(true);
        // V5.1: a szerkeszto gombjainal se hozzunk letre hatteret
        // minden egyes taviranyito fokuszvaltasnal.
        button.setBackground(ultraActionSelector(15));
        button.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focused) {
                ((TextView) v).setTypeface(focused
                        ? android.graphics.Typeface.DEFAULT_BOLD
                        : android.graphics.Typeface.DEFAULT);
                v.animate().cancel();
                v.animate().scaleX(focused ? 1.045f : 1f)
                        .scaleY(focused ? 1.055f : 1f)
                        .setDuration(195L).setInterpolator(tvEase).start();
            }
        });
        return button;
    }

    private void showFavoriteActions(final String pkg, final int visibleIndex) {
        final PackageManager pm = getPackageManager();
        String label = pkg;
        try { label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (PackageManager.NameNotFoundException ignored) { }
        final String[] options = { "Balra mozgatás", "Jobbra mozgatás", "Eltávolítás a kedvencekből" };
        showLightweightMenu(label, options, new MenuAction() {
            @Override public void onSelected(int which) {
                int idx = favoritePackages.indexOf(pkg);
                if (idx < 0) return;
                if (which == 0 && idx > 0) {
                    Collections.swap(favoritePackages, idx, idx - 1);
                    saveFavorites(); showEditor(Math.max(0, visibleIndex - 1));
                } else if (which == 1 && idx < favoritePackages.size() - 1) {
                    Collections.swap(favoritePackages, idx, idx + 1);
                    saveFavorites(); showEditor(visibleIndex + 1);
                } else if (which == 2) {
                    favoritePackages.remove(idx);
                    saveFavorites(); showEditor(Math.max(0, visibleIndex - 1));
                } else {
                    Toast.makeText(MainActivity.this, "Ebben az irányban már nem mozgatható", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showPicker() {
        if (pickerView != null) return;
        if (favoritePackages.size() >= MAX_FAVS) {
            Toast.makeText(this, "Legfeljebb " + MAX_FAVS + " kedvenc lehet. Előbb távolíts el egyet.", Toast.LENGTH_LONG).show();
            return;
        }
        final PackageManager pm = getPackageManager();
        final List<ResolveInfo> candidates = new ArrayList<>();
        for (ResolveInfo r : availableApps()) {
            if (!favoritePackages.contains(r.activityInfo.packageName)) candidates.add(r);
        }
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xD408111B);
        TextView heading = text("Alkalmazás hozzáadása", 27, 0xFFFFFFFF);
        heading.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        hp.setMargins(dp(48), dp(26), 0, 0);
        overlay.addView(heading, hp);
        TextView hint = text("OK: hozzáadás    •    Vissza: szerkesztés", 13, 0xCFFFFFFF);
        FrameLayout.LayoutParams hintP = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        hintP.setMargins(0, dp(37), dp(48), 0);
        overlay.addView(hint, hintP);
        final GridView grid = new GridView(this);
        grid.setNumColumns(6);
        grid.setHorizontalSpacing(dp(12));
        grid.setVerticalSpacing(dp(12));
        grid.setPadding(dp(48), dp(94), dp(48), dp(30));
        grid.setClipToPadding(false);
        grid.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        grid.setFocusable(true);
        grid.setClickable(true);
        grid.setSelector(rounded(0x55FFFFFF, 20, 0xFFFFFFFF, 2));
        grid.setDrawSelectorOnTop(true);
        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return candidates.size(); }
            @Override public Object getItem(int p) { return candidates.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View old, ViewGroup parent) {
                ResolveInfo ri = candidates.get(p);
                String key = "picker:" + ri.activityInfo.packageName + "/" + ri.activityInfo.name;
                if (old != null && key.equals(old.getTag())) return old;
                View result = bindGridTile(old, ri.loadLabel(pm), ri.loadIcon(pm), 120, 62, 114);
                result.setTag(key);
                return result;
            }
        });
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                String pkg = candidates.get(position).activityInfo.packageName;
                if (favoritePackages.size() >= MAX_FAVS) {
                    Toast.makeText(MainActivity.this, "Megtelt a dokk", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!favoritePackages.contains(pkg)) {
                    favoritePackages.add(pkg);
                    saveFavorites();
                    hidePicker();
                    showEditor(favoritePackages.size() - 1);
                    Toast.makeText(MainActivity.this, "Hozzáadva a kedvencekhez", Toast.LENGTH_SHORT).show();
                }
            }
        });
        overlay.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        heading.bringToFront();
        hint.bringToFront();
        pickerView = overlay;
        pickerGrid = grid;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        grid.post(new Runnable() {
            @Override public void run() {
                if (pickerView == overlay && !candidates.isEmpty()) {
                    grid.setSelection(0);
                    grid.requestFocus();
                }
            }
        });
        if (candidates.isEmpty()) Toast.makeText(this, "Nincs további hozzáadható alkalmazás", Toast.LENGTH_LONG).show();
    }

    /**
     * V5.2: menu bezarasakor az adapter es a csempek ikon Drawable
     * referenciainak azonnali elengedese. Nem hivunk System.gc()-t:
     * a RAM felszabaditasanak idoziteserol az Android dont.
     */
    private void releaseMenu(View overlay, GridView grid) {
        // Elobb valasszuk le az ablakot, hogy a GridView tisztitasa
        // kozben ne ugorjon a fokusz a hatterben levo dokkra.
        if (overlay != null) root.removeView(overlay);
        if (grid != null) {
            grid.setOnItemClickListener(null);
            // Az adapter kozvetve az osszes ResolveInfo-t / kedvenc listat foghatja.
            // setAdapter(null) a GridView ujrahasznositott csempeit is elengedi.
            grid.setAdapter(null);
        }
        if (overlay instanceof ViewGroup) ((ViewGroup) overlay).removeAllViews();
    }

    private void hidePicker() {
        if (pickerView == null) return;
        releaseMenu(pickerView, pickerGrid);
        pickerGrid = null;
        pickerView = null;
        if (editorAddButton != null && editorView != null) editorAddButton.requestFocus();
    }

    private void hideEditor() {
        hidePicker();
        if (editorView == null) return;
        releaseMenu(editorView, editorGrid);
        editorView = null;
        editorGrid = null;
        editorAddButton = null;
        editorDoneButton = null;
        focusFirstDockItem();
    }

    // 9.0.8: az appracs normal GridView. A kijeloles feher fenykeretet
    // maga a konnyu 16:9 appkartya rajzolja, nem a korabbi teljes GridView-re
    // rakott, bitmapbol keszulo SoftEdgeGlowDrawable.

    // ---------- V6.1: tvOS-szeru hatoszlopo, teljes kepernyos appracs ----------
    private void updateGridCellFocus(View cell, boolean selected) {
        if (!(cell instanceof LinearLayout)) return;
        LinearLayout wrapper = (LinearLayout) cell;
        if (wrapper.getChildCount() < 2 || !(wrapper.getChildAt(0) instanceof FrameLayout)
                || !(wrapper.getChildAt(1) instanceof TextView)) return;
        FrameLayout card = (FrameLayout) wrapper.getChildAt(0);
        TextView label = (TextView) wrapper.getChildAt(1);
        boolean changed = card.isSelected() != selected;
        if (!changed) {
            if (selected && label.getVisibility() != View.VISIBLE) {
                label.setVisibility(View.VISIBLE);
                label.setAlpha(1f);
            }
            return;
        }
        card.setSelected(selected);
        // Ugyanaz a feher, halvanyan csillogo overlay, mint a Codex-dokkban.
        // Nincs tobbe blur, bitmapgyartas, SoftEdgeGlow vagy tulrajzolas.
        if (card.getChildCount() > 1) {
            View shine = card.getChildAt(1);
            shine.animate().cancel();
            shine.animate().alpha(selected ? 1f : 0f).setDuration(150L).start();
        }
        label.animate().cancel();
        if (selected) {
            label.setVisibility(View.VISIBLE);
            label.setAlpha(0f);
            label.animate().alpha(1f).setStartDelay(30L)
                    .setInterpolator(tvEase).setDuration(FOCUS_MS).start();
        } else {
            label.animate().alpha(0f).setDuration(105L)
                    .withEndAction(new Runnable() {
                        @Override public void run() {
                            if (!card.isSelected()) label.setVisibility(View.INVISIBLE);
                        }
                    }).start();
        }
    }

    /** A fokusz-keret nem maradhat meg, ha kimegyunk az appracsbol.
     * A korabbi megoldas minden lekerdezesnel ujrainditotta a skalaanimaciot.
     */
    private void refreshVisibleGridFocus(GridView grid) {
        if (grid == null) return;
        int selected = (gridMode && grid.hasFocus())
                ? grid.getSelectedItemPosition() : -1;
        int first = grid.getFirstVisiblePosition();
        for (int childIndex = 0; childIndex < grid.getChildCount(); childIndex++) {
            View child = grid.getChildAt(childIndex);
            boolean active = first + childIndex == selected;
            updateGridCellFocus(child, active);
            if (child.isActivated() != active) {
                child.setActivated(active);
                child.animate().cancel();
                // A Codex-dokk egyszeru skala + Z-kiemeles animacioja.
                child.animate().scaleX(active ? 1.12f : 1f)
                        .scaleY(active ? 1.12f : 1f)
                        .translationZ(active ? dp(12) : 0f)
                        .rotation(0f)
                        .setInterpolator(active
                                ? new android.view.animation.OvershootInterpolator(1.65f)
                                : tvEase)
                        .setDuration(active ? 265L : 175L).start();
            }
        }
    }

    // Egyetlen, konnyu ValueAnimator a teljes fokepernyo gorgetesehez.
    // A fokusz nem lep ki a GridView-bol, nem jon letre uj Android ablak.
    private void animateHomeScrollTo(int requestedY, long durationMs) {
        if (homeScroll == null || homeColumn == null) {
            enteringAppGrid = false;
            return;
        }
        if (homeScrollAnimator != null) {
            homeScrollAnimator.cancel();
            homeScrollAnimator = null;
        }
        int maximum = Math.max(0, homeColumn.getHeight() - homeScroll.getHeight());
        int target = Math.max(0, Math.min(maximum, requestedY));
        int from = homeScroll.getScrollY();
        if (from == target) {
            enteringAppGrid = false;
            return;
        }
        final ValueAnimator animator = ValueAnimator.ofInt(from, target);
        homeScrollAnimator = animator;
        animator.setDuration(durationMs);
        animator.setInterpolator(tvEase);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator current) {
                if (homeScroll != null && homeScrollAnimator == current)
                    homeScroll.scrollTo(0, (Integer) current.getAnimatedValue());
            }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (homeScrollAnimator == animation) {
                    homeScrollAnimator = null;
                    enteringAppGrid = false;
                }
            }
        });
        animator.start();
    }

    /**
     * Codex/Imcsikee TV Home: az elso racssor megjelenesekor a dokksav
     * 22 dp tavolsagra csuszik a kijelzo tetejetol, NEM tunik el teljesen.
     * A szamitas a tenyleges, felmeretett dokk poziciojat hasznalja.
     */
    private int codexDockAnchorY() {
        if (dock == null || homeTop == null || !(dock.getParent() instanceof View))
            return homeTop == null ? 0 : homeTop.getHeight();
        View dockGroup = (View) dock.getParent();
        return Math.max(0, homeTop.getTop() + dockGroup.getTop()
                + dock.getTop() - dp(22));
    }

    /**
     * Ha csak 1-2 alkalmazas van, a ScrollView alapbol nem engedne eljutni
     * a dokk felsore igazitasahoz. Csak a racs alatti ures reszt boviti,
     * nem rajzol tovabbi elemeket es nem valtoztatja az alkalmazasok meretet.
     */
    private void ensureCodexGridScrollRoom() {
        if (allView == null || homeTop == null || homeScroll == null) return;
        int viewport = homeScroll.getHeight();
        if (viewport <= 0) viewport = getResources().getDisplayMetrics().heightPixels;
        int heroHeight = homeTop.getHeight();
        if (heroHeight <= 0) heroHeight = getResources().getDisplayMetrics().heightPixels;
        int minimum = Math.max(0, viewport + codexDockAnchorY()
                - heroHeight + dp(12));
        if (allView.getMinimumHeight() != minimum) allView.setMinimumHeight(minimum);
    }

    /**
     * Codex: sotetedes a hatterkep felett es az aktualis appcim halkulasa.
     * A dokk es az alkalmazasracs a sotetites FELETT van, kontrasztos marad.
     */
    private void animateCodexGridScene(boolean entering) {
        long duration = Math.max(235L, SCROLL_MS);
        if (appGridShade != null) {
            appGridShade.animate().cancel();
            appGridShade.animate().alpha(entering ? 1f : 0f)
                    .setInterpolator(tvEase).setDuration(duration).start();
        }
        if (selectedDockLabel != null) {
            selectedDockLabel.animate().cancel();
            selectedDockLabel.animate().alpha(entering ? 0f : 1f)
                    .setInterpolator(tvEase).setDuration(duration).start();
        }
    }

    private void revealAppGrid() {
        if (allGrid == null) return;
        allGrid.animate().cancel();
        allGrid.setAlpha(0.45f);
        allGrid.setTranslationY(dp(26));
        allGrid.animate().alpha(1f).translationY(0f)
                .setDuration(Math.max(255L, PANEL_MS)).setInterpolator(tvEase).start();
    }

    private void showAll() {
        closeSettingsDropdown();
        ensureAppOrder();
        gridMode = true;
        if (allView != null) {
            ensureCodexGridScrollRoom();
            focusGridAndScroll(gridFocusIndexOnOpen);
            gridFocusIndexOnOpen = 0;
            return;
        }
        bannerCache.clear();
        final PackageManager pm = getPackageManager();
        // Az appok a fokepernyo alatti, gorgetheto tartalom reszei.
        final FrameLayout overlay = new FrameLayout(this);
        // Nincs tobbe sotetszurke nagy panel az appracs mogott:
        // a fokepernyo eredeti hatterkepe teljesen latszik.
        overlay.setBackgroundColor(0x00000000);
        overlay.setClipChildren(false);
        // Az also appracs a dokk csempeinek PONTOS meretet hasznalja.
        // Az otos sor kozepre igazodik, a kisebb sorok is kozepen maradnak.
        final int appCount = Math.max(0, appOrder.size() - dockSlots);
        gridVisibleColumns = Math.max(1, Math.min(GRID_COLUMNS, appCount));
        int cardWidthDp = currentDockCardWidthDp();
        appGridCardHeightDp = Math.max(56, Math.round(cardWidthDp * 9f / 16f));
        appGridRowHeightDp = appGridCardHeightDp + 39;
        gridContentWidthDp = gridVisibleColumns * cardWidthDp
                + (gridVisibleColumns - 1) * GRID_CARD_GAP_DP
                + 2 * GRID_SIDE_INSET_DP;
        // NINCS osszes alkalmazas cim, nincs egybefuggo hatterpanel.

        // Ugyanaz az alacsony tulrajzolasu komponens, mint a 9.0.6-os dokkban.
        final GridView grid = new GridView(this);
        grid.setNumColumns(gridVisibleColumns);
        grid.setHorizontalSpacing(dp(GRID_CARD_GAP_DP));
        grid.setVerticalSpacing(dp(GRID_ROW_GAP_DP));
        grid.setClipChildren(false);
        grid.setPadding(dp(GRID_SIDE_INSET_DP), dp(GRID_TOP_PADDING_DP),
                dp(GRID_SIDE_INSET_DP), dp(GRID_BOTTOM_PADDING_DP));
        grid.setClipToPadding(false);
        grid.setVerticalScrollBarEnabled(false);
        grid.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        grid.setFocusable(true);
        grid.setClickable(true);
        grid.setSelector(new ColorDrawable(0x00000000));
        grid.setDrawSelectorOnTop(false);
        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() {
                return Math.max(0, appOrder.size() - dockSlots);
            }
            @Override public Object getItem(int position) {
                int idx = position + dockSlots;
                return idx >= appOrder.size() ? null : appOrder.get(idx);
            }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View recycled, ViewGroup parent) {
                String pkg = appOrder.get(position + dockSlots);
                // GridView may rebind the same visible app on every layout/focus pass.
                // Its tile is already populated: avoid repeated PackageManager icon/banner
                // queries and Drawable inflation on the UI thread.
                if (recycled instanceof LinearLayout && pkg.equals(recycled.getTag())) {
                    updateGridCellFocus(recycled, gridMode && allGrid != null
                            && allGrid.hasFocus()
                            && allGrid.getSelectedItemPosition() == position);
                    return recycled;
                }
                Drawable banner = bannerFor(pkg);
                Drawable icon = null;
                if (banner == null) {
                    try { icon = pm.getApplicationIcon(pkg); }
                    catch (Exception e) { icon = getDrawable(android.R.drawable.sym_def_app_icon); }
                }
                LinearLayout wrapper;
                FrameLayout card;
                ImageView image;
                TextView label;
                if (recycled instanceof LinearLayout
                        && ((LinearLayout) recycled).getChildCount() == 2
                        && ((LinearLayout) recycled).getChildAt(0) instanceof FrameLayout
                        && ((LinearLayout) recycled).getChildAt(1) instanceof TextView) {
                    wrapper = (LinearLayout) recycled;
                    card = (FrameLayout) wrapper.getChildAt(0);
                    image = (ImageView) card.getChildAt(0);
                    label = (TextView) wrapper.getChildAt(1);
                } else {
                    wrapper = new LinearLayout(MainActivity.this);
                    wrapper.setOrientation(LinearLayout.VERTICAL);
                    wrapper.setGravity(Gravity.CENTER_HORIZONTAL);
                    wrapper.setClipChildren(false);
                    wrapper.setClipToPadding(false);
                    wrapper.setLayoutParams(new AbsListView.LayoutParams(
                            -1, dp(appGridRowHeightDp)));
                    // Kozos konnyu 16:9 kartya a dokkal: 1 hatter, 1 kep,
                    // 1 feher keret. Nincs per-kartya UltraGlass/blur/reflection.
                    card = (FrameLayout) makeAppleCard(appTitle(pkg), icon, banner,
                            cardWidthDp, appGridCardHeightDp, false, null);
                    image = (ImageView) card.getChildAt(0);
                    wrapper.addView(card, new LinearLayout.LayoutParams(
                            -1, dp(appGridCardHeightDp)));
                    label = text("", 13, 0xFFFFFFFF);
                    label.setSingleLine(true);
                    label.setEllipsize(TextUtils.TruncateAt.END);
                    label.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                    LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(-1, dp(30));
                    textLp.topMargin = dp(8);
                    wrapper.addView(label, textLp);
                }
                image.setImageDrawable(banner != null ? banner : icon);
                image.setScaleType(banner != null
                        ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
                // A Codex-dokk ikon-paddingje; margin-LayoutParams ujraallas
                // nelkul kevesebb meretezesi/layout munkaval.
                int padX = banner == null ? dp(20) : 0;
                int padY = banner == null ? dp(12) : 0;
                if (image.getPaddingLeft() != padX || image.getPaddingTop() != padY)
                    image.setPadding(padX, padY, padX, padY);
                label.setText(appTitle(pkg));
                Object oldPkg = wrapper.getTag();
                if (!(oldPkg instanceof String) || !pkg.equals(oldPkg)) {
                    wrapper.animate().cancel();
                    wrapper.setScaleX(1f); wrapper.setScaleY(1f);
                    wrapper.setTranslationZ(0f);
                    wrapper.setAlpha(1f); wrapper.setTranslationX(0f);
                    wrapper.setActivated(false);
                    // Recycler: a reginek a kijelolese ne ragadjon rajta
                    // a kovetkezo alkalmazason.
                    card.setSelected(false);
                    if (card.getChildCount() > 1) {
                        View shine = card.getChildAt(1);
                        shine.animate().cancel();
                        shine.setAlpha(0f);
                    }
                    label.animate().cancel();
                    label.setAlpha(0f);
                    label.setVisibility(View.INVISIBLE);
                }
                wrapper.setTag(pkg);
                wrapper.setContentDescription(appTitle(pkg));
                updateGridCellFocus(wrapper, gridMode && grid.hasFocus()
                        && grid.getSelectedItemPosition() == position);
                return wrapper;
            }
        });
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view,
                                              int position, long id) {
                int idx = position + dockSlots;
                if (idx < appOrder.size()) launchFavoritePackage(appOrder.get(idx));
            }
        });
        grid.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focused) {
                // Entering/leaving the grid must always reveal/clear its border.
                refreshVisibleGridFocus(grid);
                if (focused) grid.post(new Runnable() {
                    @Override public void run() {
                        if (allGrid == grid && grid.hasFocus())
                            refreshVisibleGridFocus(grid);
                    }
                });
            }
        });
        grid.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view,
                                                 int position, long id) {
                previousGridSelection = position;
                refreshVisibleGridFocus(grid);
                // Adapter views may be recycled a frame after the selection changes.
                grid.post(new Runnable() {
                    @Override public void run() {
                        if (allGrid == grid) refreshVisibleGridFocus(grid);
                    }
                });
                if (gridMode && grid.hasFocus() && view != null && !enteringAppGrid)
                    scrollToGridCell(view);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {
                previousGridSelection = -1;
                refreshVisibleGridFocus(grid);
            }
        });
        FrameLayout.LayoutParams gridLp = new FrameLayout.LayoutParams(
                dp(gridContentWidthDp), dp(appGridTotalHeightDp()),
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        overlay.addView(grid, gridLp);
        allView = overlay;
        allGrid = grid;
        previousGridSelection = -1;
        homeColumn.addView(overlay, new LinearLayout.LayoutParams(-1, -2));
        ensureCodexGridScrollRoom();
        final int initial = gridFocusIndexOnOpen;
        gridFocusIndexOnOpen = 0;
        focusGridAndScroll(initial);
    }

    private void focusGridAndScroll(final int requested) {
        if (allGrid == null) return;
        final GridView grid = allGrid;
        final boolean gridHadFocus = grid.hasFocus();
        enteringAppGrid = true;  // az onItemSelected ne inditson masik gorgetest
        grid.post(new Runnable() {
            @Override public void run() {
                if (gridMode && allGrid == grid && grid.getCount() > 0) {
                    int index = Math.min(Math.max(0, requested), grid.getCount() - 1);
                    grid.setSelection(index);
                    grid.requestFocus();
                    // A Codex eredeti, egybefuggo home->all-apps effektje:
                    // a dokk a racs felett a kijelzo TETEJERE csuszik,
                    // a hatter sotetedik, az appok finoman felemelkednek.
                    ensureCodexGridScrollRoom();
                    animateCodexGridScene(true);
                    // Az uj minimum magassag utan egy layout ciklust hagyunk,
                    // hogy keves alkalmazasnal se alljon meg feluton a scroll.
                    homeColumn.post(new Runnable() {
                        @Override public void run() {
                            if (gridMode && allGrid == grid) {
                                animateHomeScrollTo(codexDockAnchorY(),
                                        Math.max(285L, SCROLL_MS));
                            }
                        }
                    });
                    if (!gridHadFocus) revealAppGrid();
                } else if (gridMode && grid.getCount() == 0) {
                    enteringAppGrid = false;
                    Toast.makeText(MainActivity.this, "Nincs további alkalmazás",
                            Toast.LENGTH_SHORT).show();
                    hideAll();
                } else {
                    enteringAppGrid = false;
                }
            }
        });
    }

    private void scrollToGridCell(View cell) {
        if (homeScroll == null || homeTop == null || allGrid == null) return;
        // Codex: az elso sorban a dokk fennmarad; tovabbi soroknal
        // a valasztott kartya a kepernyo kozepe kozelebe gorgetodik.
        int selected = Math.max(0, allGrid.getSelectedItemPosition());
        int columns = Math.max(1, gridVisibleColumns);
        int desired = selected < columns
                ? codexDockAnchorY()
                : homeTop.getHeight() + allGrid.getTop() + cell.getTop()
                    - Math.round(homeScroll.getHeight() * 0.42f);
        animateHomeScrollTo(Math.max(0, desired), 185L);
    }

    /** Ugyanazt a tenyleges meretet olvassuk, amit a dokk View hasznal.
     * Igy mas kepernyosurususeg es app-elrendezes mellett sincs nagyobb racs.
     */
    private int currentDockCardWidthDp() {
        if (dock != null && dock.getChildCount() > 0) {
            ViewGroup.LayoutParams params = dock.getChildAt(0).getLayoutParams();
            if (params != null && params.width > 0)
                return Math.round(params.width / getResources().getDisplayMetrics().density);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenDp = (int) (dm.widthPixels / dm.density);
        int count = Math.max(1, favoritePackages.size());
        return Math.min(150, Math.max(85, (screenDp - 88) / count - 6));
    }

    private int appGridTotalHeightDp() {
        int n = Math.max(1, (Math.max(0, appOrder.size() - dockSlots)
                + gridVisibleColumns - 1) / gridVisibleColumns);
        return GRID_TOP_PADDING_DP + n * appGridRowHeightDp
                + Math.max(0, n - 1) * GRID_ROW_GAP_DP + GRID_BOTTOM_PADDING_DP;
    }

    private void updateAllGridHeight() {
        if (allGrid == null) return;
        int columns = Math.max(1, Math.min(GRID_COLUMNS, allGrid.getCount()));
        gridVisibleColumns = columns;
        int cardWidthDp = currentDockCardWidthDp();
        appGridCardHeightDp = Math.max(56, Math.round(cardWidthDp * 9f / 16f));
        appGridRowHeightDp = appGridCardHeightDp + 39;
        gridContentWidthDp = columns * cardWidthDp
                + (columns - 1) * GRID_CARD_GAP_DP + 2 * GRID_SIDE_INSET_DP;
        allGrid.setNumColumns(columns);
        ViewGroup.LayoutParams gridLp = allGrid.getLayoutParams();
        if (gridLp != null) {
            gridLp.width = dp(gridContentWidthDp);
            gridLp.height = dp(appGridTotalHeightDp());
            allGrid.setLayoutParams(gridLp);
        }
    }

    private void hideAll() {
        // Csak a fokusz/gorgetes valtozik; a racs tenyleg az oldal resze marad.
        enteringAppGrid = false;
        gridMode = false;
        if (allGrid != null) refreshVisibleGridFocus(allGrid);
        animateCodexGridScene(false);
        if (dock != null && dock.getChildCount() > 0) {
            int i = Math.max(0, Math.min(lastFocusedDockIndex, dock.getChildCount() - 1));
            dock.getChildAt(i).requestFocus();
        }
        if (homeScroll != null) animateHomeScrollTo(0, SCROLL_MS);
    }

    private Intent launchIntent(PackageManager pm, String packageName) {
        Intent in = pm.getLeanbackLaunchIntentForPackage(packageName);
        return in != null ? in : pm.getLaunchIntentForPackage(packageName);
    }

    private void launch(Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(intent);
        } catch (Exception ex) {
            Log.e(TAG, "Nem sikerult inditani: " + intent, ex);
            Toast.makeText(this, "Az alkalmazás nem indítható", Toast.LENGTH_SHORT).show();
        }
    }

    private String phoneUploadHtml() {
        return "<!doctype html>\n"
                + "<html lang=\"hu\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">\n"
                + "<title>TVHome · Képek küldése</title>\n"
                + "<style>\n"
                + "*{box-sizing:border-box}body{margin:0;padding:24px 16px;font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;background:radial-gradient(ellipse at 20% -15%,#2b526d,#09121c 67%);color:white;min-height:100vh}\n"
                + "main{max-width:500px;margin:6vh auto;padding:30px 23px;border-radius:30px;border:1px solid #8fb6cf70;background:linear-gradient(135deg,#e0f5ff2e,#91b0d015 58%,#0815219c);box-shadow:0 15px 55px #0007;backdrop-filter:blur(22px)}\n"
                + "h1{font-size:30px;font-weight:620;margin:0 0 9px}p{color:#d4e5f0;line-height:1.45}label{display:block;margin:19px 0 7px;font-weight:600}\n"
                + "input[type=tel],input[type=file]{width:100%;padding:14px;border:1px solid #ffffff68;border-radius:15px;background:#ffffff16;color:white;font-size:18px}\n"
                + "input[type=file]{font-size:15px}input::file-selector-button{border:none;border-radius:10px;background:#d7edff;color:#173247;padding:10px}\n"
                + "button{margin-top:24px;width:100%;padding:16px;border:1px solid white;border-radius:17px;background:linear-gradient(#d8f1ff,#89bce8);font-size:18px;font-weight:700;color:#0c2e46}\n"
                + "button:disabled{opacity:.55}#status{padding:14px 0;white-space:pre-wrap;line-height:1.5}.tiny{font-size:13px;opacity:.8}\n"
                + "</style></head><body><main><h1>📺 TVHome</h1><p>Háttérképek küldése közvetlenül a tévére – felhő és számítógép nélkül.</p>\n"
                + "<label for=\"pin\">A tévén látható 6 számjegyű kód</label><input id=\"pin\" type=\"tel\" maxlength=\"6\" inputmode=\"numeric\" placeholder=\"123456\" autocomplete=\"one-time-code\">\n"
                + "<label for=\"photos\">Fotók kiválasztása (max. 20 kép)</label><input id=\"photos\" type=\"file\" accept=\"image/*\" multiple>\n"
                + "<button id=\"send\" type=\"button\">Képek küldése</button><div id=\"status\" aria-live=\"polite\"></div>\n"
                + "<p class=\"tiny\">Mindkét eszköz legyen ugyanazon a Wi-Fi/hálózaton. A feltöltés a TV-n a Bezárás gombbal leállítható. A böngésző a támogatott fotókat JPEG formátumra alakítja.</p></main>\n"
                + "<script>\n"
                + "const $=id=>document.getElementById(id),send=$('send');\n"
                + "const tell=s=>{$('status').textContent=s};\n"
                + "function loadImage(f){return new Promise((resolve,reject)=>{let img=new Image();let u=URL.createObjectURL(f);img.onload=()=>{URL.revokeObjectURL(u);resolve(img)};img.onerror=()=>{URL.revokeObjectURL(u);reject(new Error('Ezt a képformátumot a böngésző nem tudja megnyitni.'))};img.src=u})}\n"
                + "async function jpeg(f){let img=await loadImage(f);let scale=Math.min(1,2560/Math.max(img.naturalWidth,img.naturalHeight));let c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));let ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);return await new Promise((resolve,reject)=>c.toBlob(blob=>blob?resolve(blob):reject(new Error('A kép átalakítása sikertelen.')),'image/jpeg',.88))}\n"
                + "send.onclick=async()=>{let pin=$('pin').value.trim(),fs=[...$('photos').files];if(!/^\\d{6}$/.test(pin)){tell('Írd be a tévén látható 6 számjegyű kódot.');return}if(!fs.length||fs.length>20){tell('Válassz 1–20 képet.');return}send.disabled=true;let count=0;try{for(let f of fs){tell('Küldés: '+(count+1)+'/'+fs.length+' – '+f.name);let body=await jpeg(f);if(body.size>16000000)throw Error('A kép túl nagy.');let r=await fetch('/upload',{method:'POST',headers:{'Content-Type':'image/jpeg','X-TVHome-Code':pin},body});let data=await r.json();if(!r.ok||!data.ok)throw Error(data.error||'A tévé nem fogadta a képet.');count++;tell(count+'/'+fs.length+' kép elküldve ✓')}tell('Kész! '+count+' kép megérkezett. A TVHome galériájában már láthatók.')}catch(e){tell('Hiba: '+e.message+'\\nSikeresen elküldve: '+count+' kép.')}finally{send.disabled=false}};\n"
                + "</script></body></html>\n";
    }

    // ---------- TVHome 7.4 – Android/iPhone bongeszo -> TV via local Wi-Fi ----------
    // The temporary HTTP endpoint only exists while this screen is open.
    private void showPhoneUpload() {
        if (!running || root == null || phoneUploadOverlay != null) return;
        String ip = phoneUploadLocalIp();
        if (ip == null) {
            Toast.makeText(this,
                    "Nem találok helyi IP-címet. Csatlakoztasd a TV-t a hálózathoz.",
                    Toast.LENGTH_LONG).show();
            showWallpaperMenu();
            return;
        }
        final String address = "http://" + ip + ":" + PHONE_UPLOAD_PORT + "/";
        phoneUploadPin = String.format(Locale.US, "%06d",
                new SecureRandom().nextInt(1000000));
        phoneUploadCounter = 0;

        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xB307101A);
        overlay.setFocusable(true);
        overlay.setClickable(true);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(36), dp(28), dp(36), dp(25));
        panel.setBackground(new UltraGlassDrawable(27, 2));
        panel.setElevation(dp(26));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                dp(750), -2, Gravity.CENTER);
        overlay.addView(panel, pp);

        TextView heading = text("Képek küldése telefonról", 29, 0xFFFFFFFF);
        heading.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        panel.addView(heading, new LinearLayout.LayoutParams(-1, dp(50)));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(-1, -2);
        contentLp.topMargin = dp(12);
        panel.addView(content, contentLp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infop = new LinearLayout.LayoutParams(0, -2, 1f);
        infop.rightMargin = dp(18);
        content.addView(info, infop);

        TextView step = text("1. iPhone vagy Android: olvasd be a QR-kódot.\n"
                + "2. Safariban vagy Chrome-ban add meg a kódot.\n"
                + "3. Válaszd ki a fotókat, majd küldd el.", 17, 0xECFFFFFF);
        step.setLineSpacing(dp(8), 1f);
        info.addView(step);

        TextView codeLabel = text("PÁROSÍTÁSI KÓD", 14, 0xC5FFFFFF);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.topMargin = dp(20);
        info.addView(codeLabel, clp);
        TextView codeText = text(phoneUploadPin, 43, 0xFFFFFFFF);
        codeText.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        info.addView(codeText);

        TextView urlLabel = text(address, 16, 0xFFE2F4FF);
        urlLabel.setSingleLine(true);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(-1, -2);
        ulp.topMargin = dp(7);
        info.addView(urlLabel, ulp);

        ImageView qr = new ImageView(this);
        qr.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qr.setBackground(rounded(0xFFFFFFFF, 16, 0x40FFFFFF, 1));
        qr.setPadding(dp(9), dp(9), dp(9), dp(9));
        content.addView(qr, new LinearLayout.LayoutParams(dp(216), dp(216)));
        phoneUploadQr = qr;
        try {
            java.util.Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.MARGIN, 1);
            BitMatrix bits = new QRCodeWriter().encode(address,
                    BarcodeFormat.QR_CODE, 320, 320, hints);
            Bitmap qrBitmap = Bitmap.createBitmap(320, 320, Bitmap.Config.RGB_565);
            int[] pixels = new int[320 * 320];
            for (int y = 0; y < 320; y++) {
                for (int x = 0; x < 320; x++)
                    pixels[y * 320 + x] = bits.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
            }
            qrBitmap.setPixels(pixels, 0, 320, 0, 0, 320, 320);
            qr.setImageBitmap(qrBitmap);
        } catch (Exception error) {
            Log.w(TAG, "QR-kod nem keszult el, a cim kezzel is beirhato", error);
            qr.setVisibility(View.GONE);
        }

        TextView status = text("Feltöltőszerver indítása…", 15, 0xFFD7EDFF);
        status.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, dp(41));
        stp.topMargin = dp(13);
        panel.addView(status, stp);
        phoneUploadStatus = status;

        TextView close = actionButton("Bezárás – feltöltés leállítása");
        panel.addView(close, new LinearLayout.LayoutParams(-1, dp(52)));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopPhoneUpload(false);
                showWallpaperMenu();
            }
        });
        phoneUploadOverlay = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setAlpha(0f);
        overlay.animate().alpha(1f).setDuration(180L).start();
        close.requestFocus();
        startPhoneUploadServer();
    }

    private String phoneUploadLocalIp() {
        try {
            String fallback = null;
            Enumeration<NetworkInterface> network = NetworkInterface.getNetworkInterfaces();
            while (network != null && network.hasMoreElements()) {
                NetworkInterface iface = network.nextElement();
                if (!iface.isUp() || iface.isLoopback()) continue;
                String displayName = iface.getName().toLowerCase(Locale.ROOT);
                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress ip = addresses.nextElement();
                    if (!(ip instanceof Inet4Address) || !ip.isSiteLocalAddress()) continue;
                    String value = ip.getHostAddress();
                    if (displayName.startsWith("wlan") || displayName.startsWith("eth"))
                        return value;
                    if (fallback == null) fallback = value;
                }
            }
            return fallback;
        } catch (Exception ex) {
            Log.w(TAG, "Nem sikerult IP-cimet lekerni", ex);
            return null;
        }
    }

    private void phoneUploadFeedback(final String msg) {
        mainHandler.post(new Runnable() {
            @Override public void run() {
                if (phoneUploadActive && phoneUploadStatus != null)
                    phoneUploadStatus.setText(msg);
            }
        });
    }

    private void startPhoneUploadServer() {
        phoneUploadActive = true;
        final int session = ++phoneUploadGeneration;
        phoneUploadThread = new Thread(new Runnable() {
            @Override public void run() {
                ServerSocket listener = null;
                try {
                    listener = new ServerSocket();
                    listener.setReuseAddress(true);
                    listener.bind(new InetSocketAddress(PHONE_UPLOAD_PORT));
                    listener.setSoTimeout(1200);
                    if (!phoneUploadActive || session != phoneUploadGeneration) return;
                    phoneUploadSocket = listener;
                    phoneUploadFeedback("Készen áll. A telefonon nyisd meg a fenti címet.");
                    while (phoneUploadActive && session == phoneUploadGeneration) {
                        try {
                            Socket client = listener.accept();
                            phoneUploadClient = client;
                            try {
                                client.setSoTimeout(35000);
                                servePhoneUploadClient(client);
                            } finally {
                                phoneUploadClient = null;
                                try { client.close(); } catch (Exception ignored) { }
                            }
                        } catch (java.net.SocketTimeoutException ignored) {
                            // Wake regularly to honor stop requests.
                        } catch (IOException ex) {
                            if (phoneUploadActive) Log.w(TAG, "Telefonos csatlakozas megszakadt", ex);
                        }
                    }
                } catch (Exception ex) {
                    Log.e(TAG, "Nem indul a telefonos feltoltes", ex);
                    phoneUploadFeedback("Hiba: a feltöltőszerver nem indult (" +
                            PHONE_UPLOAD_PORT + "-es port).");
                } finally {
                    try { if (listener != null) listener.close(); }
                    catch (Exception ignored) { }
                    if (phoneUploadSocket == listener) phoneUploadSocket = null;
                }
            }
        }, "TVHome-PhoneUpload");
        phoneUploadThread.setDaemon(true);
        phoneUploadThread.start();
    }

    private void stopPhoneUpload(boolean immediate) {
        phoneUploadActive = false;
        ++phoneUploadGeneration;
        ServerSocket socket = phoneUploadSocket;
        phoneUploadSocket = null;
        if (socket != null) try { socket.close(); } catch (Exception ignored) { }
        Socket client = phoneUploadClient;
        if (client != null) try { client.close(); } catch (Exception ignored) { }
        phoneUploadClient = null;
        phoneUploadPin = null;
        phoneUploadThread = null;
        phoneUploadStatus = null;
        phoneUploadQr = null;
        if (phoneUploadOverlay != null) {
            FrameLayout old = phoneUploadOverlay;
            phoneUploadOverlay = null;
            old.animate().cancel();
            if (old.getParent() == root) root.removeView(old);
        }
    }

    private String phoneUploadReadLine(InputStream in, int maxLength) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') {
                if (out.size() >= maxLength) throw new IOException("HTTP header túl hosszú");
                out.write(c);
            }
        }
        if (c == -1 && out.size() == 0) return null;
        return out.toString("US-ASCII");
    }

    private void phoneUploadResponse(OutputStream raw, int status, String contentType,
                                     byte[] body) throws IOException {
        final String label = status == 200 ? "OK" : status == 401 ? "Unauthorized"
                : status == 413 ? "Payload Too Large" : status == 403 ? "Forbidden"
                : status == 404 ? "Not Found" : "Bad Request";
        String headers = "HTTP/1.1 " + status + " " + label + "\r\n"
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "X-Content-Type-Options: nosniff\r\n"
                + "Connection: close\r\n\r\n";
        raw.write(headers.getBytes(StandardCharsets.US_ASCII));
        raw.write(body);
        raw.flush();
    }

    private byte[] phoneUploadJson(boolean ok, String value) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("ok", ok);
            if (ok) obj.put("name", value);
            else obj.put("error", value);
        } catch (JSONException ignored) { }
        return obj.toString().getBytes(StandardCharsets.UTF_8);
    }

    private void servePhoneUploadClient(Socket socket) throws IOException {
        BufferedInputStream in = new BufferedInputStream(socket.getInputStream());
        BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
        if (!phoneUploadActive) return;
        InetAddress peer = socket.getInetAddress();
        if (peer == null || !(peer.isLoopbackAddress() || peer.isSiteLocalAddress())) {
            phoneUploadResponse(out, 403, "text/plain; charset=utf-8",
                    "Csak helyi hálózatról érhető el".getBytes(StandardCharsets.UTF_8));
            return;
        }
        String request = phoneUploadReadLine(in, 4096);
        if (request == null) return;
        String[] pieces = request.split(" ");
        if (pieces.length < 3) return;
        HashMap<String, String> headers = new HashMap<>();
        for (int h = 0; h < 40; h++) {
            String line = phoneUploadReadLine(in, 8192);
            if (line == null) throw new IOException("Hibas HTTP kereses");
            if (line.isEmpty()) break;
            int sep = line.indexOf(':');
            if (sep > 0)
                headers.put(line.substring(0, sep).trim().toLowerCase(Locale.ROOT),
                        line.substring(sep + 1).trim());
        }
        if ("GET".equals(pieces[0]) && "/".equals(pieces[1])) {
            byte[] html = phoneUploadHtml().getBytes(StandardCharsets.UTF_8);
            phoneUploadResponse(out, 200, "text/html; charset=utf-8", html);
            return;
        }
        if (!"POST".equals(pieces[0]) || !"/upload".equals(pieces[1])) {
            phoneUploadResponse(out, 404, "text/plain", new byte[0]);
            return;
        }
        String expected = phoneUploadPin;
        String supplied = headers.get("x-tvhome-code");
        if (expected == null || supplied == null ||
                !MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                        supplied.getBytes(StandardCharsets.UTF_8))) {
            phoneUploadResponse(out, 401, "application/json; charset=utf-8",
                    phoneUploadJson(false, "Hibás párosítási kód."));
            return;
        }
        long length;
        try { length = Long.parseLong(headers.get("content-length")); }
        catch (Exception ex) { length = -1; }
        if (length < 1 || length > PHONE_UPLOAD_MAX_BYTES) {
            phoneUploadResponse(out, 413, "application/json; charset=utf-8",
                    phoneUploadJson(false, "Túl nagy kép (max. 16 MB)."));
            return;
        }
        String mime = headers.get("content-type");
        if (!"image/jpeg".equalsIgnoreCase(mime)) {
            phoneUploadResponse(out, 400, "application/json; charset=utf-8",
                    phoneUploadJson(false, "A feltöltésnek JPEG képnek kell lennie."));
            return;
        }
        File base = getExternalFilesDir(null);
        if (base == null) {
            phoneUploadResponse(out, 400, "application/json; charset=utf-8",
                    phoneUploadJson(false, "A tévé tárhelye nem érhető el."));
            return;
        }
        File folder = new File(base, "wallpapers");
        if ((!folder.exists() && !folder.mkdirs()) || folder.getUsableSpace() < length * 2) {
            phoneUploadResponse(out, 400, "application/json; charset=utf-8",
                    phoneUploadJson(false, "Nincs elég szabad hely a TV-n."));
            return;
        }
        File part = File.createTempFile("iphone-upload-", ".part", folder);
        boolean success = false;
        try {
            try (FileOutputStream output = new FileOutputStream(part)) {
                byte[] buf = new byte[16384];
                long remaining = length;
                while (remaining > 0 && phoneUploadActive) {
                    int n = in.read(buf, 0, (int) Math.min(buf.length, remaining));
                    if (n < 0) break;
                    output.write(buf, 0, n);
                    remaining -= n;
                }
                if (remaining != 0 || !phoneUploadActive)
                    throw new IOException("A feltoltes megszakadt");
                output.getFD().sync();
            }
            BitmapFactory.Options test = new BitmapFactory.Options();
            test.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(part.getAbsolutePath(), test);
            if (test.outWidth < 200 || test.outHeight < 200 ||
                    test.outWidth > 12000 || test.outHeight > 12000) {
                phoneUploadResponse(out, 400, "application/json; charset=utf-8",
                        phoneUploadJson(false, "Nem olvasható vagy túl nagy felbontású kép."));
                return;
            }
            File file;
            do {
                phoneUploadCounter++;
                file = new File(folder, String.format(Locale.US,
                        "telefon-%d-%03d.jpg", System.currentTimeMillis(), phoneUploadCounter));
            } while (file.exists());
            if (!part.renameTo(file)) throw new IOException("Nem sikerult elmenteni a kepet");
            success = true;
            phoneUploadResponse(out, 200, "application/json; charset=utf-8",
                    phoneUploadJson(true, file.getName()));
            phoneUploadFeedback("Megérkezett: " + phoneUploadCounter + " kép. Küldhetsz többet is.");
        } finally {
            if (!success && part.exists()) part.delete();
        }
    }

    // ---------- Hatterkepek: kizarolag a launcher sajat wallpapers mappajabol ----------

    private void readWallpaperSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        // A kapcsolo mentett allapota fuggetlen a kezzel valasztott keptol.
        autoWallpaper = prefs.getBoolean(PREF_WALLPAPER_AUTO, true);
        int savedInterval = prefs.getInt(PREF_WALLPAPER_INTERVAL, 10);
        wallpaperIntervalMinutes = isSupportedWallpaperInterval(savedInterval) ? savedInterval : 10;
        fixedWallpaper = prefs.getString(PREF_WALLPAPER_FILE, "");
        if (fixedWallpaper == null) fixedWallpaper = "";
        Log.i(TAG, "Hatterkep automatikus valtas visszaallitva: " + autoWallpaper);
    }

    private boolean isSupportedWallpaperInterval(int minutes) {
        for (int value : WALLPAPER_INTERVAL_OPTIONS) if (value == minutes) return true;
        return false;
    }

    private void scheduleWallpaperRotation() {
        mainHandler.removeCallbacks(rotateTask);
        if (running && autoWallpaper) {
            mainHandler.postDelayed(rotateTask, wallpaperIntervalMs());
        }
    }

    private void showWallpaperMenu() {
        final String autoLabel = autoWallpaper
                ? "Automatikus váltás: BE" : "Automatikus váltás: KI";
        final String[] actions = {
                "Háttérképek megtekintése",
                autoLabel,
                "Váltási idő: " + wallpaperIntervalMinutes + " perc",
                "Képek küldése telefonról (Wi-Fi)",
                "Mappa frissítése a PC-ről (Wi-Fi)",
                "PC IP-címének beállítása"
        };
        showLightweightMenu("Háttérképek", actions, new MenuAction() {
            @Override public void onSelected(int choice) {
                if (choice == 0) {
                    showWallpaperGallery();
                } else if (choice == 1) {
                    boolean newAuto = !autoWallpaper;
                    // A mentett ertek a kovetkezo inditasnal is ervenyes.
                    boolean saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                            .putBoolean(PREF_WALLPAPER_AUTO, newAuto).commit();
                    if (!saved) {
                        Toast.makeText(MainActivity.this,
                                "Nem sikerült elmenteni a háttérkép-beállítást",
                                Toast.LENGTH_LONG).show();
                        showWallpaperMenu();
                        return;
                    }
                    autoWallpaper = newAuto;
                    scheduleWallpaperRotation();
                    showWallpaperMenu();
                } else if (choice == 2) {
                    showWallpaperIntervalMenu();
                } else if (choice == 3) {
                    showPhoneUpload();
                } else if (choice == 4) {
                    syncWallpapersOverWifi();
                } else if (choice == 5) {
                    askPcIp(false);
                }
            }
        }, new Runnable() {
            @Override public void run() { showTvHomeSettings(); }
        });
    }

    private void showWallpaperIntervalMenu() {
        final String[] options = new String[WALLPAPER_INTERVAL_OPTIONS.length];
        for (int i = 0; i < options.length; i++) {
            int minutes = WALLPAPER_INTERVAL_OPTIONS[i];
            options[i] = (minutes == wallpaperIntervalMinutes ? "✓  " : "    ")
                    + minutes + " perc";
        }
        showLightweightMenu("Háttérképváltás ideje", options, new MenuAction() {
            @Override public void onSelected(int chosen) {
                int minutes = WALLPAPER_INTERVAL_OPTIONS[chosen];
                boolean saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                        .putInt(PREF_WALLPAPER_INTERVAL, minutes).commit();
                if (!saved) {
                    Toast.makeText(MainActivity.this,
                            "Nem sikerült elmenteni a váltási időt", Toast.LENGTH_LONG).show();
                } else {
                    wallpaperIntervalMinutes = minutes;
                    // Az aktualis kep megmarad; a kovetkezo valtast mostantol szamoljuk.
                    scheduleWallpaperRotation();
                }
                showWallpaperMenu();
            }
        }, new Runnable() {
            @Override public void run() { showWallpaperMenu(); }
        });
    }

    /** V7.1: nagy, attekintheto, teljesen taviranyitos Liquid Glass galeria.
     * Kepek csak kulon hatter-szalon, maximalisan 320px-es thumbnailkent.
     * Nincs uj jogosultsag es nincs teljes meretu bitmap-cache.
     */
    private void showWallpaperGallery() { showWallpaperGallery(-1); }

    private void showWallpaperGallery(final int restoreIndex) {
        final File[] files = wallpapers();
        if (files.length == 0) {
            Toast.makeText(this, "A wallpapers mappa üres", Toast.LENGTH_LONG).show();
            showWallpaperMenu();
            return;
        }
        if (modalView != null) closeLightweightMenu();
        closeSettingsDropdown();
        modalReturnFocus = getCurrentFocus();
        modalBackAction = new Runnable() {
            @Override public void run() { showWallpaperMenu(); }
        };
        modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
        modalOptions.clear();

        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0x98050B14);
        overlay.setFocusable(true);
        overlay.setClickable(true);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int widthDp = Math.round(dm.widthPixels / dm.density);
        int heightDp = Math.round(dm.heightPixels / dm.density);
        final int panelWidth = Math.max(440, Math.min(1060, widthDp - 70));
        final int panelHeight = Math.max(290, Math.min(625, heightDp - 44));
        final int contentWidth = panelWidth - 64;
        final int columns = 4;
        final int gap = 16;
        final int tileWidth = (contentWidth - gap * (columns - 1)) / columns;
        final int imageHeight = Math.max(94, Math.round(tileWidth * 9f / 16f));
        final int tileHeight = imageHeight + 37;

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(25), dp(23), dp(25), dp(15));
        panel.setBackground(new UltraGlassDrawable(25, 2));
        panel.setElevation(dp(22));
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                dp(panelWidth), dp(panelHeight), Gravity.CENTER);
        overlay.addView(panel, panelLp);

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Háttérképek", 27, 0xFFFFFFFF);
        title.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        heading.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        // 7.7: a darabszám és a valódi tárhelyfoglalás a galéria fejlécében
        // látszik, mindig a ténylegesen létező háttérképek alapján.
        long wallpaperBytes = 0L;
        for (File picture : files) wallpaperBytes += Math.max(0L, picture.length());
        String storageInfo = files.length + " kép  •  "
                + String.format(Locale.forLanguageTag("hu-HU"), "%.1f",
                        wallpaperBytes / (1024.0 * 1024.0)) + " MB";
        TextView counter = text(storageInfo, 14, 0xF0FFFFFF);
        counter.setSingleLine(true);
        counter.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        heading.addView(counter);
        panel.addView(heading, new LinearLayout.LayoutParams(-1, dp(40)));

        TextView hint = text("← → ↑ ↓  léptetés   •   OK  kiválasztás   •   Hosszú OK  törlés   •   Vissza", 13,
                0xD5FFFFFF);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, dp(29));
        hintLp.bottomMargin = dp(13);
        panel.addView(hint, hintLp);

        final GridView gallery = new GridView(this);
        gallery.setNumColumns(columns);
        gallery.setColumnWidth(dp(tileWidth));
        gallery.setStretchMode(GridView.NO_STRETCH);
        gallery.setHorizontalSpacing(dp(gap));
        gallery.setVerticalSpacing(dp(14));
        gallery.setGravity(Gravity.CENTER_HORIZONTAL);
        gallery.setPadding(dp(6), dp(8), dp(6), dp(8));
        gallery.setClipToPadding(false);
        gallery.setClipChildren(false);
        gallery.setVerticalScrollBarEnabled(false);
        gallery.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        gallery.setFocusable(true);
        gallery.setClickable(true);
        gallery.setSelector(new ColorDrawable(0x00000000));
        gallery.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return files.length; }
            @Override public Object getItem(int position) { return files[position]; }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View recycled, ViewGroup parent) {
                final File file = files[position];
                LinearLayout cell;
                FrameLayout card;
                ImageView preview;
                TextView caption;
                if (recycled instanceof LinearLayout
                        && ((LinearLayout) recycled).getChildCount() == 2
                        && ((LinearLayout) recycled).getChildAt(0) instanceof FrameLayout
                        && ((LinearLayout) recycled).getChildAt(1) instanceof TextView) {
                    cell = (LinearLayout) recycled;
                    card = (FrameLayout) cell.getChildAt(0);
                    preview = (ImageView) card.getChildAt(0);
                    caption = (TextView) cell.getChildAt(1);
                } else {
                    cell = new LinearLayout(MainActivity.this);
                    cell.setOrientation(LinearLayout.VERTICAL);
                    cell.setGravity(Gravity.CENTER_HORIZONTAL);
                    cell.setClipChildren(false);
                    cell.setClipToPadding(false);
                    cell.setLayoutParams(new AbsListView.LayoutParams(
                            dp(tileWidth), dp(tileHeight)));
                    card = new FrameLayout(MainActivity.this);
                    card.setBackground(new UltraGlassDrawable(17, 3));
                    card.setClipChildren(false);
                    card.setClipToPadding(false);
                    preview = new ImageView(MainActivity.this);
                    preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    preview.setClipToOutline(true);
                    preview.setBackground(rounded(0x220C1C30, 16, 0, 0));
                    card.addView(preview, new FrameLayout.LayoutParams(-1, -1));
                    // Csak a szelek: nincs olyan kitoltes, ami elfedne a kepet.
                    card.setForeground(focusOutlineSelector(android.R.attr.state_selected, 17));
                    cell.addView(card, new LinearLayout.LayoutParams(-1, dp(imageHeight)));
                    caption = text("", 13, 0xE9FFFFFF);
                    caption.setSingleLine(true);
                    caption.setEllipsize(TextUtils.TruncateAt.END);
                    caption.setGravity(Gravity.CENTER);
                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(30));
                    cp.topMargin = dp(4);
                    cell.addView(caption, cp);
                }
                String filename = file.getName();
                int dot = filename.lastIndexOf('.');
                if (dot > 0) filename = filename.substring(0, dot);
                boolean current = file.getAbsolutePath().equals(displayedWallpaperPath)
                        || (displayedWallpaperPath == null && file.getName().equals(fixedWallpaper));
                caption.setText((current ? "● " : "") + filename);
                cell.setContentDescription(file.getName());
                cell.setTag(file.getAbsolutePath());
                preview.setTag(file.getAbsolutePath());
                preview.setImageDrawable(null);
                loadWallpaperGalleryThumbnail(file, preview, overlay);
                card.setSelected(false);
                cell.setActivated(false);
                cell.setScaleX(1f);
                cell.setScaleY(1f);
                return cell;
            }
        });
        panel.addView(gallery, new LinearLayout.LayoutParams(-1, 0, 1f));
        wallpaperGalleryGrid = gallery;
        wallpaperGallerySelection = 0;
        wallpaperGalleryGeneration++;
        galleryThumbnailWaiters.clear();
        gallery.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view,
                                                  int position, long id) {
                if (wallpaperGalleryGrid != gallery) return;
                if (position >= 0) wallpaperGallerySelection = position;
                refreshWallpaperGalleryFocus(gallery);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {
                refreshWallpaperGalleryFocus(gallery);
            }
        });
        // Gorgetesnel az ujrahasznositott kartyakra is azonnal visszakerul a keret.
        gallery.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView view, int state) { }
            @Override public void onScroll(AbsListView view, int firstVisibleItem,
                                           int visibleItemCount, int totalItemCount) {
                if (wallpaperGalleryGrid == gallery) refreshWallpaperGalleryFocus(gallery);
            }
        });
        gallery.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                refreshWallpaperGalleryFocus(gallery);
            }
        });
        gallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view,
                                              int position, long id) {
                final String chosen = files[position].getName();
                boolean saved = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                        .putString(PREF_WALLPAPER_FILE, chosen).commit();
                if (!saved) {
                    Toast.makeText(MainActivity.this,
                            "Nem sikerült elmenteni a kiválasztott képet",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                fixedWallpaper = chosen;
                // A kezi kivalasztas nem kapcsolja ki az automatikus valtast.
                showFirstWallpaper(true);
                scheduleWallpaperRotation();
                closeLightweightMenuGoingBack();
            }
        });
        modalView = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setAlpha(0f);
        overlay.animate().alpha(1f).setDuration(PANEL_MS).setInterpolator(tvEase).start();
        gallery.post(new Runnable() {
            @Override public void run() {
                if (modalView != overlay) return;
                int selected = restoreIndex >= 0
                        ? Math.min(restoreIndex, files.length - 1) : 0;
                if (restoreIndex < 0) {
                    for (int i = 0; i < files.length; i++) {
                        if (files[i].getAbsolutePath().equals(displayedWallpaperPath)) {
                            selected = i;
                            break;
                        }
                        if (files[i].getName().equals(fixedWallpaper)) selected = i;
                    }
                }
                wallpaperGallerySelection = selected;
                gallery.setSelection(selected);
                gallery.requestFocus();
                refreshWallpaperGalleryFocus(gallery);
            }
        });
    }

    /**
     * TV taviranyito: a modalOptions lista itt ures, ezert a normal menuk
     * key handlerje nem mukodhet. Kulon kezeljuk a negy nyilat es az OK-t.
     * ACTION_UP-ot is elnyelunk, igy egyetlen gombnyomas csak egyetlen
     * navigaciot / kivalasztast valthat ki.
     */
    private boolean handleWallpaperGalleryKey(KeyEvent event) {
        final GridView gallery = wallpaperGalleryGrid;
        if (gallery == null || gallery.getAdapter() == null) return false;
        final int key = event.getKeyCode();
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (key == KeyEvent.KEYCODE_BACK) {
            cancelWallpaperGalleryHold();
            // Csak a felengedesnel nyissuk meg az elozo menut; kulonben az
            // ACTION_UP mar az uj menut zarhatna be ugyanazzal a gombbal.
            if (event.getAction() == KeyEvent.ACTION_UP) closeLightweightMenuGoingBack();
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT
                || key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
            cancelWallpaperGalleryHold();
            modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
            if (down && gallery.getCount() > 0) {
                int oldIndex = Math.max(0, Math.min(wallpaperGallerySelection,
                        gallery.getCount() - 1));
                int next = oldIndex;
                final int columns = 4;
                if (key == KeyEvent.KEYCODE_DPAD_LEFT && oldIndex % columns > 0)
                    next = oldIndex - 1;
                else if (key == KeyEvent.KEYCODE_DPAD_RIGHT
                        && oldIndex % columns < columns - 1
                        && oldIndex + 1 < gallery.getCount())
                    next = oldIndex + 1;
                else if (key == KeyEvent.KEYCODE_DPAD_UP && oldIndex >= columns)
                    next = oldIndex - columns;
                else if (key == KeyEvent.KEYCODE_DPAD_DOWN
                        && oldIndex + columns < gallery.getCount())
                    next = oldIndex + columns;
                // Reszleges utolso sorban a legkozelebbi letezo csempere lepunk.
                else if (key == KeyEvent.KEYCODE_DPAD_DOWN
                        && oldIndex / columns < (gallery.getCount() - 1) / columns)
                    next = gallery.getCount() - 1;
                if (next != oldIndex) {
                    wallpaperGallerySelection = next;
                    gallery.setSelection(next);
                    gallery.requestFocus();
                    refreshWallpaperGalleryFocus(gallery);
                    gallery.post(new Runnable() {
                        @Override public void run() {
                            if (wallpaperGalleryGrid == gallery)
                                refreshWallpaperGalleryFocus(gallery);
                        }
                    });
                }
            }
            return true;
        }
        if (isOkKey(key)) {
            if (down && event.getRepeatCount() == 0) {
                cancelWallpaperGalleryHold();
                wallpaperGalleryHoldTriggered = false;
                wallpaperGalleryHoldKey = key;
                modalConfirmDownKey = key;
                final GridView activeGallery = gallery;
                wallpaperGalleryHoldTask = new Runnable() {
                    @Override public void run() {
                        wallpaperGalleryHoldTask = null;
                        if (wallpaperGalleryGrid == activeGallery && modalView != null
                                && wallpaperGalleryHoldKey != KeyEvent.KEYCODE_UNKNOWN
                                && wallpaperGallerySelection >= 0
                                && wallpaperGallerySelection < activeGallery.getCount()) {
                            wallpaperGalleryHoldTriggered = true;
                            modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
                            Object selectedFile = activeGallery.getAdapter().getItem(
                                    wallpaperGallerySelection);
                            if (selectedFile instanceof File) {
                                showWallpaperDeleteConfirmation((File) selectedFile,
                                        wallpaperGallerySelection);
                            }
                        }
                    }
                };
                mainHandler.postDelayed(wallpaperGalleryHoldTask, GALLERY_HOLD_TO_DELETE_MS);
            } else if (event.getAction() == KeyEvent.ACTION_UP || event.isCanceled()) {
                cancelWallpaperGalleryHold();
                boolean fresh = modalConfirmDownKey == key && !wallpaperGalleryHoldTriggered
                        && !event.isCanceled();
                modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
                wallpaperGalleryHoldTriggered = false;
                if (fresh && wallpaperGalleryGrid == gallery) {
                    int selected = wallpaperGallerySelection;
                    if (selected >= 0 && selected < gallery.getCount()) {
                        gallery.performItemClick(gallery.getSelectedView(), selected,
                                gallery.getAdapter().getItemId(selected));
                    }
                }
            }
            return true;
        }
        return false;
    }

    private void cancelWallpaperGalleryHold() {
        if (wallpaperGalleryHoldTask != null) {
            mainHandler.removeCallbacks(wallpaperGalleryHoldTask);
            wallpaperGalleryHoldTask = null;
        }
        wallpaperGalleryHoldKey = KeyEvent.KEYCODE_UNKNOWN;
    }

    /** Megerosites kulon Android-ablak nelkul, a 7.4 Liquid Glass feluleten. */
    private void showWallpaperDeleteConfirmation(File file, int index) {
        if (root == null || wallpaperGalleryGrid == null || wallpaperDeleteOverlay != null)
            return;
        wallpaperDeleteTarget = file;
        wallpaperDeleteIndex = index;
        wallpaperDeleteSelection = 0;
        wallpaperDeleteConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
        FrameLayout overlay = new FrameLayout(this);
        overlay.setFocusable(true);
        overlay.setClickable(true);
        overlay.setBackgroundColor(0x99030A12);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24), dp(22), dp(24), dp(22));
        panel.setBackground(new UltraGlassDrawable(24, 2));
        panel.setElevation(dp(30));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                dp(460), -2, Gravity.CENTER);
        overlay.addView(panel, p);

        TextView title = text("Háttérkép törlése?", 25, 0xFFFFFFFF);
        title.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        panel.addView(title, new LinearLayout.LayoutParams(-1, dp(44)));
        TextView description = text("A kép végleg törlődik a TV tárhelyéről:\n"
                + file.getName(), 15, 0xE4FFFFFF);
        description.setPadding(0, dp(8), 0, dp(18));
        panel.addView(description, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(buttons, new LinearLayout.LayoutParams(-1, dp(51)));
        wallpaperDeleteCancel = actionButton("Mégse");
        LinearLayout.LayoutParams cancelP = new LinearLayout.LayoutParams(0, -1, 1f);
        cancelP.rightMargin = dp(10);
        buttons.addView(wallpaperDeleteCancel, cancelP);
        wallpaperDeleteConfirm = actionButton("Törlés");
        wallpaperDeleteConfirm.setTextColor(0xFFFFBDC5);
        buttons.addView(wallpaperDeleteConfirm,
                new LinearLayout.LayoutParams(0, -1, 1f));
        wallpaperDeleteCancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeWallpaperDeleteOverlay(true); }
        });
        wallpaperDeleteConfirm.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { deleteSelectedWallpaper(); }
        });
        wallpaperDeleteOverlay = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setAlpha(0f);
        overlay.animate().alpha(1f).setDuration(160L).setInterpolator(tvEase).start();
        wallpaperDeleteCancel.requestFocus();
    }

    private boolean handleWallpaperDeleteKey(KeyEvent event) {
        if (wallpaperDeleteOverlay == null) return false;
        int key = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (key == KeyEvent.KEYCODE_BACK) {
            if (!down) closeWallpaperDeleteOverlay(true);
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT
                || key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (down && event.getRepeatCount() == 0) {
                wallpaperDeleteConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
                wallpaperDeleteSelection = (key == KeyEvent.KEYCODE_DPAD_RIGHT
                        || key == KeyEvent.KEYCODE_DPAD_DOWN) ? 1 : 0;
                TextView focus = wallpaperDeleteSelection == 0
                        ? wallpaperDeleteCancel : wallpaperDeleteConfirm;
                if (focus != null) focus.requestFocus();
            }
            return true;
        }
        if (isOkKey(key)) {
            if (down && event.getRepeatCount() == 0) wallpaperDeleteConfirmKey = key;
            else if (!down) {
                boolean activate = wallpaperDeleteConfirmKey == key && !event.isCanceled();
                wallpaperDeleteConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
                if (activate) {
                    if (wallpaperDeleteSelection == 0) closeWallpaperDeleteOverlay(true);
                    else deleteSelectedWallpaper();
                }
            }
            return true;
        }
        return true; // Nem hagyjuk, hogy a galeria menetje menut inditson mogotte.
    }

    private void closeWallpaperDeleteOverlay(boolean restoreFocus) {
        if (wallpaperDeleteOverlay == null) return;
        FrameLayout overlay = wallpaperDeleteOverlay;
        wallpaperDeleteOverlay = null;
        wallpaperDeleteTarget = null;
        wallpaperDeleteIndex = -1;
        wallpaperDeleteCancel = null;
        wallpaperDeleteConfirm = null;
        wallpaperDeleteConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
        overlay.animate().cancel();
        if (overlay.getParent() == root) root.removeView(overlay);
        if (restoreFocus && wallpaperGalleryGrid != null) {
            wallpaperGalleryGrid.requestFocus();
            refreshWallpaperGalleryFocus(wallpaperGalleryGrid);
        }
    }

    private void deleteSelectedWallpaper() {
        final File target = wallpaperDeleteTarget;
        final int index = wallpaperDeleteIndex;
        if (target == null || wallpaperGalleryGrid == null) return;
        // Csak a sajat wallpapers mappaban szereplo, letezo kep torolheto.
        boolean listed = false;
        for (File file : wallpapers()) {
            if (file.equals(target)) { listed = true; break; }
        }
        if (!listed || !target.isFile()) {
            closeWallpaperDeleteOverlay(true);
            Toast.makeText(this, "A kép már nem található", Toast.LENGTH_LONG).show();
            return;
        }
        final String path = target.getAbsolutePath();
        final boolean wasDisplayed = path.equals(displayedWallpaperPath);
        final boolean wasFixed = target.getName().equals(fixedWallpaper);
        if (!target.delete()) {
            closeWallpaperDeleteOverlay(true);
            Toast.makeText(this, "A kép törlése nem sikerült", Toast.LENGTH_LONG).show();
            return;
        }
        closeWallpaperDeleteOverlay(false);
        // Az aszinkron galeria-elonezetek a regi path-ot tobbe nem tolthetik vissza.
        wallpaperGalleryGeneration++;
        galleryThumbnailWaiters.clear();
        galleryThumbCache.remove(path);
        File[] remaining = wallpapers();
        final int nextIndex = Math.max(0, Math.min(index, remaining.length - 1));
        if (wasFixed) {
            fixedWallpaper = remaining.length > 0 ? remaining[nextIndex].getName() : "";
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putString(PREF_WALLPAPER_FILE, fixedWallpaper).apply();
        }
        boolean foundDisplayed = false;
        for (int i = 0; i < remaining.length; i++) {
            if (remaining[i].getAbsolutePath().equals(displayedWallpaperPath)) {
                wallpaperIndex = i;
                foundDisplayed = true;
                break;
            }
        }
        if (wasDisplayed || !foundDisplayed) {
            wallpaperIndex = remaining.length > 0 ? nextIndex : -1;
            displayedWallpaperPath = null;
            if (remaining.length == 0) showFirstWallpaper(true);
            else requestWallpaper(remaining[nextIndex], true);
        }
        scheduleWallpaperRotation();
        closeLightweightMenu();
        if (remaining.length == 0) showWallpaperMenu();
        else showWallpaperGallery(nextIndex);
        Toast.makeText(this, "Háttérkép törölve", Toast.LENGTH_SHORT).show();
    }

    private void refreshWallpaperGalleryFocus(GridView gallery) {
        if (gallery == null) return;
        // A modal overlay tud ideiglenesen fokuszt valtani, de a galerian beluli
        // kijeloles soha nem tunhet el emiatt.
        int index = gallery == wallpaperGalleryGrid ? wallpaperGallerySelection : -1;
        int first = gallery.getFirstVisiblePosition();
        for (int i = 0; i < gallery.getChildCount(); i++) {
            View child = gallery.getChildAt(i);
            if (!(child instanceof LinearLayout)) continue;
            LinearLayout row = (LinearLayout) child;
            if (row.getChildCount() < 1 || !(row.getChildAt(0) instanceof FrameLayout)) continue;
            boolean active = first + i == index;
            FrameLayout card = (FrameLayout) row.getChildAt(0);
            card.setSelected(active);
            if (row.isActivated() != active) {
                row.setActivated(active);
                row.animate().cancel();
                row.animate().scaleX(active ? 1.045f : 1f)
                        .scaleY(active ? 1.045f : 1f)
                        .setDuration(FOCUS_MS).setInterpolator(tvEase).start();
                row.setElevation(dp(active ? 15 : 0));
            }
        }
    }

    private void loadWallpaperGalleryThumbnail(final File file, final ImageView image,
                                                final FrameLayout galleryOverlay) {
        final String path = file.getAbsolutePath();
        final int galleryRequestGeneration = wallpaperGalleryGeneration;
        Bitmap thumbnail = galleryThumbCache.get(path);
        if (thumbnail != null) {
            image.setImageBitmap(thumbnail);
            return;
        }
        ArrayList<ImageView> pending = galleryThumbnailWaiters.get(path);
        if (pending != null) {
            if (!pending.contains(image)) pending.add(image);
            return;
        }
        final ArrayList<ImageView> waiters = new ArrayList<>();
        waiters.add(image);
        galleryThumbnailWaiters.put(path, waiters);
        galleryExecutor.execute(new Runnable() {
            @Override public void run() {
                if (galleryRequestGeneration != wallpaperGalleryGeneration) return;
                Bitmap loaded = null;
                try {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(path, bounds);
                    int largest = Math.max(bounds.outWidth, bounds.outHeight);
                    if (largest > 0) {
                        int sample = 1;
                        while (largest / (sample * 2) >= 320) sample *= 2;
                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inSampleSize = sample;
                        opts.inPreferredConfig = Bitmap.Config.RGB_565;
                        loaded = BitmapFactory.decodeFile(path, opts);
                        if (loaded != null && Math.max(loaded.getWidth(), loaded.getHeight()) > 320) {
                            float ratio = 320f / Math.max(loaded.getWidth(), loaded.getHeight());
                            Bitmap resized = Bitmap.createScaledBitmap(loaded,
                                    Math.max(1, Math.round(loaded.getWidth() * ratio)),
                                    Math.max(1, Math.round(loaded.getHeight() * ratio)), true);
                            if (resized != loaded) loaded.recycle();
                            loaded = resized;
                        }
                    }
                } catch (Exception error) {
                    Log.w(TAG, "Nem sikerült betölteni a galéria-előnézetet: " + path, error);
                }
                if (galleryRequestGeneration != wallpaperGalleryGeneration) {
                    if (loaded != null) loaded.recycle();
                    return;
                }
                final Bitmap ready = loaded;
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        if (galleryThumbnailWaiters.get(path) != waiters
                                || galleryRequestGeneration != wallpaperGalleryGeneration
                                || isDestroyed()) {
                            if (ready != null) ready.recycle();
                            return;
                        }
                        galleryThumbnailWaiters.remove(path);
                        if (ready == null) return;
                        galleryThumbCache.put(path, ready);
                        if (modalView == galleryOverlay) for (ImageView target : waiters) {
                            if (path.equals(target.getTag())) target.setImageBitmap(ready);
                        }
                    }
                });
            }
        });
    }

    // ---------- PC -> TV szinkron, csak gombnyomasra (nem fut allandoan) ----------

    private void syncWallpapersOverWifi() {
        if (wifiSyncBusy) return;
        String pcIp = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(PREF_WALLPAPER_PC_IP, "");
        if (pcIp == null || !validLanIp(pcIp)) {
            askPcIp(true);
            return;
        }
        final String finalIp = pcIp;
        wifiSyncBusy = true;
        final AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("Háttérképek frissítése")
                .setMessage("Kapcsolódás a számítógéphez...")
                .setCancelable(false).create();
        progress.show();

        wallpaperExecutor.execute(new Runnable() {
            @Override public void run() {
                String message;
                boolean success = false;
                try {
                    int count = pullWallpapers(finalIp, progress);
                    message = count + " háttérkép szinkronizálva a PC-ről.";
                    success = true;
                } catch (Exception ex) {
                    Log.e(TAG, "Wi-Fi wallpaper sync failed", ex);
                    message = "Nem sikerült a frissítés: " + ex.getMessage()
                            + "\nA korábbi háttérképek megmaradtak.";
                }
                final boolean done = success;
                final String result = message;
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        wifiSyncBusy = false;
                        if (isFinishing() || isDestroyed()) return;
                        progress.dismiss();
                        if (done) {
                            galleryThumbCache.evictAll();
                            wallpaperIndex = -1;
                            // Ha a korabban kivalasztott fix kep eltunt, az elsore esunk vissza.
                            File[] now = wallpapers();
                            boolean exists = false;
                            for (File f : now) {
                                if (f.getName().equals(fixedWallpaper)) { exists = true; break; }
                            }
                            if (!exists) {
                                fixedWallpaper = now.length > 0 ? now[0].getName() : "";
                                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                                        .putString(PREF_WALLPAPER_FILE, fixedWallpaper).apply();
                            }
                            // A Wi-Fi frissites ugyanolyan fajlnevnel is valtoztathat a kepen.
                            displayedWallpaperPath = null;
                            showFirstWallpaper(true);
                            scheduleWallpaperRotation();
                        }
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle(done ? "Sikeres frissítés" : "Hálózati hiba")
                                .setMessage(result)
                                .setPositiveButton("OK", null).show();
                    }
                });
            }
        });
    }

    private void askPcIp(final boolean syncAfterSave) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("pl. 192.168.0.10");
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        String prev = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(PREF_WALLPAPER_PC_IP, "");
        input.setText(prev == null ? "" : prev);
        input.selectAll();
        FrameLayout wrapper = new FrameLayout(this);
        wrapper.setPadding(dp(30), dp(8), dp(30), dp(8));
        wrapper.addView(input, new FrameLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle("A számítógéped IPv4-címe")
                .setMessage("A Start_Wallpaper_Server.ps1 megmutatja a PC IP-címét. "
                        + "Ne a TV (192.168.0.4) címét írd ide!")
                .setView(wrapper)
                .setNegativeButton("Mégse", null)
                .setPositiveButton("Mentés", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String ip = input.getText().toString().trim();
                        if (!validLanIp(ip)) {
                            Toast.makeText(MainActivity.this,
                                    "Érvénytelen helyi IPv4-cím", Toast.LENGTH_LONG).show();
                            askPcIp(syncAfterSave);
                            return;
                        }
                        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                                .putString(PREF_WALLPAPER_PC_IP, ip).apply();
                        if (syncAfterSave) syncWallpapersOverWifi();
                    }
                }).show();
    }

    // Csak privat IPv4 helyi cimeket fogadunk el.
    private boolean validLanIp(String ip) {
        if (ip == null || !ip.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        String[] parts = ip.split("\\.");
        int[] p = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                p[i] = Integer.parseInt(parts[i]);
                if (p[i] > 255) return false;
            }
        } catch (NumberFormatException ex) { return false; }
        return p[0] == 10 || (p[0] == 192 && p[1] == 168)
                || (p[0] == 172 && p[1] >= 16 && p[1] <= 31);
    }

    private HttpURLConnection connectLan(String urlText) throws Exception {
        URL url = new URL(urlText);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setConnectTimeout(6000);
        con.setReadTimeout(20000);
        con.setInstanceFollowRedirects(false);
        con.setUseCaches(false);
        con.setRequestProperty("Connection", "close");
        if (con.getResponseCode() != HttpURLConnection.HTTP_OK) {
            int code = con.getResponseCode();
            con.disconnect();
            throw new java.io.IOException("PC-kiszolgáló: HTTP " + code);
        }
        return con;
    }

    private void updateSyncProgress(final AlertDialog dialog, final String message) {
        mainHandler.post(new Runnable() {
            @Override public void run() {
                if (!isFinishing() && !isDestroyed() && dialog.isShowing()) {
                    dialog.setMessage(message);
                }
            }
        });
    }

    private int pullWallpapers(String ip, AlertDialog dialog) throws Exception {
        File base = getExternalFilesDir(null);
        if (base == null) throw new java.io.IOException("A TV tárhelye nem érhető el");
        File target = new File(base, "wallpapers");
        File stage = new File(base, "wallpapers-sync-temp");
        File backup = new File(base, "wallpapers-sync-backup");
        String prefix = "http://" + ip + ":" + WIFI_SYNC_PORT;

        HttpURLConnection manifestCon = connectLan(prefix + "/manifest");
        byte[] data;
        try (InputStream in = manifestCon.getInputStream();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int read;
            while ((read = in.read(buf)) != -1) {
                if (output.size() + read > 128 * 1024)
                    throw new java.io.IOException("Túl nagy képlista");
                output.write(buf, 0, read);
            }
            data = output.toByteArray();
        } finally { manifestCon.disconnect(); }
        JSONObject json = new JSONObject(new String(data, "UTF-8"));
        JSONArray files = json.getJSONArray("files");
        if (files.length() < 1 || files.length() > 60)
            throw new java.io.IOException("A PC-n 1–60 kép lehet a mappában");

        if (stage.exists() && !deleteTree(stage))
            throw new java.io.IOException("Régi ideiglenes mappa nem törölhető");
        if (!stage.mkdirs()) throw new java.io.IOException("Ideiglenes mappa nem hozható létre");

        try {
            long total = 0;
            java.util.HashSet<String> lowerNames = new java.util.HashSet<>();
            for (int n = 0; n < files.length(); n++) {
                JSONObject item = files.getJSONObject(n);
                String name = item.getString("name");
                String sha = item.getString("sha256").toLowerCase(Locale.ROOT);
                long expected = item.getLong("size");
                if (name.length() == 0 || name.length() > 140 || name.equals(".")
                        || name.equals("..") || name.contains("/") || name.contains("\\")
                        || name.indexOf((char) 0) >= 0 || name.startsWith("egyedi-")
                        || !name.toLowerCase(Locale.ROOT).matches(".*\\.(jpg|jpeg|png|webp)")
                        || !sha.matches("[a-f0-9]{64}")) {
                    throw new java.io.IOException("Nem biztonságos képfájlnév");
                }
                if (!lowerNames.add(name.toLowerCase(Locale.ROOT)))
                    throw new java.io.IOException("Duplikált képfájlnév");
                if (expected < 1 || expected > 25L * 1024 * 1024)
                    throw new java.io.IOException("Túl nagy vagy üres képfájl: " + name);
                total += expected;
                if (total > 180L * 1024 * 1024)
                    throw new java.io.IOException("Túl nagy képmappa (max. 180 MB)");

                updateSyncProgress(dialog, "Képek másolása: " + (n + 1) + "/" + files.length()
                        + "\n" + name);
                File dest = new File(stage, name);
                HttpURLConnection con = connectLan(prefix + "/file/" + sha);
                try (InputStream in = con.getInputStream();
                     FileOutputStream out = new FileOutputStream(dest)) {
                    MessageDigest digest = MessageDigest.getInstance("SHA-256");
                    byte[] buf = new byte[16 * 1024];
                    long received = 0;
                    int count;
                    while ((count = in.read(buf)) != -1) {
                        received += count;
                        if (received > expected)
                            throw new java.io.IOException("Hibás fájlméret: " + name);
                        digest.update(buf, 0, count);
                        out.write(buf, 0, count);
                    }
                    if (received != expected || !toHex(digest.digest()).equals(sha))
                        throw new java.io.IOException("Sérült kép: " + name);
                    out.getFD().sync();
                } finally { con.disconnect(); }
            }

            // Csak TELJES letoltes es SHA256 ellenorzes utan cserelunk.
            if (backup.exists() && !deleteTree(backup))
                throw new java.io.IOException("Régi biztonsági mappa nem törölhető");
            boolean movedOld = target.exists();
            if (movedOld && !target.renameTo(backup))
                throw new java.io.IOException("A régi háttérképek nem menthetők");
            if (!stage.renameTo(target)) {
                if (movedOld && !backup.renameTo(target))
                    throw new java.io.IOException("A korábbi képek a wallpapers-sync-backup mappában vannak");
                throw new java.io.IOException("Új képmappa aktiválása nem sikerült");
            }
            if (movedOld && !deleteTree(backup))
                Log.w(TAG, "A korábbi háttérképek biztonsági másolata megmaradt");
            return files.length();
        } finally {
            if (stage.exists()) deleteTree(stage);
        }
    }

    private String toHex(byte[] bytes) {
        StringBuilder b = new StringBuilder(bytes.length * 2);
        for (byte n : bytes) {
            b.append(Character.forDigit((n >>> 4) & 0x0f, 16));
            b.append(Character.forDigit(n & 0x0f, 16));
        }
        return b.toString();
    }

    private boolean deleteTree(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children == null) return false;
            for (File c : children) if (!deleteTree(c)) return false;
        }
        return file.delete();
    }

    // ---------- Hatterkepek: a kepek a TV-n, a /files/wallpapers mappaban vannak ----------
    private File[] wallpapers() {
        File base = getExternalFilesDir(null);
        if (base == null) return new File[0];
        File folder = new File(base, "wallpapers");
        File[] result = folder.listFiles(new FilenameFilter() {
            @Override public boolean accept(File dir, String name) {
                String n = name.toLowerCase(java.util.Locale.ROOT);
                // Regi 4.1-es automatikus masolatokat ne listazzuk, es ne forgassuk.
                if (n.startsWith("egyedi-")) return false;
                return new File(dir, name).isFile() &&
                        (n.endsWith(".jpg") || n.endsWith(".jpeg")
                                || n.endsWith(".png") || n.endsWith(".webp"));
            }
        });
        if (result == null) return new File[0];
        Arrays.sort(result);
        return result;
    }

    /** Kicsinyites es dekodolas a hatterben, hogy a taviranyito gyors maradjon. */
    private Bitmap decodeWallpaper(File file) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int maxTarget = Math.min(WALLPAPER_MAX_SIDE,
                Math.max(1, getResources().getDisplayMetrics().widthPixels));
        int sourceMax = Math.max(bounds.outWidth, bounds.outHeight);
        int sample = 1;
        while (sourceMax / (sample * 2) >= maxTarget) sample *= 2;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap decoded = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        if (decoded == null) return null;
        int largest = Math.max(decoded.getWidth(), decoded.getHeight());
        if (largest <= maxTarget) return decoded;

        float ratio = (float) maxTarget / largest;
        int w = Math.max(1, Math.round(decoded.getWidth() * ratio));
        int h = Math.max(1, Math.round(decoded.getHeight() * ratio));
        Bitmap scaled = Bitmap.createScaledBitmap(decoded, w, h, true);
        if (scaled != decoded) decoded.recycle();
        return scaled;
    }

    private void showFirstWallpaper() {
        showFirstWallpaper(false); // Hideg indulas: nincs korabbi kep, amire attunhetnenk.
    }

    private void showFirstWallpaper(boolean animate) {
        File[] files = wallpapers();
        if (files.length == 0) {
            wallpaperIndex = -1;
            wallpaperGeneration++;
            displayedWallpaperPath = null;
            if (ultraWallpaperGlass != null && !ultraWallpaperGlass.isRecycled())
                ultraWallpaperGlass.recycle();
            ultraWallpaperGlass = null;
            applyAmbientClockContrast(false);
            bgA.animate().cancel();
            bgB.animate().cancel();
            bgA.setImageDrawable(null);
            bgB.setImageDrawable(null);
            return;
        }
        // Ha egy regi 'egyedi-' hatter volt kivalasztva, ne hozzuk vissza.
        int selectedIndex = -1;
        // Az utoljara manualisan kivalasztott kep automatikus modban is
        // indulokep lehet: a 10 perces valtas ettol tovabb mukodik.
        if (!fixedWallpaper.isEmpty()) {
            for (int i = 0; i < files.length; i++) {
                if (files[i].getName().equals(fixedWallpaper)) {
                    selectedIndex = i;
                    break;
                }
            }
        }
        if (selectedIndex >= 0) {
            wallpaperIndex = selectedIndex;
        } else if (wallpaperIndex < 0 || wallpaperIndex >= files.length || !autoWallpaper) {
            wallpaperIndex = autoWallpaper
                    ? (int) ((System.currentTimeMillis() / wallpaperIntervalMs()) % files.length)
                    : 0;
        }
        requestWallpaper(files[wallpaperIndex], animate);
    }

    private void nextWallpaper() {
        File[] files = wallpapers();
        if (!autoWallpaper || files.length < 2) return;
        wallpaperIndex = (wallpaperIndex + 1) % files.length;
        requestWallpaper(files[wallpaperIndex], true);
    }

    private void requestWallpaper(final File file, final boolean crossfade) {
        if (file == null) return;
        final String path = file.getAbsolutePath();
        // Ha ez a kep mar latszik, ne kezdjunk ujra kepdekodolast es attunest.
        if (path.equals(displayedWallpaperPath)) return;
        final int generation = ++wallpaperGeneration;
        wallpaperExecutor.execute(new Runnable() {
            @Override public void run() {
                // Regi / mar felesleges kepkeresek ne foglaljak a TV memoriat.
                if (!running || generation != wallpaperGeneration) return;
                Bitmap bmp;
                try { bmp = decodeWallpaper(file); }
                catch (Exception ex) {
                    Log.e(TAG, "Hatterkep hiba: " + file, ex);
                    return;
                }
                if (!running || generation != wallpaperGeneration) {
                    if (bmp != null && !bmp.isRecycled()) bmp.recycle();
                    return;
                }
                Bitmap glassCandidate = null;
                try {
                    glassCandidate = makeUltraGlassSample(bmp);
                } catch (OutOfMemoryError oom) {
                    Log.w(TAG, "Ultra glass minta nelkul folytatjuk", oom);
                } catch (RuntimeException ex) {
                    Log.w(TAG, "Ultra glass blur nem sikerult", ex);
                }
                // A belso Runnable csak vegleges (final) lokalis valtozot hasznalhat.
                final Bitmap glassSample = glassCandidate;
                final boolean brightClockBackdrop = sampleClockBackdropBrightness(bmp);
                final Bitmap image = bmp;
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        if (!running || generation != wallpaperGeneration || image == null) {
                            if (image != null && !image.isRecycled()) image.recycle();
                            if (glassSample != null && !glassSample.isRecycled()) glassSample.recycle();
                            return;
                        }
                        Bitmap formerGlass = ultraWallpaperGlass;
                        ultraWallpaperGlass = glassSample;
                        if (formerGlass != null && formerGlass != glassSample
                                && !formerGlass.isRecycled()) formerGlass.recycle();
                        invalidateUltraGlassSurfaces(root);
                        applyAmbientClockContrast(brightClockBackdrop);
                        bgA.animate().cancel();
                        bgB.animate().cancel();
                        final ImageView outgoing = frontIsA ? bgA : bgB;
                        final ImageView incoming = frontIsA ? bgB : bgA;
                        final boolean hasPrevious = outgoing.getDrawable() != null;
                        if (!crossfade || !hasPrevious) {
                            // Hideg indulas / elso kep: rogton megjelenitjuk.
                            bgA.setImageDrawable(null);
                            bgB.setImageDrawable(null);
                            bgA.setImageBitmap(image);
                            bgA.setAlpha(1f);
                            bgB.setAlpha(0f);
                            frontIsA = true;
                        } else {
                            // bgB a bgA FELETT van a root-ban, ezert a ket iranyt
                            // mashogy animaltatjuk. Igy az atmenet soran mindig
                            // legalabb egy teljesen atlatszatlan kep latszik.
                            incoming.setImageBitmap(image);
                            outgoing.setAlpha(1f);
                            if (frontIsA) {
                                // A elol -> B felulrol lassan feltunik.
                                incoming.setAlpha(0f);
                                incoming.animate().alpha(1f)
                                        .setDuration(WALLPAPER_FADE_MS)
                                        .setInterpolator(new AccelerateDecelerateInterpolator())
                                        .withEndAction(new Runnable() {
                                            @Override public void run() {
                                                if (generation == wallpaperGeneration && running) {
                                                    outgoing.setAlpha(0f);
                                                    outgoing.setImageDrawable(null);
                                                }
                                            }
                                        }).start();
                            } else {
                                // B felul -> A alatta: a regi B fokozatosan eltunik.
                                incoming.setAlpha(1f);
                                outgoing.animate().alpha(0f)
                                        .setDuration(WALLPAPER_FADE_MS)
                                        .setInterpolator(new AccelerateDecelerateInterpolator())
                                        .withEndAction(new Runnable() {
                                            @Override public void run() {
                                                if (generation == wallpaperGeneration && running) {
                                                    outgoing.setImageDrawable(null);
                                                }
                                            }
                                        }).start();
                            }
                            frontIsA = !frontIsA;
                        }
                        displayedWallpaperPath = path;
                    }
                });
            }
        });
    }

    // ---------- Konnyu, Activity-n beluli opciomenuk (5.3) ----------
    // A korabbi AlertDialog minden megnyitasnal uj Window/ViewRootImpl-t hozott
    // letre. A sajat opciomenuk nem nyitnak uj Android ablakot.
    private interface MenuAction {
        void onSelected(int option);
    }

    /**
     * A sima ScrollView a requestChildFocus() alatt azonnal arrébb ugrik.
     * Ezzel a kis alosztallyal az automatikus ugrast tiltjuk le CSAK a
     * Control Centerben, a gorgetest a kovetkezo animator kezeli.
     */
    private final class ControlCenterScrollView extends ScrollView {
        ControlCenterScrollView(Context context) { super(context); }
        @Override public void requestChildFocus(View child, View focused) {
            // A normal Android-fokusz tovabbmegy, de a ScrollView NEM
            // ugorhat a gyerekre: a sajat animator gorgit hozza.
            if (getParent() != null) getParent().requestChildFocus(this, focused);
        }
        @Override public boolean requestChildRectangleOnScreen(View child,
                Rect rectangle, boolean immediate) {
            return false;
        }
    }

    /**
     * Az uj csempe kivalasztasa nem a getCurrentFocus()-ra tamaszkodik.
     * Ha a kovetkezo csempe a ScrollView lathato reszen kivul van,
     * eloszor odagorgetunk, es csak az animacio VEGEN kerunk fokuszt.
     * Igy a D-pad minden csempet eler, a natív ScrollView pedig nem ugral.
     */
    private void moveControlCenterFocus(int next) {
        if (controlCenterView == null || next < 0 || next >= controlCenterTiles.size()) return;
        controlCenterCursor = next;
        revealControlCenterTile(controlCenterTiles.get(next), true);
    }

    /** Egyetlen, megszakithato, rovid mozgas a kijelolt csempehez. */
    private void revealControlCenterTile(View tile) {
        revealControlCenterTile(tile, false);
    }

    private void revealControlCenterTile(final View tile, final boolean focusWhenVisible) {
        final ScrollView scroll = controlCenterScroll;
        if (scroll == null || controlCenterView == null || tile == null) return;
        if (tile.getHeight() <= 0 || scroll.getHeight() <= 0) {
            // Elso layout-frameben meg nincs kiszamolva a csempe pozicioja.
            if (focusWhenVisible) {
                scroll.post(new Runnable() {
                    @Override public void run() {
                        if (controlCenterView != null && controlCenterScroll == scroll
                                && controlCenterCursor < controlCenterTiles.size()
                                && controlCenterTiles.get(controlCenterCursor) == tile)
                            revealControlCenterTile(tile, true);
                    }
                });
            }
            return;
        }
        if (!(tile.getParent() instanceof View)
                || !(((View) tile.getParent()).getParent() instanceof View)) return;
        View row = (View) tile.getParent();
        View content = (View) row.getParent();
        int itemTop = content.getTop() + row.getTop() + tile.getTop();
        int itemBottom = itemTop + tile.getHeight();
        int margin = dp(14);
        int current = scroll.getScrollY();
        int target = current;
        if (itemTop < current + margin) target = itemTop - margin;
        else if (itemBottom > current + scroll.getHeight() - margin)
            target = itemBottom - scroll.getHeight() + margin;
        int maxY = Math.max(0, content.getHeight() - scroll.getHeight());
        target = Math.max(0, Math.min(maxY, target));
        if (controlCenterScrollAnimator != null) {
            controlCenterScrollAnimator.cancel();
            controlCenterScrollAnimator = null;
        }
        if (target == current) {
            if (focusWhenVisible && controlCenterView != null) tile.requestFocus();
            return;
        }
        final ValueAnimator animator = ValueAnimator.ofInt(current, target);
        controlCenterScrollAnimator = animator;
        animator.setDuration(245L);
        animator.setInterpolator(tvEase);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                if (controlCenterScroll == scroll && controlCenterView != null)
                    scroll.scrollTo(0, (Integer) a.getAnimatedValue());
            }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (controlCenterScrollAnimator == a) controlCenterScrollAnimator = null;
                if (!cancelled && focusWhenVisible && controlCenterView != null
                        && controlCenterScroll == scroll
                        && controlCenterCursor >= 0
                        && controlCenterCursor < controlCenterTiles.size()
                        && controlCenterTiles.get(controlCenterCursor) == tile) {
                    tile.requestFocus();
                }
            }
        });
        animator.start();
    }

    // ---------- TVHome 7.2 – Liquid Glass Control Center ----------
    // A főképernyő nem kap új gombot. Elérés: Beállítások > Vezérlőközpont,
    // vagy MENU, ha a fizikai távirányító továbbítja az Androidnak.
    /** TVHome 7.3: az uj gyorskezelő egy jobboldali, teljes magas Liquid Glass sav.
     * A nyilas/OK navigacio a korabbi, bevalt kezeles marad.
     */
    private void showControlCenter(View restoreTo) {
        if (root == null || !running || moving || appearanceOverlay != null
                || modalView != null || editorView != null || pickerView != null) return;
        if (controlCenterView != null) return;
        if (settingsDropdown != null) closeSettingsDropdown();
        controlCenterReturnFocus = restoreTo != null ? restoreTo : getCurrentFocus();
        controlCenterConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
        controlCenterCursor = 0;
        controlCenterTiles.clear();

        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0x48030A13);
        overlay.setFocusable(false);
        overlay.setClickable(true);

        // A glass hatter, a tartalom ES a kontur ugyanabban a kerekre
        // maszkolt keretben van; semmi nem rajzolhat a sarokokon tul.
        final FrameLayout panelShell = new FrameLayout(this);
        panelShell.setBackground(new UltraGlassDrawable(30, 2));
        panelShell.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(30));
            }
        });
        panelShell.setClipToOutline(true);
        panelShell.setClipChildren(true);
        panelShell.setClipToPadding(true);
        panelShell.setElevation(dp(26));

        int screenDp = Math.round(getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
        int widthDp = Math.min(480, Math.max(300, screenDp - 18));
        // A TV kepernyojetol 12 dp res: felul es alul is latszik a kerekites.
        FrameLayout.LayoutParams shellLp = new FrameLayout.LayoutParams(
                dp(widthDp), -1, Gravity.RIGHT | Gravity.TOP);
        shellLp.topMargin = dp(12);
        shellLp.bottomMargin = dp(12);
        shellLp.rightMargin = dp(12);
        overlay.addView(panelShell, shellLp);

        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setClipChildren(true);
        panel.setClipToPadding(true);
        panel.setPadding(dp(21), dp(23), dp(21), dp(12));
        panelShell.addView(panel, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout titleArea = new LinearLayout(this);
        titleArea.setOrientation(LinearLayout.VERTICAL);
        titleArea.setPadding(dp(8), dp(4), dp(4), dp(17));
        panel.addView(titleArea, new LinearLayout.LayoutParams(-1, -2));
        TextView eyebrow = text("T V H O M E     /     G Y O R S V E Z É R L É S", 10, 0xB9E4F2FF);
        titleArea.addView(eyebrow, new LinearLayout.LayoutParams(-1, dp(20)));
        TextView heading = text("Vezérlőközpont", 25, 0xFFFFFFFF);
        heading.setTypeface(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD);
        titleArea.addView(heading, new LinearLayout.LayoutParams(-1, dp(42)));
        TextView hint = text("Távirányítóval vezérelhető  •  Vissza: bezárás", 12, 0xCEFFFFFF);
        titleArea.addView(hint, new LinearLayout.LayoutParams(-1, dp(23)));

        final ControlCenterScrollView scroll = new ControlCenterScrollView(this);
        controlCenterScroll = scroll;
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipChildren(true);
        scroll.setClipToPadding(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout gridArea = new LinearLayout(this);
        gridArea.setOrientation(LinearLayout.VERTICAL);
        gridArea.setClipChildren(false);
        gridArea.setClipToPadding(false);
        gridArea.setPadding(dp(4), dp(8), dp(4), dp(10));
        scroll.addView(gridArea, new ScrollView.LayoutParams(-1, -2));

        final String[] titles = {
                "Wi-Fi", "Bluetooth", "HDMI-források", "Ambient Mode",
                "Következő háttér", "Auto képváltás", "Képgaléria", "Megjelenés"
        };
        final String[] descs = {
                networkStateText(0), networkStateText(1),
                "Bemenetválasztás", "Képernyővédő",
                "Következő tájkép", autoWallpaper ? "BE  •  " + wallpaperIntervalMinutes + " perc" : "KI",
                "Képek böngészése", "Liquid Glass"
        };

        for (int row = 0; row < 4; row++) {
            LinearLayout pair = new LinearLayout(this);
            pair.setOrientation(LinearLayout.HORIZONTAL);
            pair.setClipChildren(false);
            pair.setClipToPadding(false);
            LinearLayout.LayoutParams pairLp = new LinearLayout.LayoutParams(-1, dp(104));
            if (row > 0) pairLp.topMargin = dp(13);
            gridArea.addView(pair, pairLp);
            for (int col = 0; col < 2; col++) {
                final int which = row * 2 + col;
                final LinearLayout tile = new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setGravity(Gravity.CENTER_VERTICAL);
                tile.setPadding(dp(13), dp(11), dp(10), dp(10));
                tile.setFocusable(true);
                tile.setClickable(true);
                tile.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
                tile.setBackground(controlCenterGlassTileSelector());
                tile.setElevation(dp(3));
                LinearLayout iconHeader = new LinearLayout(this);
                iconHeader.setOrientation(LinearLayout.HORIZONTAL);
                iconHeader.setGravity(Gravity.CENTER_VERTICAL);
                ImageView icon = new ImageView(this);
                icon.setImageDrawable(new ControlIcon(which));
                iconHeader.addView(icon, new LinearLayout.LayoutParams(dp(25), dp(25)));
                View space = new View(this);
                iconHeader.addView(space, new LinearLayout.LayoutParams(0, 1, 1f));
                if (which < 2) {
                    TextView statusDot = text("●", 13,
                            networkActive(which) ? 0xFF7AF7C8 : 0x77FFFFFF);
                    iconHeader.addView(statusDot, new LinearLayout.LayoutParams(-2, -2));
                }
                tile.addView(iconHeader, new LinearLayout.LayoutParams(-1, dp(30)));
                TextView title = text(titles[which], 14, 0xFFFFFFFF);
                title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                title.setSingleLine(true);
                title.setEllipsize(TextUtils.TruncateAt.END);
                tile.addView(title, new LinearLayout.LayoutParams(-1, dp(21)));
                TextView sub = text(descs[which], 11, 0xD7FFFFFF);
                sub.setSingleLine(true);
                sub.setEllipsize(TextUtils.TruncateAt.END);
                tile.addView(sub, new LinearLayout.LayoutParams(-1, dp(18)));
                LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(0, -1, 1f);
                if (col == 1) tileLp.leftMargin = dp(11);
                pair.addView(tile, tileLp);
                controlCenterTiles.add(tile);
                tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override public void onFocusChange(View v, boolean focused) {
                        v.animate().cancel();
                        v.animate().scaleX(focused ? 1.065f : 1f)
                                .scaleY(focused ? 1.075f : 1f)
                                .setDuration(FOCUS_MS).setInterpolator(tvEase).start();
                        v.setElevation(dp(focused ? 16 : 3));
                        if (focused) {
                            int index = controlCenterTiles.indexOf(v);
                            if (index >= 0) controlCenterCursor = index;
                            if (controlCenterScrollAnimator == null)
                                revealControlCenterTile(v);
                        }
                    }
                });
                tile.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { performControlCenterAction(which); }
                });
            }
        }
        TextView footer = text("MENU  /  VISSZA       ●  Kapcsolat állapota", 11, 0xCCFFFFFF);
        footer.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, dp(36));
        footerLp.topMargin = dp(7);
        panel.addView(footer, footerLp);

        controlCenterView = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setAlpha(0f);
        panelShell.setTranslationX(dp(widthDp + 26));
        overlay.animate().alpha(1f).setDuration(150L).setInterpolator(tvEase).start();
        panelShell.animate().translationX(0f).setDuration(280L)
                .setInterpolator(tvEase).start();
        controlCenterTiles.get(0).requestFocus();
    }

    private Drawable controlCenterGlassTileSelector() {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused},
                visibleMenuFocus(19));
        states.addState(new int[]{},
                glassRounded(new int[]{0x59B7D8F2, 0x27637E9F}, 19, 0x69FFFFFF, 1));
        return states;
    }

    /** Egyedi, kisméretű Canvas vektorikonok, képfájlok nélkül. */
    private static final class ControlIcon extends Drawable {
        private final int type;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int alpha = 255;
        ControlIcon(int type) { this.type = type; }
        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            c.save();
            c.translate(b.left, b.top);
            c.scale(b.width() / 100f, b.height() / 100f);
            paint.setColor(0xFFF7FCFF);
            paint.setAlpha(alpha);
            paint.setStrokeWidth(7f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStyle(Paint.Style.STROKE);
            Path path = new Path();
            switch (type) {
                case 0: // Wi-Fi – harom koncentrikus hullam
                    c.drawArc(9, 21, 91, 91, 224, 92, false, paint);
                    c.drawArc(26, 42, 74, 92, 226, 88, false, paint);
                    paint.setStyle(Paint.Style.FILL);
                    c.drawCircle(50, 83, 5.5f, paint);
                    break;
                case 1: // Bluetooth – szabalyos runa
                    path.moveTo(50, 8); path.lineTo(74, 28); path.lineTo(28, 72);
                    path.moveTo(50, 92); path.lineTo(74, 70); path.lineTo(28, 27);
                    path.moveTo(50, 8); path.lineTo(50, 92); c.drawPath(path, paint);
                    break;
                case 2: // HDMI – monitor + cable
                    c.drawRoundRect(9, 12, 91, 69, 8, 8, paint);
                    c.drawLine(50, 69, 50, 83, paint);
                    c.drawLine(30, 85, 70, 85, paint);
                    break;
                case 3: // Ambient – holdsarlo + csillag
                    paint.setStyle(Paint.Style.FILL);
                    path.moveTo(60, 8); path.cubicTo(16, 16, 18, 86, 73, 90);
                    path.cubicTo(42, 100, 15, 69, 27, 36);
                    path.cubicTo(32, 22, 46, 12, 60, 8); c.drawPath(path, paint);
                    c.drawCircle(81, 24, 5, paint);
                    break;
                case 4: // kovetkezo kep – kepkeret es nyil
                    c.drawRoundRect(7, 13, 83, 80, 9, 9, paint);
                    path.moveTo(18, 66); path.lineTo(39, 44); path.lineTo(50, 56);
                    path.lineTo(62, 40); path.lineTo(80, 64); c.drawPath(path, paint);
                    c.drawCircle(61, 30, 4, paint);
                    c.drawLine(82, 69, 95, 69, paint);
                    c.drawLine(88, 61, 95, 69, paint); c.drawLine(88, 77, 95, 69, paint);
                    break;
                case 5: // auto – korbejaro nyil
                    c.drawArc(15, 15, 85, 85, 210, 296, false, paint);
                    path.moveTo(74, 12); path.lineTo(87, 30); path.lineTo(66, 33);
                    c.drawPath(path, paint);
                    break;
                case 6: // galeria – fedesben levo fenykepkeretek
                    c.drawRoundRect(16, 20, 89, 85, 7, 7, paint);
                    c.drawLine(11, 10, 74, 10, paint);
                    path.moveTo(21, 74); path.lineTo(42, 51); path.lineTo(53, 63);
                    path.lineTo(66, 49); path.lineTo(83, 69); c.drawPath(path, paint);
                    c.drawCircle(66, 36, 5, paint);
                    break;
                default: // megjelenes – allitocsuszkak
                    c.drawLine(16, 25, 84, 25, paint);
                    c.drawLine(16, 50, 84, 50, paint);
                    c.drawLine(16, 75, 84, 75, paint);
                    paint.setStyle(Paint.Style.FILL);
                    c.drawCircle(38, 25, 9, paint);
                    c.drawCircle(68, 50, 9, paint);
                    c.drawCircle(46, 75, 9, paint);
                    break;
            }
            c.restore();
        }
        @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) {
            paint.setColorFilter(filter); invalidateSelf();
        }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private boolean networkActive(int which) {
        try {
            if (which == 0) {
                WifiManager manager = (WifiManager) getApplicationContext()
                        .getSystemService(Context.WIFI_SERVICE);
                return manager != null && manager.isWifiEnabled();
            }
            BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            return adapter != null && adapter.isEnabled();
        } catch (SecurityException denied) { return false; }
        catch (Exception ex) { return false; }
    }

    private String networkStateText(int which) {
        if (which == 1 && Build.VERSION.SDK_INT >= 31
                && checkSelfPermission("android.permission.BLUETOOTH_CONNECT")
                != PackageManager.PERMISSION_GRANTED) return "Engedély szükséges";
        return networkActive(which) ? "Bekapcsolva" : "Kikapcsolva";
    }

    private void refreshNetworkTiles() {
        if (controlCenterView == null) return;
        for (int which = 0; which < 2 && which < controlCenterTiles.size(); which++) {
            LinearLayout tile = controlCenterTiles.get(which);
            if (tile.getChildCount() < 3) continue;
            TextView sub = (TextView) tile.getChildAt(2);
            sub.setText(networkStateText(which));
            LinearLayout header = (LinearLayout) tile.getChildAt(0);
            if (header.getChildCount() >= 3) {
                TextView dot = (TextView) header.getChildAt(2);
                dot.setTextColor(networkActive(which) ? 0xFF7AF7C8 : 0x77FFFFFF);
            }
        }
    }

    private void handleNetworkToggle(final int which) {
        if (networkRequestInProgress) return;
        final boolean target = !networkActive(which);
        if (which == 0) {
            try {
                WifiManager wifi = (WifiManager) getApplicationContext()
                        .getSystemService(Context.WIFI_SERVICE);
                if (wifi == null) {
                    Toast.makeText(this, "Wi-Fi nem elérhető", Toast.LENGTH_LONG).show(); return;
                }
                boolean accepted = wifi.setWifiEnabled(target);
                if (!accepted) {
                    Toast.makeText(this,
                            "Az Android nem engedte a Wi-Fi kapcsolását ezen a rendszeren.",
                            Toast.LENGTH_LONG).show();
                    refreshNetworkTiles(); return;
                }
                networkRequestInProgress = true;
                verifyRadioChange(0, target);
            } catch (Exception e) {
                Log.w(TAG, "Wi-Fi kapcsolás megtagadva", e);
                Toast.makeText(this, "Wi-Fi kapcsolás letiltva: " + e.getClass().getSimpleName(),
                        Toast.LENGTH_LONG).show();
                refreshNetworkTiles();
            }
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(
                "android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            pendingBluetoothTarget = target;
            requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"},
                    REQUEST_BT_CONNECT);
            return;
        }
        if (!target) {
            // BT taviranyito eseten ezt csak megerosites utan szabad megtenni.
            new AlertDialog.Builder(this)
                    .setTitle("Bluetooth kikapcsolása?")
                    .setMessage("Ha a távirányító Bluetooth-os, elveszítheted vele a kapcsolatot. "
                            + "Csak akkor kapcsold ki, ha más módon is vissza tudod kapcsolni.")
                    .setNegativeButton("Mégse", null)
                    .setPositiveButton("Kikapcsolás", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            performBluetoothSwitch(false);
                        }
                    }).show();
            return;
        }
        performBluetoothSwitch(true);
    }

    @SuppressWarnings("deprecation")
    private void performBluetoothSwitch(boolean target) {
        try {
            BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            if (adapter == null) {
                Toast.makeText(this, "Bluetooth nem elérhető", Toast.LENGTH_LONG).show();
                return;
            }
            boolean accepted = target ? adapter.enable() : adapter.disable();
            if (!accepted) {
                Toast.makeText(this,
                        "Az Android nem engedte a Bluetooth kapcsolását.",
                        Toast.LENGTH_LONG).show();
                refreshNetworkTiles(); return;
            }
            networkRequestInProgress = true;
            verifyRadioChange(1, target);
        } catch (Exception e) {
            Log.w(TAG, "Bluetooth kapcsolás megtagadva", e);
            Toast.makeText(this, "Bluetooth kapcsolás letiltva: " + e.getClass().getSimpleName(),
                    Toast.LENGTH_LONG).show();
            refreshNetworkTiles();
        }
    }

    private void verifyRadioChange(final int which, final boolean expected) {
        mainHandler.postDelayed(new Runnable() {
            @Override public void run() {
                networkRequestInProgress = false;
                boolean actual = networkActive(which);
                refreshNetworkTiles();
                if (actual != expected) {
                    Toast.makeText(MainActivity.this, (which == 0 ? "Wi-Fi" : "Bluetooth")
                            + ": a TV rendszere nem hajtotta végre a kapcsolást.",
                            Toast.LENGTH_LONG).show();
                }
            }
        }, 1600L);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                       int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BT_CONNECT) {
            Boolean desired = pendingBluetoothTarget;
            pendingBluetoothTarget = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && desired != null) {
                if (!desired) handleNetworkToggle(1); // megerosites, mielott BT-off lenne
                else performBluetoothSwitch(true);
            } else {
                Toast.makeText(this, "Bluetooth engedély nélkül nem kapcsolható.",
                        Toast.LENGTH_LONG).show();
                refreshNetworkTiles();
            }
        }
    }

    private boolean handleControlCenterKey(KeyEvent event) {
        int key = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (key == KeyEvent.KEYCODE_BACK || key == KeyEvent.KEYCODE_MENU) {
            if (down && event.getRepeatCount() == 0) closeControlCenter(true);
            return true;
        }
        if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT
                || key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (down) {
                // Minden lenyomasnal a LOGIKAI indexet leptetjuk, nem a
                // meg animalt / offscreen View pillanatnyi fokuszat.
                int position = Math.max(0, Math.min(controlCenterCursor,
                        controlCenterTiles.size() - 1));
                int next = position;
                if (key == KeyEvent.KEYCODE_DPAD_LEFT && position % 2 == 1) next--;
                if (key == KeyEvent.KEYCODE_DPAD_RIGHT && position % 2 == 0) next++;
                if (key == KeyEvent.KEYCODE_DPAD_UP && position >= 2) next -= 2;
                if (key == KeyEvent.KEYCODE_DPAD_DOWN && position < 6) next += 2;
                if (next != position && next >= 0 && next < controlCenterTiles.size())
                    moveControlCenterFocus(next);
            }
            return true;
        }
        if (isOkKey(key)) {
            if (down && event.getRepeatCount() == 0) controlCenterConfirmKey = key;
            if (!down) {
                boolean confirmed = controlCenterConfirmKey == key;
                controlCenterConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
                if (confirmed && controlCenterScrollAnimator == null
                        && controlCenterCursor >= 0
                        && controlCenterCursor < controlCenterTiles.size()) {
                    LinearLayout target = controlCenterTiles.get(controlCenterCursor);
                    if (target.hasFocus()) target.performClick();
                }
            }
            return true;
        }
        // A hangerő / média / rendszerbillentyűk normál kezelése megmarad.
        return super.dispatchKeyEvent(event);
    }

    private void closeControlCenter(boolean restoreFocus) {
        if (controlCenterView == null) return;
        final FrameLayout old = controlCenterView;
        final View target = controlCenterReturnFocus;
        controlCenterView = null;
        controlCenterReturnFocus = null;
        controlCenterConfirmKey = KeyEvent.KEYCODE_UNKNOWN;
        if (controlCenterScrollAnimator != null) {
            controlCenterScrollAnimator.cancel();
            controlCenterScrollAnimator = null;
        }
        controlCenterScroll = null;
        controlCenterTiles.clear();
        old.animate().cancel();
        old.setFocusable(false);
        old.setClickable(false);
        // A teljes jobboldali uvegpanel kifelé csuszik, nem kozepre záródik.
        for (int i = 0; i < old.getChildCount(); i++) {
            View child = old.getChildAt(i);
            child.animate().cancel();
            child.animate().translationX(dp(500)).setDuration(190L)
                    .setInterpolator(tvEase).start();
        }
        old.animate().alpha(0f).setDuration(195L)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        if (old.getParent() == root) root.removeView(old);
                        old.removeAllViews();
                    }
                }).start();
        if (restoreFocus) {
            if (target != null && target.isAttachedToWindow()) {
                // A fogaskerek fokusza ne nyissa ujra a dropdown-t automatikusan.
                suppressSettingsAutoOpen = true;
                target.requestFocus();
            } else focusFirstDockItem();
        }
    }

    private void performControlCenterAction(int which) {
        if (which < 2) {
            handleNetworkToggle(which);
            return;
        }
        closeControlCenter(true);
        switch (which) {
            case 4: {
                // Manualis lepes akkor is mukodik, ha az automatikus valtas KI.
                File[] files = wallpapers();
                if (files.length < 2) {
                    Toast.makeText(this, "Legalább két háttérkép szükséges",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                int current = -1;
                for (int i = 0; i < files.length; i++) {
                    if (files[i].getAbsolutePath().equals(displayedWallpaperPath)) {
                        current = i; break;
                    }
                }
                if (current < 0) {
                    for (int i = 0; i < files.length; i++) {
                        if (files[i].getName().equals(fixedWallpaper)) {
                            current = i; break;
                        }
                    }
                }
                wallpaperIndex = (current + 1) % files.length;
                fixedWallpaper = files[wallpaperIndex].getName();
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                        .putString(PREF_WALLPAPER_FILE, fixedWallpaper).apply();
                requestWallpaper(files[wallpaperIndex], true);
                scheduleWallpaperRotation();
                break;
            }
            case 3:
                enterAmbientMode();
                break;
            case 2:
                showInputsMenu();
                break;
            case 5:
                autoWallpaper = !autoWallpaper;
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                        .putBoolean(PREF_WALLPAPER_AUTO, autoWallpaper).apply();
                scheduleWallpaperRotation();
                Toast.makeText(this, autoWallpaper
                        ? "Automatikus háttérképváltás: BE"
                        : "Automatikus háttérképváltás: KI", Toast.LENGTH_SHORT).show();
                break;
            case 6:
                showWallpaperGallery();
                break;
            case 7:
                showAppearanceMenu();
                break;
            default: break;
        }
    }

    private void showLightweightMenu(String heading, String[] choices, final MenuAction action) {
        showLightweightMenu(heading, choices, action, null);
    }

    private void showLightweightMenu(String heading, String[] choices,
                                     final MenuAction action, Runnable backAction) {
        showLightweightMenu(heading, choices, action, backAction, true);
    }

    private void showLightweightMenu(String heading, String[] choices,
                                     final MenuAction action, Runnable backAction,
                                     boolean addBackRow) {
        if (modalView != null) closeLightweightMenu();
        closeSettingsDropdown();
        modalReturnFocus = getCurrentFocus();
        modalBackAction = backAction;
        // Kulcsfontossagu: ha a menut hosszu OK nyitotta meg, annak
        // kovetkezo ACTION_UP-ja ne aktivalhassa az elso opciot.
        modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;

        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0x81040A13);
        overlay.setFocusable(true);
        overlay.setClickable(true);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setBackground(new UltraGlassDrawable(22, 2));
        // The five-row wallpaper menu must not reserve a huge empty area below
        // its last option. Keep scrollable height for longer, variable lists.
        boolean isWallpaperMenu = "Háttérképek".equals(heading)
                || "Háttérképváltás ideje".equals(heading);
        boolean compactMenu = choices.length + (addBackRow ? 1 : 0) <= 3;
        int widthDp = isWallpaperMenu ? 520
                : (compactMenu ? ("Források".equals(heading) ? 360 : 420) : 580);
        FrameLayout.LayoutParams scrollLp = new FrameLayout.LayoutParams(
                dp(widthDp), (compactMenu || isWallpaperMenu) ? -2 : dp(470),
                Gravity.CENTER);
        overlay.addView(scroll, scrollLp);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(18), dp(22), dp(18));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        TextView titleView = text(heading, 25, 0xFFFFFFFF);
        titleView.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.bottomMargin = dp(16);
        content.addView(titleView, titleLp);

        modalOptions.clear();
        int itemCount = choices.length + (addBackRow ? 1 : 0);
        for (int i = 0; i < itemCount; i++) {
            final int selected = i;
            TextView item = actionButton(i == choices.length ? "Vissza" : choices[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(49));
            lp.bottomMargin = dp(9);
            content.addView(item, lp);
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (selected == choices.length) {
                        closeLightweightMenuGoingBack();
                    } else {
                        closeLightweightMenu();
                        action.onSelected(selected);
                    }
                }
            });
            modalOptions.add(item);
        }
        modalView = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setAlpha(0f);
        scroll.setPivotX(dp(widthDp) / 2f);
        scroll.setPivotY(0f);
        scroll.setScaleX(0.92f); scroll.setScaleY(0.92f);
        scroll.setAlpha(0.38f);
        scroll.setTranslationY(dp(23));
        overlay.animate().alpha(1f).setDuration(165L)
                .setInterpolator(tvEase).start();
        scroll.animate().scaleX(1f).scaleY(1f).translationY(0f).alpha(1f)
                .setDuration(Math.max(245L, PANEL_MS)).setInterpolator(tvEase).start();
        final TextView first = modalOptions.get(0);
        first.requestFocus();
        first.post(new Runnable() {
            @Override public void run() {
                if (modalView == overlay) first.requestFocus();
            }
        });
    }

    private void closeLightweightMenuGoingBack() {
        Runnable onBack = modalBackAction;
        closeLightweightMenu();
        if (onBack != null) onBack.run();
    }

    private void closeLightweightMenu() {
        if (modalView == null) return;
        cancelWallpaperGalleryHold();
        closeWallpaperDeleteOverlay(false);
        View previous = modalReturnFocus;
        final View disappearing = modalView;
        final boolean closingSources = SOURCES_MENU_TAG.equals(disappearing.getTag());
        if (wallpaperGalleryGrid != null) {
            wallpaperGalleryGeneration++;
            galleryThumbnailWaiters.clear();
            // Referencia levalasztasa, az aszinkron thumb visszairas csak aktiv galeriaba mehet.
            wallpaperGalleryGrid.setOnItemSelectedListener(null);
            wallpaperGalleryGrid.setOnScrollListener(null);
            wallpaperGalleryGrid.setOnItemClickListener(null);
            wallpaperGalleryGrid.setAdapter(null);
            wallpaperGalleryGrid = null;
            wallpaperGallerySelection = -1;
        }
        disappearing.animate().cancel();
        disappearing.setFocusable(false);
        disappearing.setClickable(false);
        // Hatterkep / forras menu kilepesekor gyors fade-out; a fokusz
        // azonnal visszakerul az eredeti gombra, nincs uj Window.
        if (disappearing instanceof ViewGroup
                && ((ViewGroup) disappearing).getChildCount() > 0) {
            View closingPanel = ((ViewGroup) disappearing).getChildAt(0);
            closingPanel.animate().cancel();
            closingPanel.animate().alpha(0.55f).scaleX(0.975f).scaleY(0.975f)
                    .translationY(dp(7)).setDuration(145L)
                    .setInterpolator(tvEase).start();
        }
        disappearing.animate().alpha(0f).setDuration(150L)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        if (disappearing.getParent() == root) root.removeView(disappearing);
                        if (disappearing instanceof ViewGroup)
                            ((ViewGroup) disappearing).removeAllViews();
                    }
                }).start();
        modalView = null;
        modalReturnFocus = null;
        modalBackAction = null;
        modalConfirmDownKey = KeyEvent.KEYCODE_UNKNOWN;
        modalOptions.clear();
        if (previous != null && previous.isAttachedToWindow()) previous.requestFocus();
        else if (editorView == null && pickerView == null && allView == null) focusFirstDockItem();
        if (closingSources && inputsButton != null && !inputsButton.hasFocus()
                && inputsButton.getChildCount() > 1) {
            TextView label = (TextView) inputsButton.getChildAt(1);
            label.animate().cancel();
            label.animate().alpha(0f).setDuration(95L).start();
            animateHeaderButtonWidth(inputsButton, label, dp(39), "Források");
        }
    }

    // ---------- UI segedek ----------
    private ImageView addBackground() {
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(image, new FrameLayout.LayoutParams(-1, -1));
        return image;
    }

    private TextView text(CharSequence value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    private GradientDrawable gradient(int[] colors) {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
    }

    // Ultra glass: reflective focus controls. These selectors do NOT affect app-card focus,
    // whose foreground is still transparent except for the thin outline.
    private Drawable ultraHeaderSelector() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, visibleMenuFocus(17));
        s.addState(new int[]{}, new UltraGlassDrawable(17, 0));
        return s;
    }

    /**
     * V8.2: one continuous soft focus surface for menus, not neon lines.
     * The original album-reactive MediaHaloDrawable is not involved.
     */
    private final class PremiumMenuFocusDrawable extends Drawable {
        private final float radiusDp;
        private final Paint light = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint wash = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final Path clipShape = new Path();
        private int opacity = 255;
        PremiumMenuFocusDrawable(int radius) {
            radiusDp = radius;
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(Math.max(1f, dp(1.6f)));
        }
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.isEmpty() || opacity <= 0) return;
            float r = Math.min(dp(radiusDp), Math.min(b.width(), b.height()) / 2f);
            rect.set(b.left + dp(1), b.top + dp(1),
                    b.right - dp(1), b.bottom - dp(1));
            wash.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{0xD7A8C3D6, 0xCE507392, 0xCD1D3851},
                    new float[]{0f, 0.43f, 1f}, Shader.TileMode.CLAMP));
            wash.setAlpha(opacity);
            canvas.drawRoundRect(rect, r, r, wash);
            light.setShader(new android.graphics.RadialGradient(
                    b.left + b.width() * 0.25f, b.top + b.height() * 0.12f,
                    Math.max(b.width() * 0.73f, dp(1)),
                    new int[]{0xB8F7FDFF, 0x38D5EBFC, 0x00DDEFFF},
                    new float[]{0f, 0.47f, 1f}, Shader.TileMode.CLAMP));
            light.setAlpha(opacity);
            clipShape.reset();
            clipShape.addRoundRect(rect, r, r, Path.Direction.CW);
            canvas.save();
            canvas.clipPath(clipShape);
            canvas.drawRect(rect, light);
            canvas.restore();
            rim.setColor(0xF3F5FCFF);
            rim.setAlpha(Math.round(opacity * 0.92f));
            canvas.drawRoundRect(rect, r, r, rim);
        }
        @Override public void setAlpha(int a) { opacity = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter cf) {
            light.setColorFilter(cf); wash.setColorFilter(cf); rim.setColorFilter(cf);
            invalidateSelf();
        }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private Drawable visibleMenuFocus(int radius) {
        // Shared lightweight wallpaper glass + diffused edge light.
        return new android.graphics.drawable.LayerDrawable(new Drawable[]{
                new UltraGlassDrawable(radius, 4), new PremiumMenuFocusDrawable(radius)});
    }

    private Drawable ultraActionSelector(int radius) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, visibleMenuFocus(radius));
        s.addState(new int[]{}, new UltraGlassDrawable(radius, 0));
        return s;
    }

    private Drawable ultraMenuRowSelector(int radius) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, visibleMenuFocus(radius));
        s.addState(new int[]{}, new ColorDrawable(0x00000000));
        return s;
    }

    /**
     * Reflection ONLY: a top-left polished rim and delicate side reflections.
     * All drawing is restricted to ~1-2 dp along edges, so banner images stay clear.
     */
    private void addUltraReflectionRim(FrameLayout tile, int cornerDp) {
        View rim = new View(this);
        rim.setFocusable(false);
        rim.setClickable(false);
        rim.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        rim.setBackground(new UltraRimDrawable(cornerDp));
        rim.setAlpha(0.54f);
        tile.addView(rim, new FrameLayout.LayoutParams(-1, -1));
    }

    private final class UltraRimDrawable extends Drawable {
        private final int cornerDp;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int opacity = 255;
        private int cachedWidth = -1, cachedHeight = -1;
        UltraRimDrawable(int corner) { cornerDp = corner; }
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (opacity == 0 || b.isEmpty()) return;
            final float radius = dp(cornerDp);
            final float one = Math.max(1f, dp(1));
            RectF r = new RectF(b.left + one, b.top + one,
                    b.right - one, b.bottom - one);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(one);
            if (b.width() != cachedWidth || b.height() != cachedHeight) {
                cachedWidth = b.width();
                cachedHeight = b.height();
                p.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                        new int[]{0xE6FFFFFF, 0x9FD7EDFF, 0x28FFFFFF, 0x75DAEEFF},
                        new float[]{0f, 0.24f, 0.64f, 1f}, Shader.TileMode.CLAMP));
            }
            p.setAlpha(opacity);
            canvas.drawRoundRect(r, radius, radius, p);
            p.setStyle(Paint.Style.FILL);
        }
        @Override public void setAlpha(int a) { opacity = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter f) { p.setColorFilter(f); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /**
     * TVHome 6.6 true wallpaper glass: the pane is a window onto a blurred copy
     * of the SAME wallpaper at the SAME screen position. No gray paint fill.
     * A small warped sample near the perimeter simulates a glass lens, while
     * translucent neutral highlights and bevel reflections create thickness.
     * The source wallpaper is sampled/blurry only after a background load;
     * focus navigation only draws existing GPU bitmap + cheap strokes.
     * kind 0: header, 1: dock, 2: menus, 3: app background, 4: focused button.
     */
    private final class UltraGlassDrawable extends Drawable {
        private final int radiusDp, kind;
        private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint lens = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint neutral = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint reflection = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint outerEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bevel = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint upperShine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lowerShine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect sample = new Rect();
        private final Rect distorted = new Rect();
        private final RectF pane = new RectF();
        private final RectF inner = new RectF();
        private final Path shape = new Path();
        private final Path perimeter = new Path();
        private final int[] viewPos = new int[2];
        private final int[] rootPos = new int[2];
        private int lastWidth = -1, lastHeight = -1;
        private int alpha = 255;

        UltraGlassDrawable(int radius, int style) {
            radiusDp = radius;
            kind = style;
            outerEdge.setStyle(Paint.Style.STROKE);
            bevel.setStyle(Paint.Style.STROKE);
            upperShine.setStyle(Paint.Style.STROKE);
            lowerShine.setStyle(Paint.Style.STROKE);
        }

        private void geometry(int width, int height) {
            if (width == lastWidth && height == lastHeight) return;
            lastWidth = width;
            lastHeight = height;
            float r = Math.min(dp(radiusDp), Math.min(width, height) * 0.5f);
            pane.set(0, 0, width, height);
            shape.reset();
            shape.addRoundRect(pane, r, r, Path.Direction.CW);
            // One continuous 5 dp rim; no oval/glow painted over the icon.
            float edge = Math.min(dp(5), Math.min(width, height) * 0.18f);
            inner.set(edge, edge, width - edge, height - edge);
            perimeter.reset();
            perimeter.setFillType(Path.FillType.EVEN_ODD);
            perimeter.addRoundRect(pane, r, r, Path.Direction.CW);
            perimeter.addRoundRect(inner, Math.max(0, r - edge),
                    Math.max(0, r - edge), Path.Direction.CW);

            final int top, bottom;
            if (kind == 1) { // dock: neutral crystal with wallpaper still visible
                top = 0x3AFFFFFF; bottom = 0x2C101923;
            } else if (kind == 2) { // V8.2: deep neutral glass, less milky/blue
                top = 0x6DECF7FF; bottom = 0xBB101E30;
            } else if (kind == 3) { // cards: image is drawn on top, do not wash it
                top = 0x1EFFFFFF; bottom = 0x180A1725;
            } else if (kind == 4) {
                top = 0x58FFFFFF; bottom = 0x36121F2C;
            } else {
                top = 0x35FFFFFF; bottom = 0x300B1523;
            }
            neutral.setShader(new LinearGradient(0, 0, width * 0.14f, height,
                    top, bottom, Shader.TileMode.CLAMP));
            reflection.setShader(new LinearGradient(0, 0,
                    Math.max(1, width * 0.12f), Math.max(1, height * 0.48f),
                    new int[]{0x82FFFFFF, 0x1EFFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.36f, 1f}, Shader.TileMode.CLAMP));
            outerEdge.setStrokeWidth(Math.max(1f, dp(1.15f)));
            outerEdge.setShader(new LinearGradient(0, 0, width, height,
                    new int[]{0xEEFFFFFF, 0x93FFFFFF, 0x40B9DDF7, 0xB4FFFFFF},
                    new float[]{0f, 0.28f, 0.70f, 1f}, Shader.TileMode.CLAMP));
            bevel.setStrokeWidth(Math.max(1f, dp(2.3f)));
            bevel.setShader(new LinearGradient(0, 0, width * 0.32f, height,
                    new int[]{0x84FFFFFF, 0x08FFFFFF, 0x4CB7D6EF},
                    new float[]{0f, 0.46f, 1f}, Shader.TileMode.CLAMP));
            upperShine.setStrokeWidth(Math.max(1f, dp(1.45f)));
            upperShine.setStrokeCap(Paint.Cap.ROUND);
            upperShine.setShader(new LinearGradient(r, 0, width * 0.69f, 0,
                    new int[]{0x12FFFFFF, 0xE8FFFFFF, 0x7AFFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.18f, 0.62f, 1f}, Shader.TileMode.CLAMP));
            lowerShine.setStrokeWidth(Math.max(1f, dp(1.1f)));
            lowerShine.setShader(new LinearGradient(0, height, width, height,
                    new int[]{0x16FFFFFF, 0x8CD7F1FF, 0xB7FFFFFF, 0x10FFFFFF},
                    new float[]{0f, 0.34f, 0.76f, 1f}, Shader.TileMode.CLAMP));
        }

        private View findOwner() {
            Drawable.Callback cb = getCallback();
            int hops = 0;
            while (cb instanceof Drawable && hops++ < 6)
                cb = ((Drawable) cb).getCallback();
            return cb instanceof View ? (View) cb : null;
        }

        @Override public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            int w = bounds.width(), h = bounds.height();
            if (w <= 1 || h <= 1 || alpha == 0) return;
            geometry(w, h);
            final float r = Math.min(dp(radiusDp), Math.min(w, h) * 0.5f);
            final float strength = glassStrength / (float) BASE_GLASS;
            final float dockPhoto = kind == 1 && dockStyle == 1 ? 0.32f : 1f;
            final float dockTint = kind == 1
                    ? (dockStyle == 1 ? 0.30f : dockStyle == 2 ? 1.33f : 1f) : 1f;
            final float highlight = (kind == 1 && dockStyle == 1 ? 0.76f : 1f) * strength;
            int save = canvas.save();
            canvas.translate(bounds.left, bounds.top);
            canvas.clipPath(shape);

            Bitmap backdrop = ultraWallpaperGlass;
            View owner = findOwner();
            if (owner != null && root != null && root.getWidth() > 0 && root.getHeight() > 0
                    && backdrop != null && !backdrop.isRecycled()) {
                owner.getLocationOnScreen(viewPos);
                root.getLocationOnScreen(rootPos);
                float sx = backdrop.getWidth() / (float) root.getWidth();
                float sy = backdrop.getHeight() / (float) root.getHeight();
                // Clamp to bitmap boundaries; for homeScroll content the sample
                // uses the visible screen location, not the off-screen row index.
                int x1 = Math.max(0, Math.min(backdrop.getWidth() - 1,
                        Math.round((viewPos[0] - rootPos[0]) * sx)));
                int y1 = Math.max(0, Math.min(backdrop.getHeight() - 1,
                        Math.round((viewPos[1] - rootPos[1]) * sy)));
                int x2 = Math.max(x1 + 1, Math.min(backdrop.getWidth(),
                        Math.round((viewPos[0] - rootPos[0] + w) * sx)));
                int y2 = Math.max(y1 + 1, Math.min(backdrop.getHeight(),
                        Math.round((viewPos[1] - rootPos[1] + h) * sy)));
                sample.set(x1, y1, x2, y2);
                // A blurred wallpaper itself supplies almost all material color.
                photo.setAlpha(clampAlpha(alpha * 0.99f * strength * dockPhoto));
                canvas.drawBitmap(backdrop, sample, pane, photo);

                // Gentle 2 px optical displacement only around the pane rim.
                // This is a cheap static lens approximation, not live GPU blur.
                if (kind != 3) {
                    int edgeSave = canvas.save();
                    canvas.clipPath(perimeter);
                    distorted.set(sample);
                    int distortion = 2;
                    distorted.left = Math.max(0, distorted.left - distortion);
                    distorted.top = Math.max(0, distorted.top - distortion);
                    distorted.right = Math.min(backdrop.getWidth(), distorted.right + distortion);
                    distorted.bottom = Math.min(backdrop.getHeight(), distorted.bottom + distortion);
                    lens.setAlpha(clampAlpha(alpha * 0.89f * strength));
                    canvas.drawBitmap(backdrop, distorted, pane, lens);
                    canvas.restoreToCount(edgeSave);
                }
            }
            // Neutral transparent glass + a thin photographic reflection.
            // Crucially NOT an opaque blue/gray fill like in 6.5.
            neutral.setAlpha(clampAlpha(alpha * strength * dockTint));
            canvas.drawRect(pane, neutral);
            reflection.setAlpha(clampAlpha(alpha * highlight
                    * (kind == 3 ? 0.45f : kind == 2 ? 0.52f : 0.8f)));
            canvas.drawRect(0, 0, w, h * 0.46f, reflection);
            canvas.restoreToCount(save);

            save = canvas.save();
            canvas.translate(bounds.left, bounds.top);
            // Two delicate beveled light edges create visual thickness.
            outerEdge.setAlpha(clampAlpha(alpha * highlight));
            canvas.drawRoundRect(dp(0.7f), dp(0.7f), w - dp(0.7f),
                    h - dp(0.7f), r, r, outerEdge);
            bevel.setAlpha(clampAlpha(alpha * highlight
                    * (kind == 3 ? 0.25f : kind == 2 ? 0.43f : 0.64f)));
            canvas.drawRoundRect(dp(2.9f), dp(2.9f), w - dp(2.9f),
                    h - dp(2.9f), Math.max(0, r - dp(2.4f)),
                    Math.max(0, r - dp(2.4f)), bevel);
            // Soft gleam following the horizontal lips of the glass.
            if (kind != 3) {
                upperShine.setAlpha(clampAlpha(alpha * highlight * (kind == 2 ? 0.38f : 1f)));
                canvas.drawLine(r, dp(1.35f), Math.max(r, w - r),
                        dp(1.35f), upperShine);
                lowerShine.setAlpha(clampAlpha(alpha * (kind == 2 ? 0.34f : 0.72f) * highlight));
                canvas.drawLine(r, h - dp(1.35f), Math.max(r, w - r),
                        h - dp(1.35f), lowerShine);
            }
            canvas.restoreToCount(save);
        }

        @Override public void setAlpha(int a) {
            alpha = Math.max(0, Math.min(255, a));
            invalidateSelf();
        }
        @Override public void setColorFilter(ColorFilter filter) {
            photo.setColorFilter(filter);
            lens.setColorFilter(filter);
            neutral.setColorFilter(filter);
            reflection.setColorFilter(filter);
            invalidateSelf();
        }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Pixel-identical two-pass box blur, streamed through a 19-row ring buffer.
     * The crop, size, RGB rounding and edge clamping are unchanged. */
    private Bitmap makeUltraGlassSample(Bitmap source) {
        if (source == null) return null;
        final int w = 480;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int h = Math.max(120, Math.min(300, Math.round(
                w * (float) dm.heightPixels / Math.max(1, dm.widthPixels))));
        Bitmap preview = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Rect crop;
        float srcAspect = (float) source.getWidth() / Math.max(1, source.getHeight());
        float dstAspect = (float) w / h;
        if (srcAspect > dstAspect) {
            int sw = Math.max(1, Math.round(source.getHeight() * dstAspect));
            int off = Math.max(0, (source.getWidth() - sw) / 2);
            crop = new Rect(off, 0, off + sw, source.getHeight());
        } else {
            int sh = Math.max(1, Math.round(source.getWidth() / dstAspect));
            int off = Math.max(0, (source.getHeight() - sh) / 2);
            crop = new Rect(0, off, source.getWidth(), off + sh);
        }
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        new Canvas(preview).drawBitmap(source, crop, new Rect(0, 0, w, h), paint);
        final int blur = 9;
        final int diameter = 2 * blur + 1;
        final int[] rows = new int[w * diameter];
        final int[] input = new int[w], output = new int[w];
        final int[] red = new int[w], green = new int[w], blue = new int[w];
        for (int slot = 0; slot < diameter; slot++) {
            int y = Math.max(0, Math.min(h - 1, slot - blur));
            if (slot > 0 && slot <= blur) System.arraycopy(rows, 0, rows, slot * w, w);
            else blurHorizontalRow(preview, y, input, rows, slot * w, w, blur);
            for (int x = 0; x < w; x++) {
                int c = rows[slot * w + x];
                red[x] += (c >>> 16) & 255;
                green[x] += (c >>> 8) & 255;
                blue[x] += c & 255;
            }
        }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) output[x] = 0xFF000000
                    | ((red[x] / diameter) << 16) | ((green[x] / diameter) << 8)
                    | (blue[x] / diameter);
            preview.setPixels(output, 0, w, 0, y, w, 1);
            if (y + 1 == h) break;
            int offset = (y % diameter) * w;
            for (int x = 0; x < w; x++) {
                int c = rows[offset + x];
                red[x] -= (c >>> 16) & 255;
                green[x] -= (c >>> 8) & 255;
                blue[x] -= c & 255;
            }
            // Future rows have not been overwritten by vertical output yet.
            blurHorizontalRow(preview, Math.min(h - 1, y + blur + 1), input, rows, offset, w, blur);
            for (int x = 0; x < w; x++) {
                int c = rows[offset + x];
                red[x] += (c >>> 16) & 255;
                green[x] += (c >>> 8) & 255;
                blue[x] += c & 255;
            }
        }
        return preview;
    }

    private static void blurHorizontalRow(Bitmap image, int y, int[] input,
            int[] rows, int offset, int width, int radius) {
        image.getPixels(input, 0, width, 0, y, width, 1);
        int red = 0, green = 0, blue = 0;
        int diameter = radius * 2 + 1;
        for (int i = -radius; i <= radius; i++) {
            int c = input[Math.max(0, Math.min(width - 1, i))];
            red += (c >>> 16) & 255; green += (c >>> 8) & 255; blue += c & 255;
        }
        for (int x = 0; x < width; x++) {
            rows[offset + x] = 0xFF000000 | ((red / diameter) << 16)
                    | ((green / diameter) << 8) | (blue / diameter);
            if (x + 1 == width) break;
            int leaving = input[Math.max(0, x - radius)];
            int entering = input[Math.min(width - 1, x + radius + 1)];
            red += ((entering >>> 16) & 255) - ((leaving >>> 16) & 255);
            green += ((entering >>> 8) & 255) - ((leaving >>> 8) & 255);
            blue += (entering & 255) - (leaving & 255);
        }
    }

    private void invalidateUltraGlassSurfaces(View node) {
        if (node == null) return;
        node.invalidate();
        if (node instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) node;
            for (int i = 0; i < group.getChildCount(); i++) {
                invalidateUltraGlassSurfaces(group.getChildAt(i));
            }
        }
    }

    private GradientDrawable glassRounded(int[] colors, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private Drawable headerGlassSelector() {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused},
                glassRounded(new int[]{0xB8FFFFFF, 0x66BED2EF}, 17, 0xF4FFFFFF, 1));
        bg.addState(new int[]{},
                glassRounded(new int[]{0x78EEF5FF, 0x307D93AE}, 17, 0x58FFFFFF, 1));
        return bg;
    }

    private Drawable menuRowGlassSelector(int radiusDp) {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused},
                glassRounded(new int[]{0x99FFFFFF, 0x5CAAC1E0}, radiusDp, 0xE6FFFFFF, 1));
        bg.addState(new int[]{}, new ColorDrawable(0x00000000));
        return bg;
    }

    private Drawable actionButtonGlassSelector(int radiusDp) {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused},
                glassRounded(new int[]{0xAEFFFFFF, 0x60BDD2ED}, radiusDp, 0xF0FFFFFF, 1));
        bg.addState(new int[]{},
                glassRounded(new int[]{0x6BE8F1FF, 0x2F7A8FA9}, radiusDp, 0x44FFFFFF, 1));
        return bg;
    }

    private Drawable panelGlassBackground(int radiusDp) {
        return glassRounded(new int[]{0xE65A6A80, 0xCC182332}, radiusDp, 0x74FFFFFF, 1);
    }

    private Drawable dockGlassBackground(int radiusDp) {
        return glassRounded(new int[]{0xC76E8099, 0xA2182230}, radiusDp, 0x4CFFFFFF, 1);
    }

    private Drawable appTileGlassBackground(int radiusDp) {
        return glassRounded(new int[]{0xC36B7F98, 0x9B172230}, radiusDp, 0x40FFFFFF, 1);
    }

    private Drawable innerImageGlassBackground(int radiusDp) {
        return glassRounded(new int[]{0x25FFFFFF, 0x10D8E6FF}, radiusDp, 0x12FFFFFF, 1);
    }

    /** Egyetlen elegáns, vékony fehér körvonal; a fényt külön réteg adja. */
    private Drawable focusOutlineSelector(int focusState, int radiusDp) {
        StateListDrawable selector = new StateListDrawable();
        selector.addState(new int[]{focusState},
                rounded(0x00000000, radiusDp, 0xF5FFFFFF, 2));
        selector.addState(new int[]{},
                rounded(0x00000000, radiusDp, 0x00000000, 0));
        return selector;
    }

    private void addSoftGlowLayer(FrameLayout card, int cornerDp) {
        // Az első gyermek mindig az alkalmazás képe marad.
        View glow = new View(this);
        glow.setBackground(new SoftEdgeGlowDrawable(dp(13), dp(cornerDp), dp(2.5f), dp(8)));
        glow.setAlpha(0f);
        glow.setFocusable(false);
        glow.setClickable(false);
        glow.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, -1);
        p.setMargins(-dp(13), -dp(13), -dp(13), -dp(13));
        card.addView(glow, p);
    }

    /** Kikapcsolás AZONNAL; bekapcsoláskor finom 160 ms-os fade. */
    private void setSoftGlowVisible(FrameLayout card, boolean visible, boolean animateIn) {
        if (card.getChildCount() < 2) return;
        View glow = card.getChildAt(1);
        if (!visible) {
            glow.animate().cancel();
            glow.setAlpha(0f);
        } else if (animateIn) {
            glow.animate().cancel();
            glow.setAlpha(0f);
            glow.animate().alpha(1f).setDuration(Math.round(160f * FOCUS_MS / 175f))
                    .setInterpolator(tvEase).start();
        }
        // Azonos aktív csempe ismételt refreshénél az éppen futó fade-et
        // NEM szakítjuk félbe, különben láthatatlanul halvány maradhat.
    }

    /**
     * Egyetlen valóban BLUR-ös, kékesfehér kontúr fényárnyalata.
     * A BlurMaskFilter egyszer, kisméretű SZOFTVERES BITMAP-be rajzolódik,
     * a TV később sima GPU-textúraként jeleníti meg. Nincs állandó CPU blur,
     * több koncentrikus gyűrű vagy drága teljes képernyős effekt.
     * Az app belsejét átlátszóra töröljük, így a logó nem lesz fátyolos.
     */
    private static final class SoftEdgeGlowDrawable extends Drawable {
        private static android.graphics.ColorMatrixColorFilter strengthFilter;

        static void setGlowPercent(int percent) {
            float gain = Math.max(0f, percent / (float) BASE_GLOW);
            if (Math.abs(gain - 1f) < 0.001f) {
                strengthFilter = null; // exact 6.6 output at default value
            } else {
                float[] matrix = new float[]{
                        1f,0f,0f,0f,0f,
                        0f,1f,0f,0f,0f,
                        0f,0f,1f,0f,0f,
                        0f,0f,0f,gain,0f};
                strengthFilter = new android.graphics.ColorMatrixColorFilter(matrix);
            }
        }

        private static final LruCache<String, Bitmap> CACHE =
                new LruCache<String, Bitmap>(1024) {
                    @Override protected int sizeOf(String key, Bitmap bitmap) {
                        return Math.max(1, bitmap.getByteCount() / 1024);
                    }
                };
        private final int bleed, radius, stroke, blur;
        private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private int alpha = 255;
        // Csak az appracs mozgo kijelolo fenye allitja be. A dock/egyeb glow
        // eredeti, pixelpontos rajzolasa valtozatlan marad.
        private int stableTextureWidth = 0, stableTextureHeight = 0;
        private String textureKey;
        private int textureWidth = -1, textureHeight = -1;

        SoftEdgeGlowDrawable(int bleed, int radius, int stroke, int blur) {
            this.bleed = bleed;
            this.radius = radius;
            this.stroke = stroke;
            this.blur = blur;
        }

        void setStableTextureSize(int width, int height) {
            stableTextureWidth = Math.max(1, width);
            stableTextureHeight = Math.max(1, height);
        }

        @Override public void draw(Canvas screen) {
            Rect b = getBounds();
            int actualWidth = b.width(), actualHeight = b.height();
            if (alpha == 0 || actualWidth <= 0 || actualHeight <= 0
                    || actualWidth > 1800 || actualHeight > 1200) return;
            final boolean stable = stableTextureWidth > 0 && stableTextureHeight > 0;
            int w = stable ? stableTextureWidth : actualWidth;
            int h = stable ? stableTextureHeight : actualHeight;
            if (w > 1800 || h > 1200) return;
            if (w != textureWidth || h != textureHeight) {
                textureWidth = w; textureHeight = h;
                textureKey = w + "x" + h + ":" + bleed + ":" + radius + ":" + stroke + ":" + blur;
            }
            Bitmap cached = CACHE.get(textureKey);
            if (cached == null || cached.isRecycled()) {
                cached = Bitmap.createBitmap(w, h, Config.ARGB_8888);
                Canvas c = new Canvas(cached); // software Canvas: blur csak itt fut egyszer
                RectF inner = new RectF(bleed, bleed, w - bleed, h - bleed);
                Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
                soft.setStyle(Paint.Style.STROKE);
                soft.setStrokeWidth(stroke);
                soft.setColor(0xB4C9E5FF);
                soft.setMaskFilter(new BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL));
                c.drawRoundRect(inner, radius, radius, soft);
                // Csak a csempén kívüli glow maradjon, belül semmi ne fakítsa a képet.
                Paint erase = new Paint(Paint.ANTI_ALIAS_FLAG);
                erase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                c.drawRoundRect(inner, radius, radius, erase);
                erase.setXfermode(null);
                CACHE.put(textureKey, cached);
            }
            bitmapPaint.setAlpha(alpha);
            bitmapPaint.setColorFilter(strengthFilter);
            // Az app-glow mozgasakor nem gyartunk minden uj merethez bitmapet:
            // a vegso meretu, egyszer elkeszitett texturat rajzoljuk celrectbe.
            if (stable) screen.drawBitmap(cached, null, b, bitmapPaint);
            else screen.drawBitmap(cached, b.left, b.top, bitmapPaint);
        }

        @Override public void setAlpha(int value) {
            alpha = Math.max(0, Math.min(255, value));
            invalidateSelf();
        }
        @Override public void setColorFilter(ColorFilter filter) {
            bitmapPaint.setColorFilter(filter);
            invalidateSelf();
        }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static ExecutorService idleWorker(String name) {
        // Still serial: release the idle thread/stack between user requests.
        return new java.util.concurrent.ThreadPoolExecutor(0, 1, 15L,
                java.util.concurrent.TimeUnit.SECONDS,
                new java.util.concurrent.LinkedBlockingQueue<Runnable>(),
                task -> new Thread(task, name));
    }

    /** A kuldott forras-ikonhoz hasonlo, atlatszo hatteru nyil es kijelzo. */
    private static class SourceIcon extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrow = new Path();
        private int alpha = 255;
        SourceIcon() {
            arrow.moveTo(56f, 30f); arrow.lineTo(82f, 50f);
            arrow.lineTo(56f, 70f); arrow.close();
        }
        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            c.save();
            c.translate(b.left, b.top);
            c.scale(b.width() / 100f, b.height() / 100f);
            p.setColor(0xFFF2F3F6);
            p.setAlpha(alpha);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(9f);
            c.drawRoundRect(9f, 12f, 91f, 88f, 12f, 12f, p);
            p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(22f, 46f, 66f, 55f, 1f, 1f, p);
            c.drawPath(arrow, p);
            c.restore();
        }
        @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { p.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Fogaskerek: tiszta vektor a kuldott, vizjeles PNG stilusaban. */
    private static class GearIcon extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int alpha = 255;
        private final Path gear = new Path();
        GearIcon() {
            final int teeth = 12;
            for (int i = 0; i < teeth * 4; i++) {
                double angle = -Math.PI / 2 + i * Math.PI * 2 / (teeth * 4);
                int step = i % 4;
                float r = (step == 1 || step == 2) ? 48f : 37f;
                float x = (float)(Math.cos(angle) * r);
                float y = (float)(Math.sin(angle) * r);
                if (i == 0) gear.moveTo(x, y); else gear.lineTo(x, y);
            }
            gear.close();
            gear.setFillType(android.graphics.Path.FillType.EVEN_ODD);
            gear.addCircle(0f, 0f, 15f, android.graphics.Path.Direction.CW);
        }
        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            c.save();
            c.translate(b.left + b.width() / 2f, b.top + b.height() / 2f);
            float sc = Math.min(b.width(), b.height()) / 100f;
            c.scale(sc, sc);
            p.setColor(0xFFF2F3F6);
            p.setAlpha(alpha);
            p.setStyle(Paint.Style.FILL);
            c.drawPath(gear, p);
            p.setColor(0x77111822);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4f);
            c.drawCircle(0f, 0f, 26f, p);
            c.restore();
        }
        @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { p.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Negyiranyu athelyezes ikon, atlatszo hatterrel. */
    private static class FourWayIcon extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int alpha = 255;
        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            canvas.save();
            canvas.translate(b.left, b.top);
            canvas.scale(b.width() / 100f, b.height() / 100f);
            paint.setColor(0xFFF5F6FA);
            paint.setAlpha(alpha);
            paint.setStrokeWidth(9f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawLine(50, 18, 50, 82, paint);
            canvas.drawLine(18, 50, 82, 50, paint);
            paint.setStyle(Paint.Style.FILL);
            android.graphics.Path p = new android.graphics.Path();
            p.moveTo(50, 0); p.lineTo(34, 24); p.lineTo(66, 24); p.close();
            canvas.drawPath(p, paint);
            p.reset(); p.moveTo(50, 100); p.lineTo(34, 76); p.lineTo(66, 76); p.close();
            canvas.drawPath(p, paint);
            p.reset(); p.moveTo(0, 50); p.lineTo(24, 34); p.lineTo(24, 66); p.close();
            canvas.drawPath(p, paint);
            p.reset(); p.moveTo(100, 50); p.lineTo(76, 34); p.lineTo(76, 66); p.close();
            canvas.drawPath(p, paint);
            canvas.restore();
        }
        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) {
            paint.setColorFilter(filter); invalidateSelf();
        }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Egyszeru plusz (+) rajz, nincs uj PNG vagy eroforras-fuggoseg. */
    private static class PlusIcon extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int alpha = 255;
        @Override public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            float cx = bounds.exactCenterX();
            float cy = bounds.exactCenterY();
            float arm = Math.min(bounds.width(), bounds.height()) * 0.27f;
            paint.setColor(0xFFFFFFFF);
            paint.setAlpha(alpha);
            paint.setStrokeWidth(Math.max(3f, Math.min(bounds.width(), bounds.height()) * 0.095f));
            paint.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawLine(cx - arm, cy, cx + arm, cy, paint);
            canvas.drawLine(cx, cy - arm, cx, cy + arm, paint);
        }
        @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private static class AppEntry {
        final CharSequence label;
        final Drawable icon;
        final Intent intent;
        AppEntry(CharSequence label, Drawable icon, Intent intent) {
            this.label = label;
            this.icon = icon;
            this.intent = intent;
        }
    }
}
